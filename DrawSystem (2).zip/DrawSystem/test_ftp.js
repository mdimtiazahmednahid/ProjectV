import { Client } from "basic-ftp"

const client = new Client()

async function testFTP() {
    try {
        await client.access({
            host: "ftp.shunnointernational.com",
            user: "ecom123@draw.shunnointernational.com",
            password: "u1#=1$}*0s^coqC[",
            secure: false
        })
        console.log(await client.list())
    }
    catch(err) {
        console.error("Failed:", err)
    }
    client.close()
}

testFTP()

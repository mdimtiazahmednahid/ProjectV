-- FairDraw Database Schema

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- Roles & Permissions
-- --------------------------------------------------------
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `permissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `description` VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `role_permissions` (
  `role_id` INT NOT NULL,
  `permission_id` INT NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`permission_id`) REFERENCES `permissions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Administrators
-- --------------------------------------------------------
CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `last_login` TIMESTAMP NULL DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Giveaways
-- --------------------------------------------------------
CREATE TABLE `giveaways` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `prize` VARCHAR(255) NOT NULL,
  `facebook_post_url` VARCHAR(255) NOT NULL,
  `facebook_post_id` VARCHAR(100) NOT NULL,
  `number_of_winners` INT NOT NULL DEFAULT 1,
  `reserve_winners` INT NOT NULL DEFAULT 0,
  `status` ENUM('draft', 'active', 'frozen', 'completed', 'archived') NOT NULL DEFAULT 'draft',
  `scheduled_draw_time` TIMESTAMP NULL DEFAULT NULL,
  `rules_json` JSON NOT NULL, -- Stores settings like One Entry Per User, Ignore Replies, etc.
  `notes` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Facebook Data
-- --------------------------------------------------------
CREATE TABLE `facebook_posts` (
  `id` VARCHAR(100) PRIMARY KEY,
  `giveaway_id` INT NOT NULL,
  `page_id` VARCHAR(100) NOT NULL,
  `message` TEXT DEFAULT NULL,
  `created_time` TIMESTAMP NULL DEFAULT NULL,
  `permalink_url` VARCHAR(255) DEFAULT NULL,
  `fetched_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`giveaway_id`) REFERENCES `giveaways`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `facebook_comments` (
  `id` VARCHAR(100) PRIMARY KEY,
  `giveaway_id` INT NOT NULL,
  `post_id` VARCHAR(100) NOT NULL,
  `parent_id` VARCHAR(100) DEFAULT NULL, -- Null if top-level comment
  `user_id` VARCHAR(100) NOT NULL,
  `user_name` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `created_time` TIMESTAMP NOT NULL,
  `permalink_url` VARCHAR(255) DEFAULT NULL,
  `reaction_count` INT DEFAULT 0,
  `mention_count` INT DEFAULT 0,
  `is_hidden` TINYINT(1) DEFAULT 0,
  `fetched_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`giveaway_id`) REFERENCES `giveaways`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX idx_fb_comments_giveaway ON facebook_comments(giveaway_id);
CREATE INDEX idx_fb_comments_user ON facebook_comments(user_id);

-- --------------------------------------------------------
-- Participants & Snapshots
-- --------------------------------------------------------
CREATE TABLE `participants` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `giveaway_id` INT NOT NULL,
  `facebook_user_id` VARCHAR(100) NOT NULL,
  `facebook_name` VARCHAR(255) NOT NULL,
  `comment_count` INT DEFAULT 1,
  `is_eligible` TINYINT(1) DEFAULT 1,
  `excluded_reason` VARCHAR(255) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`giveaway_id`) REFERENCES `giveaways`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX idx_participants_giveaway ON participants(giveaway_id);

CREATE TABLE `participant_snapshots` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `giveaway_id` INT NOT NULL,
  `admin_id` INT NOT NULL,
  `total_participants` INT NOT NULL,
  `eligible_count` INT NOT NULL,
  `snapshot_hash` VARCHAR(64) NOT NULL, -- SHA-256 hash of eligible participant IDs/names
  `snapshot_data` LONGTEXT NOT NULL, -- JSON string of the exact eligible participant list at freeze time
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`giveaway_id`) REFERENCES `giveaways`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Draw Engine
-- --------------------------------------------------------
CREATE TABLE `draws` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `giveaway_id` INT NOT NULL,
  `admin_id` INT NOT NULL,
  `seed` VARCHAR(255) NOT NULL, -- The random bytes generated for the draw (hex encoded)
  `participant_snapshot_id` INT NOT NULL,
  `algorithm` VARCHAR(50) DEFAULT 'Fisher-Yates',
  `software_version` VARCHAR(20) DEFAULT '1.0.0',
  `status` ENUM('in_progress', 'completed', 'failed') NOT NULL DEFAULT 'completed',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`giveaway_id`) REFERENCES `giveaways`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`),
  FOREIGN KEY (`participant_snapshot_id`) REFERENCES `participant_snapshots`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `winners` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `draw_id` INT NOT NULL,
  `participant_id` INT NOT NULL,
  `is_reserve` TINYINT(1) DEFAULT 0,
  `position` INT NOT NULL, -- The exact position they were drawn
  `status` ENUM('pending', 'confirmed', 'disqualified') NOT NULL DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`draw_id`) REFERENCES `draws`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`participant_id`) REFERENCES `participants`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Audit Logs
-- --------------------------------------------------------
CREATE TABLE `audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT DEFAULT NULL, -- Null if system action
  `giveaway_id` INT DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `description` TEXT NOT NULL,
  `old_value` JSON DEFAULT NULL,
  `new_value` JSON DEFAULT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `browser_user_agent` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`giveaway_id`) REFERENCES `giveaways`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE INDEX idx_audit_logs_giveaway ON audit_logs(giveaway_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);

-- --------------------------------------------------------
-- Exports
-- --------------------------------------------------------
CREATE TABLE `exports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT NOT NULL,
  `giveaway_id` INT NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_type` ENUM('csv', 'json', 'pdf') NOT NULL,
  `report_type` ENUM('winners', 'audit', 'participants', 'excluded') NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`giveaway_id`) REFERENCES `giveaways`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Settings & Notifications
-- --------------------------------------------------------
CREATE TABLE `settings` (
  `setting_key` VARCHAR(100) PRIMARY KEY,
  `setting_value` TEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `type` ENUM('info', 'success', 'warning', 'error') DEFAULT 'info',
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

COMMIT;

-- Default Settings Insert
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES 
('system_name', 'FairDraw'),
('timezone', 'UTC'),
('language', 'en'),
('export_preferences', 'csv'),
('winner_animation_duration', '3000'),
('shuffle_animation_rounds', '3');

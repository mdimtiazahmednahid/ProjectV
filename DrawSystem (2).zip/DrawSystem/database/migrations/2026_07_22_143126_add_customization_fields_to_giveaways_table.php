<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('giveaways', function (Blueprint $table) {
            $table->string('custom_title')->nullable();
            $table->string('custom_subtitle')->nullable();
            $table->string('custom_winner_title')->nullable();
            $table->string('custom_logo_url')->nullable();
            $table->string('custom_background_url')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('giveaways', function (Blueprint $table) {
            $table->dropColumn([
                'custom_title',
                'custom_subtitle',
                'custom_winner_title',
                'custom_logo_url',
                'custom_background_url'
            ]);
        });
    }
};

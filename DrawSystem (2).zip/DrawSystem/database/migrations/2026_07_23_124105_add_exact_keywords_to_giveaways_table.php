<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasColumn('giveaways', 'exact_keyword')) {
            Schema::table('giveaways', function (Blueprint $table) {
                $table->string('exact_keyword')->nullable()->after('required_keyword');
            $table->string('exact_wrong_keyword')->nullable()->after('wrong_keyword');
        });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('giveaways', function (Blueprint $table) {
            $table->dropColumn(['exact_keyword', 'exact_wrong_keyword']);
        });
    }
};

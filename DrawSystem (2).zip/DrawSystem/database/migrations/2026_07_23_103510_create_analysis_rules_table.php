<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('analysis_rules')) {
            Schema::create('analysis_rules', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('type'); // e.g. 'sentiment', 'correctness', 'mention', 'loyalty'
            $table->json('config'); // e.g. {"positive": ["good", "awesome"], "negative": ["bad"]}
            $table->timestamps();
        });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('analysis_rules');
    }
};

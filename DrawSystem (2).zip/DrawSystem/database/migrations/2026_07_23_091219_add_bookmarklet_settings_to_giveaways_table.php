<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddBookmarkletSettingsToGiveawaysTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('giveaways', function (Blueprint $table) {
            $table->boolean('grab_replies')->default(false);
            $table->boolean('grab_profile_url')->default(true);
            $table->boolean('grab_profile_pic')->default(true);
            $table->boolean('grab_comment_time')->default(true);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('giveaways', function (Blueprint $table) {
            $table->dropColumn([
                'grab_replies',
                'grab_profile_url',
                'grab_profile_pic',
                'grab_comment_time'
            ]);
        });
    }
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('gender_dictionaries', function (Blueprint $table) {
            $table->id();
            $table->string('keyword')->unique();
            $table->enum('gender', ['male', 'female']);
            $table->timestamps();
        });
        
        // Seed default Bengali keywords
        $defaults = [
            ['keyword' => 'md', 'gender' => 'male'],
            ['keyword' => 'md.', 'gender' => 'male'],
            ['keyword' => 'mohammad', 'gender' => 'male'],
            ['keyword' => 'mr', 'gender' => 'male'],
            ['keyword' => 'ahmed', 'gender' => 'male'],
            ['keyword' => 'mst', 'gender' => 'female'],
            ['keyword' => 'mst.', 'gender' => 'female'],
            ['keyword' => 'akter', 'gender' => 'female'],
            ['keyword' => 'begum', 'gender' => 'female'],
            ['keyword' => 'mrs', 'gender' => 'female'],
            ['keyword' => 'ms', 'gender' => 'female'],
        ];
        
        DB::table('gender_dictionaries')->insert(array_map(function($item) {
            return array_merge($item, ['created_at' => now(), 'updated_at' => now()]);
        }, $defaults));
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('gender_dictionaries');
    }
};

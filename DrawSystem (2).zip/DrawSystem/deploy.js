import { Client } from "basic-ftp"
import * as fs from "fs"
import * as path from "path"

const client = new Client()
client.ftp.verbose = true

const localDir = "e:\\NAHID\\DrawSystem"
const remoteDir = "/" // Usually uploads to the root of the FTP account mapped to this domain

const excludeDirs = ['.git', 'node_modules', 'vendor', '.idea', '.vscode', 'storage/framework/cache', 'storage/framework/views']

async function uploadDir(localPath, remotePath) {
    const items = fs.readdirSync(localPath)
    
    for (const item of items) {
        const fullLocalPath = path.join(localPath, item)
        const relPath = path.relative(localDir, fullLocalPath).replace(/\\/g, '/')
        const segments = relPath.split('/')
        
        // Check excludes (now properly checking any segment, so nested .git is ignored)
        if (segments.some(seg => excludeDirs.includes(seg)) || relPath.endsWith('.zip')) {
            continue
        }
        
        const stat = fs.statSync(fullLocalPath)
        const targetRemotePath = remotePath + (remotePath.endsWith('/') ? '' : '/') + item
        
        if (stat.isDirectory()) {
            await client.ensureDir(targetRemotePath)
            await uploadDir(fullLocalPath, targetRemotePath)
            await client.cd('..')
        } else {
            console.log(`Uploading ${relPath}...`)
            await client.uploadFrom(fullLocalPath, targetRemotePath)
        }
    }
}

async function deploy() {
    try {
        await client.access({
            host: "ftp.shunnointernational.com",
            user: "ecom123@draw.shunnointernational.com",
            password: "u1#=1$}*0s^coqC[",
            secure: false
        })
        
        console.log("Connected to FTP server")
        await uploadDir(localDir, remoteDir)
        console.log("Deployment completed successfully")
    }
    catch(err) {
        console.error("Deployment failed:", err)
    }
    client.close()
}

deploy()

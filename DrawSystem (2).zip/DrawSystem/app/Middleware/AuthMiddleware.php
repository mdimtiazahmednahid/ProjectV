<?php
namespace App\Middleware;

class AuthMiddleware {
    public static function check() {
        if (!isset($_SESSION['admin_id'])) {
            header("Location: " . APP_URL . "/login");
            exit();
        }
    }

    public static function guest() {
        if (isset($_SESSION['admin_id'])) {
            header("Location: " . APP_URL . "/dashboard");
            exit();
        }
    }
}

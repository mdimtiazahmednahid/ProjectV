<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Middleware\AuthMiddleware;

class DashboardController extends Controller {
    public function index() {
        AuthMiddleware::check();
        
        // Fetch stats here
        
        $this->view('dashboard/index', [
            'title' => 'Dashboard',
            'admin_name' => $_SESSION['admin_name']
        ]);
    }
}

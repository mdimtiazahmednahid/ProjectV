<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Models\Admin;

class AuthController extends Controller {
    public function login() {
        AuthMiddleware::guest();
        $this->view('auth/login', [
            'csrf_token' => CsrfMiddleware::generateToken()
        ]);
    }

    public function authenticate() {
        AuthMiddleware::guest();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            CsrfMiddleware::verifyToken($_POST['csrf_token'] ?? '');

            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            $admin = Admin::findByEmail($email);

            if ($admin && password_verify($password, $admin['password_hash'])) {
                if ($admin['is_active']) {
                    session_regenerate_id(true);
                    $_SESSION['admin_id'] = $admin['id'];
                    $_SESSION['admin_name'] = $admin['name'];
                    $_SESSION['admin_role'] = $admin['role_name'];

                    Admin::updateLastLogin($admin['id']);
                    
                    $this->redirect('/dashboard');
                } else {
                    $error = "Account is inactive.";
                }
            } else {
                $error = "Invalid email or password.";
            }

            $this->view('auth/login', [
                'error' => $error,
                'csrf_token' => CsrfMiddleware::generateToken()
            ]);
        }
    }

    public function logout() {
        session_destroy();
        $this->redirect('/login');
    }
}

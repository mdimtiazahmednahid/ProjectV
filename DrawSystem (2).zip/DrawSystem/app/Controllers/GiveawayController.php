<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Models\Giveaway;
use App\Services\FacebookService;
use App\Services\RuleEngine;
use App\Services\ParticipantEngine;

class GiveawayController extends Controller {
    public function __construct() {
        AuthMiddleware::check();
    }

    public function index() {
        $giveaways = Giveaway::all();
        $this->view('giveaways/index', [
            'title' => 'Giveaways',
            'giveaways' => $giveaways
        ]);
    }

    public function create() {
        $this->view('giveaways/create', [
            'title' => 'Create Giveaway',
            'csrf_token' => CsrfMiddleware::generateToken()
        ]);
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            CsrfMiddleware::verifyToken($_POST['csrf_token'] ?? '');

            // Basic validation
            $title = trim($_POST['title'] ?? '');
            $prize = trim($_POST['prize'] ?? '');
            $facebook_post_url = trim($_POST['facebook_post_url'] ?? '');
            
            // Extract post ID from URL (basic implementation, usually requires robust regex or API call)
            preg_match('/(?:posts|videos|photos)\/(?:a\.\d+\/)?(\d+)/', $facebook_post_url, $matches);
            $facebook_post_id = $matches[1] ?? 'unknown_id'; // In a real app, Facebook API parses this

            $data = [
                'admin_id' => $_SESSION['admin_id'],
                'title' => $title,
                'description' => $_POST['description'] ?? '',
                'prize' => $prize,
                'facebook_post_url' => $facebook_post_url,
                'facebook_post_id' => $facebook_post_id,
                'number_of_winners' => (int)($_POST['number_of_winners'] ?? 1),
                'reserve_winners' => (int)($_POST['reserve_winners'] ?? 0),
                'scheduled_draw_time' => !empty($_POST['scheduled_draw_time']) ? $_POST['scheduled_draw_time'] : null,
                'notes' => $_POST['notes'] ?? '',
                'rules' => [
                    'one_entry_per_user' => isset($_POST['rule_one_entry']),
                    'ignore_replies' => isset($_POST['rule_ignore_replies']),
                    'required_keyword' => $_POST['rule_keyword'] ?? '',
                ]
            ];

            Giveaway::create($data);
            
            // In a real app we'd trigger audit log here
            
            $this->redirect('/giveaways');
        }
    }

    public function show($id) {
        $giveaway = Giveaway::find($id);
        if (!$giveaway) {
            die("Giveaway not found");
        }
        
        // Fetch stats
        $db = \App\Core\Database::getInstance()->getConnection();
        $statsStmt = $db->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN is_eligible = 1 THEN 1 ELSE 0 END) as eligible, SUM(CASE WHEN is_eligible = 0 THEN 1 ELSE 0 END) as excluded FROM participants WHERE giveaway_id = :id");
        $statsStmt->execute(['id' => $id]);
        $stats = $statsStmt->fetch();

        $this->view('giveaways/show', [
            'title' => $giveaway['title'],
            'giveaway' => $giveaway,
            'stats' => $stats
        ]);
    }

    public function import($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $giveaway = Giveaway::find($id);
            if ($giveaway && $giveaway['status'] === 'active' || $giveaway['status'] === 'draft') {
                
                $fbService = new FacebookService();
                $fbService->fetchComments($id, $giveaway['facebook_post_id']);
                
                $ruleEngine = new RuleEngine();
                $ruleEngine->applyRules($id);
                
                // Update status if it was draft
                if ($giveaway['status'] === 'draft') {
                    $db = \App\Core\Database::getInstance()->getConnection();
                    $stmt = $db->prepare("UPDATE giveaways SET status = 'active' WHERE id = :id");
                    $stmt->execute(['id' => $id]);
                }
            }
            $this->redirect('/giveaways/' . $id);
        }
    }

    public function freeze($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $giveaway = Giveaway::find($id);
            if ($giveaway && $giveaway['status'] === 'active') {
                $engine = new ParticipantEngine();
                $engine->freeze($id, $_SESSION['admin_id']);
            }
            $this->redirect('/giveaways/' . $id);
        }
    }

    public function drawUI($id) {
        $giveaway = Giveaway::find($id);
        if (!$giveaway || $giveaway['status'] !== 'frozen') {
            $this->redirect('/giveaways/' . $id);
        }
        
        $this->view('giveaways/draw', [
            'title' => 'Draw Animation - ' . $giveaway['title'],
            'giveaway' => $giveaway
        ]);
    }

    public function executeDraw($id) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $giveaway = Giveaway::find($id);
            if ($giveaway && $giveaway['status'] === 'frozen') {
                $engine = new \App\Services\DrawEngine();
                $engine->execute($id, $_SESSION['admin_id']);
            }
            
            // Fetch winners
            $db = \App\Core\Database::getInstance()->getConnection();
            $stmt = $db->prepare("
                SELECT p.facebook_name, w.is_reserve, w.position 
                FROM winners w 
                JOIN participants p ON w.participant_id = p.id 
                JOIN draws d ON w.draw_id = d.id
                WHERE d.giveaway_id = :id 
                ORDER BY w.position ASC
            ");
            $stmt->execute(['id' => $id]);
            $winners = $stmt->fetchAll();

            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'winners' => $winners]);
            exit;
        }
    }
}

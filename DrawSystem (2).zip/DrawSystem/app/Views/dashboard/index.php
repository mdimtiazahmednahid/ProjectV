<?php ob_start(); ?>
<div class="mb-8">
    <h3 class="text-3xl font-medium text-gray-700 dark:text-white">Dashboard</h3>
    <p class="text-sm text-gray-600 dark:text-gray-400 mt-2">Welcome back, <?= htmlspecialchars($admin_name) ?>! Here is what's happening with your giveaways.</p>
</div>

<!-- Stats Cards -->
<div class="mt-4 flex flex-wrap -mx-6">
    <div class="w-full px-6 sm:w-1/2 xl:w-1/4">
        <div class="flex items-center px-5 py-6 bg-white rounded-md shadow-sm dark:bg-gray-800">
            <div class="p-3 bg-blue-600 bg-opacity-75 rounded-full">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </div>
            <div class="mx-5">
                <h4 class="text-2xl font-semibold text-gray-700 dark:text-gray-200">12</h4>
                <div class="text-gray-500 dark:text-gray-400">Active Giveaways</div>
            </div>
        </div>
    </div>
    
    <div class="w-full mt-6 px-6 sm:w-1/2 xl:w-1/4 sm:mt-0">
        <div class="flex items-center px-5 py-6 bg-white rounded-md shadow-sm dark:bg-gray-800">
            <div class="p-3 bg-green-600 bg-opacity-75 rounded-full">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
            </div>
            <div class="mx-5">
                <h4 class="text-2xl font-semibold text-gray-700 dark:text-gray-200">8,204</h4>
                <div class="text-gray-500 dark:text-gray-400">Total Participants</div>
            </div>
        </div>
    </div>
    
    <div class="w-full mt-6 px-6 sm:w-1/2 xl:w-1/4 xl:mt-0">
        <div class="flex items-center px-5 py-6 bg-white rounded-md shadow-sm dark:bg-gray-800">
            <div class="p-3 bg-yellow-600 bg-opacity-75 rounded-full">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
            </div>
            <div class="mx-5">
                <h4 class="text-2xl font-semibold text-gray-700 dark:text-gray-200">45</h4>
                <div class="text-gray-500 dark:text-gray-400">Completed Draws</div>
            </div>
        </div>
    </div>
    
    <div class="w-full mt-6 px-6 sm:w-1/2 xl:w-1/4 xl:mt-0">
        <div class="flex items-center px-5 py-6 bg-white rounded-md shadow-sm dark:bg-gray-800">
            <div class="p-3 bg-indigo-600 bg-opacity-75 rounded-full">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            </div>
            <div class="mx-5">
                <h4 class="text-2xl font-semibold text-gray-700 dark:text-gray-200">120</h4>
                <div class="text-gray-500 dark:text-gray-400">Recent Winners</div>
            </div>
        </div>
    </div>
</div>

<!-- Charts and Recent Activity -->
<div class="mt-8 flex flex-col lg:flex-row gap-6">
    <div class="w-full lg:w-2/3 bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Participant Growth (Last 7 Days)</h4>
        <canvas id="participantsChart" width="400" height="200"></canvas>
    </div>
    
    <div class="w-full lg:w-1/3 bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
        <h4 class="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Recent Activities</h4>
        <div class="relative px-4">
            <div class="absolute h-full border border-dashed border-opacity-20 border-secondary"></div>
            <!-- Timeline Item -->
            <div class="flex items-center w-full my-6 -ml-1.5">
                <div class="w-1/12 z-10">
                    <div class="w-3.5 h-3.5 bg-blue-600 rounded-full"></div>
                </div>
                <div class="w-11/12">
                    <p class="text-sm text-gray-600 dark:text-gray-400">Giveaway <span class="font-bold text-gray-800 dark:text-gray-200">"Summer Tech Bundle"</span> frozen.</p>
                    <p class="text-xs text-gray-500">2 hours ago</p>
                </div>
            </div>
            <!-- Timeline Item -->
            <div class="flex items-center w-full my-6 -ml-1.5">
                <div class="w-1/12 z-10">
                    <div class="w-3.5 h-3.5 bg-green-600 rounded-full"></div>
                </div>
                <div class="w-11/12">
                    <p class="text-sm text-gray-600 dark:text-gray-400">Winner selected for <span class="font-bold text-gray-800 dark:text-gray-200">"Weekly Gift Card"</span>.</p>
                    <p class="text-xs text-gray-500">5 hours ago</p>
                </div>
            </div>
            <!-- Timeline Item -->
            <div class="flex items-center w-full my-6 -ml-1.5">
                <div class="w-1/12 z-10">
                    <div class="w-3.5 h-3.5 bg-yellow-600 rounded-full"></div>
                </div>
                <div class="w-11/12">
                    <p class="text-sm text-gray-600 dark:text-gray-400">1,502 comments imported from Facebook.</p>
                    <p class="text-xs text-gray-500">Yesterday</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('participantsChart').getContext('2d');
        const isDarkMode = document.documentElement.classList.contains('dark');
        const textColor = isDarkMode ? '#9ca3af' : '#4b5563';
        const gridColor = isDarkMode ? '#374151' : '#e5e7eb';
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'New Participants',
                    data: [120, 190, 300, 500, 200, 300, 450],
                    backgroundColor: 'rgba(59, 130, 246, 0.2)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: { color: textColor }
                    }
                },
                scales: {
                    y: {
                        ticks: { color: textColor },
                        grid: { color: gridColor }
                    },
                    x: {
                        ticks: { color: textColor },
                        grid: { color: gridColor }
                    }
                }
            }
        });
    });
</script>

<?php
$content = ob_get_clean();
include APP_PATH . '/Views/layouts/app.php';
?>

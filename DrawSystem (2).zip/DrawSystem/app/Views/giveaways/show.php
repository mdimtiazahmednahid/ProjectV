<?php ob_start(); ?>
<div class="mb-6 flex items-center justify-between">
    <div class="flex items-center">
        <a href="<?= APP_URL ?>/giveaways" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mr-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
        </a>
        <div>
            <h3 class="text-2xl font-bold text-gray-800 dark:text-white"><?= htmlspecialchars($giveaway['title']) ?></h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Prize: <span class="font-semibold text-gray-800 dark:text-gray-200"><?= htmlspecialchars($giveaway['prize']) ?></span></p>
        </div>
    </div>
    <div>
        <?php
        $statusColors = [
            'draft' => 'bg-gray-100 text-gray-800 border-gray-200',
            'active' => 'bg-green-100 text-green-800 border-green-200',
            'frozen' => 'bg-blue-100 text-blue-800 border-blue-200',
            'completed' => 'bg-purple-100 text-purple-800 border-purple-200'
        ];
        $badgeClass = $statusColors[$giveaway['status']] ?? 'bg-gray-100 text-gray-800 border-gray-200';
        ?>
        <span class="px-3 py-1 <?= $badgeClass ?> rounded-full text-sm font-semibold border">
            Status: <?= ucfirst($giveaway['status']) ?>
        </span>
    </div>
</div>

<!-- Giveaway Dashboard Tabs -->
<div x-data="{ tab: 'overview' }" class="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
    
    <div class="border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
        <nav class="flex -mb-px px-6" aria-label="Tabs">
            <button @click="tab = 'overview'" :class="{'border-primary text-primary': tab === 'overview', 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300': tab !== 'overview'}" class="whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm transition-colors">
                Overview
            </button>
            <button @click="tab = 'participants'" :class="{'border-primary text-primary': tab === 'participants', 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300': tab !== 'participants'}" class="whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm transition-colors">
                Participants
            </button>
            <button @click="tab = 'draw'" :class="{'border-primary text-primary': tab === 'draw', 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300': tab !== 'draw'}" class="whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm transition-colors">
                Draw Engine
            </button>
        </nav>
    </div>

    <div class="p-6">
        <!-- Overview Tab -->
        <div x-show="tab === 'overview'">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                <!-- Import Actions -->
                <div class="lg:col-span-2 bg-gray-50 dark:bg-gray-700/50 rounded-lg p-6 border border-gray-200 dark:border-gray-600">
                    <h4 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Facebook Data Import</h4>
                    <p class="text-sm text-gray-600 dark:text-gray-300 mb-6">Connect to the Facebook API to retrieve comments from the specified post URL.</p>
                    
                    <div class="flex items-center space-x-4">
                        <?php if ($giveaway['status'] === 'draft' || $giveaway['status'] === 'active'): ?>
                        <form action="<?= APP_URL ?>/giveaways/import/<?= $giveaway['id'] ?>" method="POST">
                            <button type="submit" class="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-medium flex items-center">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                                Sync Comments
                            </button>
                        </form>
                        <span class="text-sm text-gray-500 dark:text-gray-400">Pulls latest data from Facebook</span>
                        <?php else: ?>
                        <p class="text-sm text-gray-500">Syncing is disabled because the giveaway is <?= $giveaway['status'] ?>.</p>
                        <?php endif; ?>
                    </div>

                    <div class="mt-8 grid grid-cols-3 gap-4">
                        <div class="bg-white dark:bg-gray-800 p-4 rounded-md shadow-sm border border-gray-100 dark:border-gray-700 text-center">
                            <span class="block text-2xl font-bold text-gray-800 dark:text-gray-200"><?= number_format((float)($stats['total'] ?? 0)) ?></span>
                            <span class="text-xs text-gray-500 uppercase tracking-wide">Total Participants Checked</span>
                        </div>
                        <div class="bg-white dark:bg-gray-800 p-4 rounded-md shadow-sm border border-gray-100 dark:border-gray-700 text-center">
                            <span class="block text-2xl font-bold text-green-600"><?= number_format((float)($stats['eligible'] ?? 0)) ?></span>
                            <span class="text-xs text-gray-500 uppercase tracking-wide">Eligible</span>
                        </div>
                        <div class="bg-white dark:bg-gray-800 p-4 rounded-md shadow-sm border border-gray-100 dark:border-gray-700 text-center">
                            <span class="block text-2xl font-bold text-red-500"><?= number_format((float)($stats['excluded'] ?? 0)) ?></span>
                            <span class="text-xs text-gray-500 uppercase tracking-wide">Excluded</span>
                        </div>
                    </div>
                </div>

                <!-- Giveaway Details -->
                <div class="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-600">
                    <h4 class="text-lg font-semibold text-gray-800 dark:text-white border-b dark:border-gray-700 pb-2 mb-4">Configuration</h4>
                    <dl class="space-y-3 text-sm">
                        <div class="flex justify-between">
                            <dt class="text-gray-500 dark:text-gray-400">Winners to draw:</dt>
                            <dd class="font-medium text-gray-900 dark:text-white"><?= $giveaway['number_of_winners'] ?></dd>
                        </div>
                        <div class="flex justify-between">
                            <dt class="text-gray-500 dark:text-gray-400">Reserve winners:</dt>
                            <dd class="font-medium text-gray-900 dark:text-white"><?= $giveaway['reserve_winners'] ?></dd>
                        </div>
                        <div class="flex flex-col mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                            <dt class="text-gray-500 dark:text-gray-400 mb-1">Active Rules:</dt>
                            <dd class="text-gray-900 dark:text-gray-300">
                                <?php $rules = json_decode($giveaway['rules_json'], true); ?>
                                <ul class="list-disc pl-5 space-y-1 mt-2 text-xs">
                                    <?php if (!empty($rules['one_entry_per_user'])): ?><li>One Entry Per User</li><?php endif; ?>
                                    <?php if (!empty($rules['ignore_replies'])): ?><li>Ignore Replies</li><?php endif; ?>
                                    <?php if (!empty($rules['required_keyword'])): ?><li>Keyword: <strong><?= htmlspecialchars($rules['required_keyword']) ?></strong></li><?php endif; ?>
                                </ul>
                            </dd>
                        </div>
                    </dl>
                </div>
            </div>
        </div>

        <!-- Participants Tab -->
        <div x-show="tab === 'participants'" x-cloak>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">No participants</h3>
                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">Sync comments from Facebook first to generate the participant list.</p>
                <div class="mt-6">
                    <button type="button" @click="tab = 'overview'" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-blue-700">
                        Go to Overview
                    </button>
                </div>
            </div>
        </div>

        <!-- Draw Engine Tab -->
        <div x-show="tab === 'draw'" x-cloak>
            
            <div class="bg-yellow-50 dark:bg-yellow-900/30 border-l-4 border-yellow-400 p-4 mb-8">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-yellow-700 dark:text-yellow-500">
                            <strong>Action Required:</strong> You must <strong>Freeze Participants</strong> before you can generate the winners. This creates an immutable snapshot of the data.
                        </p>
                    </div>
                </div>
            </div>

            <div class="flex flex-col items-center justify-center p-10 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl bg-gray-50 dark:bg-gray-800">
                <?php if ($giveaway['status'] === 'active'): ?>
                <form action="<?= APP_URL ?>/giveaways/freeze/<?= $giveaway['id'] ?>" method="POST">
                    <button type="submit" onclick="return confirm('Are you sure you want to freeze participants? This action cannot be undone.')" class="px-8 py-4 bg-primary text-white text-lg font-bold rounded-lg shadow-md hover:bg-blue-700 transition-colors flex items-center">
                        <svg class="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                        Freeze Participants & Lock Giveaway
                    </button>
                </form>
                <p class="mt-4 text-sm text-gray-500 text-center max-w-lg">
                    Once frozen, no more comments can be imported and rules cannot be changed. This ensures cryptographic fairness.
                </p>
                <?php elseif ($giveaway['status'] === 'frozen'): ?>
                <div class="text-center">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-500 mb-4">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-2">Participants Frozen</h3>
                    <p class="text-gray-500 dark:text-gray-400 mb-6">A cryptographic snapshot has been generated. You are ready to draw the winners.</p>
                    <a href="<?= APP_URL ?>/giveaways/draw/<?= $giveaway['id'] ?>" class="inline-flex items-center px-6 py-3 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-green-600 hover:bg-green-700">
                        Proceed to Draw Room
                    </a>
                </div>
                <?php elseif ($giveaway['status'] === 'completed'): ?>
                <div class="text-center">
                    <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-2">Draw Completed</h3>
                    <a href="<?= APP_URL ?>/giveaways/draw/<?= $giveaway['id'] ?>" class="inline-flex items-center px-6 py-3 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700">
                        View Winners
                    </a>
                </div>
                <?php else: ?>
                <button type="button" disabled class="px-8 py-4 bg-gray-400 text-white text-lg font-bold rounded-lg shadow-md cursor-not-allowed opacity-50 flex items-center">
                    <svg class="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                    Freeze Participants & Lock Giveaway
                </button>
                <p class="mt-4 text-sm text-gray-500 text-center max-w-lg">
                    You need to import participants and have an 'active' giveaway status before freezing.
                </p>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include APP_PATH . '/Views/layouts/app.php';
?>

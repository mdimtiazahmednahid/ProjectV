<?php ob_start(); ?>
<div class="flex justify-between items-center mb-6">
    <div>
        <h3 class="text-2xl font-medium text-gray-700 dark:text-white">Giveaways</h3>
        <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Manage your Facebook giveaway campaigns</p>
    </div>
    <a href="<?= APP_URL ?>/giveaways/create" class="px-4 py-2 bg-primary text-white rounded-md hover:bg-blue-600 transition-colors flex items-center">
        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
        Create Giveaway
    </a>
</div>

<div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="min-w-full leading-normal">
            <thead>
                <tr>
                    <th class="px-5 py-3 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-900 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">
                        Giveaway
                    </th>
                    <th class="px-5 py-3 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-900 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">
                        Prize
                    </th>
                    <th class="px-5 py-3 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-900 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">
                        Status
                    </th>
                    <th class="px-5 py-3 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-900 text-left text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">
                        Created
                    </th>
                    <th class="px-5 py-3 border-b-2 border-gray-200 dark:border-gray-700 bg-gray-100 dark:bg-gray-900 text-right text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($giveaways)): ?>
                <tr>
                    <td colspan="5" class="px-5 py-10 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm text-center text-gray-500 dark:text-gray-400">
                        No giveaways found. Create your first one to get started!
                    </td>
                </tr>
                <?php else: ?>
                    <?php foreach ($giveaways as $g): ?>
                    <tr>
                        <td class="px-5 py-5 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                            <div class="flex items-center">
                                <div class="ml-3">
                                    <p class="text-gray-900 dark:text-gray-200 font-semibold whitespace-no-wrap">
                                        <?= htmlspecialchars($g['title']) ?>
                                    </p>
                                    <a href="<?= htmlspecialchars($g['facebook_post_url']) ?>" target="_blank" class="text-blue-500 hover:underline text-xs flex items-center mt-1">
                                        <svg class="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm3 8h-1.35c-.538 0-.65.221-.65.778v1.222h2l-.209 2h-1.791v7h-3v-7h-2v-2h2v-2.308c0-1.769.931-2.692 3.029-2.692h1.971v3z"/></svg>
                                        View Post
                                    </a>
                                </div>
                            </div>
                        </td>
                        <td class="px-5 py-5 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                            <p class="text-gray-900 dark:text-gray-200 whitespace-no-wrap"><?= htmlspecialchars($g['prize']) ?></p>
                            <p class="text-gray-500 text-xs mt-1"><?= $g['number_of_winners'] ?> Winners</p>
                        </td>
                        <td class="px-5 py-5 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                            <?php
                            $statusClasses = [
                                'draft' => 'bg-gray-200 text-gray-800',
                                'active' => 'bg-green-200 text-green-800',
                                'frozen' => 'bg-blue-200 text-blue-800',
                                'completed' => 'bg-purple-200 text-purple-800',
                                'archived' => 'bg-red-200 text-red-800'
                            ];
                            $cls = $statusClasses[$g['status']] ?? 'bg-gray-200 text-gray-800';
                            ?>
                            <span class="relative inline-block px-3 py-1 font-semibold <?= $cls ?> rounded-full text-xs">
                                <span class="relative"><?= ucfirst($g['status']) ?></span>
                            </span>
                        </td>
                        <td class="px-5 py-5 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm">
                            <p class="text-gray-900 dark:text-gray-200 whitespace-no-wrap">
                                <?= date('M d, Y', strtotime($g['created_at'])) ?>
                            </p>
                        </td>
                        <td class="px-5 py-5 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm text-right">
                            <a href="<?= APP_URL ?>/giveaways/<?= $g['id'] ?>" class="text-primary hover:text-blue-800 inline-block">
                                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-md text-sm transition-colors hover:bg-blue-200">Manage</span>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php
$content = ob_get_clean();
include APP_PATH . '/Views/layouts/app.php';
?>

<?php ob_start(); ?>
<div class="mb-6 flex items-center">
    <a href="<?= APP_URL ?>/giveaways" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mr-4">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
    </a>
    <div>
        <h3 class="text-2xl font-medium text-gray-700 dark:text-white">Create New Giveaway</h3>
        <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Setup the parameters for your Facebook giveaway</p>
    </div>
</div>

<form action="<?= APP_URL ?>/giveaways/create" method="POST" class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 lg:p-8 border border-gray-200 dark:border-gray-700 max-w-4xl">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token ?? '') ?>">
    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Basic Info -->
        <div class="col-span-1 md:col-span-2">
            <h4 class="text-lg font-semibold text-gray-800 dark:text-gray-200 border-b dark:border-gray-700 pb-2 mb-4">Basic Information</h4>
        </div>
        
        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Giveaway Title *</label>
            <input type="text" name="title" required class="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-primary focus:border-primary" placeholder="e.g. Summer iPhone Giveaway">
        </div>
        
        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Prize *</label>
            <input type="text" name="prize" required class="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-primary focus:border-primary" placeholder="e.g. iPhone 15 Pro">
        </div>
        
        <div class="col-span-1 md:col-span-2">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Description</label>
            <textarea name="description" rows="3" class="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-primary focus:border-primary" placeholder="Internal notes or public description..."></textarea>
        </div>

        <!-- Facebook Integration -->
        <div class="col-span-1 md:col-span-2 mt-4">
            <h4 class="text-lg font-semibold text-gray-800 dark:text-gray-200 border-b dark:border-gray-700 pb-2 mb-4">Facebook Post</h4>
        </div>
        
        <div class="col-span-1 md:col-span-2">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Facebook Post URL *</label>
            <input type="url" name="facebook_post_url" required class="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-primary focus:border-primary" placeholder="https://www.facebook.com/yourpage/posts/123456789">
            <p class="text-xs text-gray-500 mt-1">Paste the direct URL to the Facebook post where users are commenting.</p>
        </div>

        <!-- Draw Parameters -->
        <div class="col-span-1 md:col-span-2 mt-4">
            <h4 class="text-lg font-semibold text-gray-800 dark:text-gray-200 border-b dark:border-gray-700 pb-2 mb-4">Draw Parameters</h4>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Number of Winners *</label>
            <input type="number" min="1" value="1" name="number_of_winners" required class="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-primary focus:border-primary">
        </div>
        
        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Reserve Winners</label>
            <input type="number" min="0" value="0" name="reserve_winners" class="w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-primary focus:border-primary">
            <p class="text-xs text-gray-500 mt-1">Backup winners in case main winners are disqualified.</p>
        </div>

        <!-- Entry Rules -->
        <div class="col-span-1 md:col-span-2 mt-4">
            <h4 class="text-lg font-semibold text-gray-800 dark:text-gray-200 border-b dark:border-gray-700 pb-2 mb-4">Entry Rules & Filters</h4>
            
            <div class="space-y-3 mt-4">
                <label class="flex items-center">
                    <input type="checkbox" name="rule_one_entry" value="1" checked class="w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded focus:ring-primary dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                    <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">One Entry Per User (Ignore multiple comments)</span>
                </label>
                
                <label class="flex items-center">
                    <input type="checkbox" name="rule_ignore_replies" value="1" checked class="w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded focus:ring-primary dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                    <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">Ignore Replies (Only top-level comments count)</span>
                </label>
            </div>
            
            <div class="mt-4">
                <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Required Keyword (Optional)</label>
                <input type="text" name="rule_keyword" class="w-full md:w-1/2 px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-primary focus:border-primary" placeholder="e.g. WIN">
                <p class="text-xs text-gray-500 mt-1">If set, only comments containing this word will be eligible.</p>
            </div>
        </div>
        
    </div>
    
    <div class="mt-8 pt-5 border-t border-gray-200 dark:border-gray-700 flex justify-end">
        <a href="<?= APP_URL ?>/giveaways" class="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 mr-4 transition-colors">Cancel</a>
        <button type="submit" class="px-6 py-2 bg-primary text-white rounded-md hover:bg-blue-600 transition-colors shadow-sm font-medium">Create Giveaway</button>
    </div>
</form>

<?php
$content = ob_get_clean();
include APP_PATH . '/Views/layouts/app.php';
?>

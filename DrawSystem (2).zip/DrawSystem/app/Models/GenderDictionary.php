<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GenderDictionary extends Model
{
    //
}

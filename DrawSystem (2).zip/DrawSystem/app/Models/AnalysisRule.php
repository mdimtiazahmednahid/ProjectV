<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AnalysisRule extends Model
{
    //
}

<?php
namespace App\Models;

use App\Core\Database;
use PDO;

class Admin {
    public static function findByEmail($email) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("SELECT a.*, r.name as role_name FROM admins a JOIN roles r ON a.role_id = r.id WHERE a.email = :email LIMIT 1");
        $stmt->execute(['email' => $email]);
        return $stmt->fetch();
    }

    public static function updateLastLogin($id) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("UPDATE admins SET last_login = NOW() WHERE id = :id");
        $stmt->execute(['id' => $id]);
    }
}

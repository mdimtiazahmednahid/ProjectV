<?php
// app/Config/routes.php

// Define routes using the router instance
/** @var \App\Core\Router $router */

$router->add('GET', '/', 'HomeController@index');
$router->add('GET', '/login', 'AuthController@login');
$router->add('POST', '/login', 'AuthController@authenticate');
$router->add('GET', '/logout', 'AuthController@logout');
$router->add('GET', '/dashboard', 'DashboardController@index');

// Giveaways
$router->add('GET', '/giveaways', 'GiveawayController@index');
$router->add('GET', '/giveaways/create', 'GiveawayController@create');
$router->add('POST', '/giveaways/create', 'GiveawayController@store');
$router->add('GET', '/giveaways/{id}', 'GiveawayController@show');
$router->add('POST', '/giveaways/import/{id}', 'GiveawayController@import');
$router->add('POST', '/giveaways/freeze/{id}', 'GiveawayController@freeze');
$router->add('GET', '/giveaways/draw/{id}', 'GiveawayController@drawUI');
$router->add('POST', '/giveaways/draw/{id}', 'GiveawayController@executeDraw');

// Public Verification
$router->add('GET', '/verify/{id}', 'VerificationController@show');

// Additional routes for giveaways, facebook import, etc. will go here.

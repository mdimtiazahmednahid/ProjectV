<?php
// app/Config/config.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'fairdraw_db');

define('APP_URL', 'http://localhost/DrawSystem/public');
define('APP_NAME', 'FairDraw');

// Security
define('CSRF_TOKEN_SECRET', 'SuperSecretToken_ChangeMeInProd');

<?php

namespace App\Http\Controllers;

use App\Models\Giveaway;
use Illuminate\Http\Request;

class GiveawayController extends Controller
{
    public function index()
    {
        $giveaways = Giveaway::withCount('participants')->latest()->get();
        return view('dashboard', compact('giveaways'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'source_url' => 'nullable|url',
            'wrong_keyword' => 'nullable|string|max:255'
        ]);

        Giveaway::create($validated);
        return redirect()->route('dashboard')->with('success', 'Giveaway created successfully!');
    }

    public function show(Giveaway $giveaway, Request $request)
    {
        $giveaway->loadCount('participants');
        $search = $request->query('search');
        $filter = $request->query('filter');
        
        $participants = $giveaway->participants()
            ->when($search, function ($query, $search) {
                $query->where(function($q) use ($search) {
                    $q->where('name', 'like', "%{$search}%")
                      ->orWhere('comment', 'like', "%{$search}%");
                });
            })
            ->when($filter === 'no_comments', function ($query) {
                $query->where(function($q) {
                    $q->whereNull('comment')
                      ->orWhere('comment', '')
                      ->orWhere('comment', 'No comment');
                });
            })
            ->when($filter === 'duplicates', function ($query) use ($giveaway) {
                $query->whereIn('name', function($q) use ($giveaway) {
                    $q->select('name')
                      ->from('participants')
                      ->where('giveaway_id', $giveaway->id)
                      ->groupBy('name')
                      ->havingRaw('COUNT(*) > 1');
                });
            })
            ->orderBy('name')
            ->paginate(50)
            ->withQueryString();

        return view('giveaway', compact('giveaway', 'participants', 'search', 'filter'));
    }

    public function destroy(Giveaway $giveaway)
    {
        $giveaway->delete();
        return redirect()->route('dashboard')->with('success', 'Giveaway deleted!');
    }

    public function bulkDestroy(Request $request)
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:giveaways,id'
        ]);

        Giveaway::whereIn('id', $request->ids)->delete();

        return response()->json(['success' => true]);
    }

    public function updateUrl(Request $request, Giveaway $giveaway)
    {
        $validated = $request->validate([
            'source_url' => 'nullable|url'
        ]);

        $giveaway->update($validated);

        return response()->json(['success' => true, 'source_url' => $giveaway->source_url]);
    }

    public function updateTitle(Request $request, Giveaway $giveaway)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255'
        ]);

        $giveaway->update($validated);

        return response()->json(['success' => true, 'title' => $giveaway->title]);
    }

    public function updateSettings(Request $request, Giveaway $giveaway)
    {
        $validated = $request->validate([
            'number_of_winners' => 'nullable|integer|min:1|max:10',
            'spin_duration' => 'required|integer|min:1|max:60',
            'required_keyword' => 'nullable|string|max:255',
            'wrong_keyword' => 'nullable|string|max:255',
            'custom_title' => 'nullable|string|max:255',
            'custom_subtitle' => 'nullable|string|max:255',
            'custom_winner_title' => 'nullable|string|max:255',
            'custom_logo_file' => 'nullable|image|max:2048',
            'custom_background_file' => 'nullable|image|max:5120',
            'grab_replies' => 'nullable|boolean',
            'grab_profile_url' => 'nullable|boolean',
            'grab_profile_pic' => 'nullable|boolean',
            'grab_comment_time' => 'nullable|boolean',
            'exact_keyword' => 'nullable|string|max:255',
            'exact_wrong_keyword' => 'nullable|string|max:255',
        ]);

        $validated['grab_replies'] = $request->has('grab_replies');
        $validated['grab_profile_url'] = $request->has('grab_profile_url');
        $validated['grab_profile_pic'] = $request->has('grab_profile_pic');
        $validated['grab_comment_time'] = $request->has('grab_comment_time');

        if ($request->hasFile('custom_logo_file')) {
            $path = $request->file('custom_logo_file')->store('assets', 'public');
            $validated['custom_logo_url'] = $path;
        }

        if ($request->hasFile('custom_background_file')) {
            $path = $request->file('custom_background_file')->store('assets', 'public');
            $validated['custom_background_url'] = $path;
        }

        unset($validated['custom_logo_file'], $validated['custom_background_file']);

        // Default to 1 if not set
        if (!isset($validated['number_of_winners'])) {
            $validated['number_of_winners'] = 1;
        }

        $giveaway->update($validated);
        
        return redirect()->back()->with('success', 'Settings updated successfully!');
    }
}

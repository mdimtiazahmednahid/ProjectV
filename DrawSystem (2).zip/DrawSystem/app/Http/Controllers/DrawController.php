<?php

namespace App\Http\Controllers;

use App\Models\Giveaway;
use App\Models\Participant;
use App\Models\Winner;
use App\Services\WinnerSelectionService;
use Illuminate\Http\Request;

class DrawController extends Controller
{
    public function show(Giveaway $giveaway)
    {
        $participantCount = $giveaway->participants()->where('is_eligible', true)->count();
        if ($participantCount === 0) {
            return redirect()->route('giveaways.show', $giveaway)->with('error', 'No eligible participants to draw from!');
        }
        
        return view('draw', compact('giveaway', 'participantCount'));
    }

    public function summary(Request $request, Giveaway $giveaway, WinnerSelectionService $selectionService)
    {
        try {
            $keyword = $request->input('keyword');
            $summary = $selectionService->getEligibilitySummary($giveaway, $keyword, $giveaway->wrong_keyword);
            
            $query = $giveaway->participants()->where('is_eligible', true);
            
            $exactKeyword = $giveaway->exact_keyword;
            if (!empty($exactKeyword)) {
                $exactKeywords = array_filter(array_map('trim', explode(',', $exactKeyword)));
                if (!empty($exactKeywords)) {
                    $query->where(function($q) use ($exactKeywords) {
                        foreach ($exactKeywords as $ekw) {
                            $q->orWhere('comment', $ekw);
                        }
                    });
                }
            } elseif (!empty($keyword)) {
                $keywords = array_filter(array_map('trim', explode(',', $keyword)));
                if (!empty($keywords)) {
                    $query->where(function($q) use ($keywords) {
                        foreach ($keywords as $kw) {
                            $q->orWhere('comment', 'LIKE', '%' . $kw . '%');
                        }
                    });
                }
            }
            
            $exactWrongKeyword = $giveaway->exact_wrong_keyword;
            if (!empty($exactWrongKeyword)) {
                $exactWrongKeywords = array_filter(array_map('trim', explode(',', $exactWrongKeyword)));
                if (!empty($exactWrongKeywords)) {
                    $query->where(function($q) use ($exactWrongKeywords) {
                        foreach ($exactWrongKeywords as $ewkw) {
                            $q->where('comment', '!=', $ewkw);
                        }
                    });
                }
            } else {
                $wrongKeyword = $giveaway->wrong_keyword;
                if (!empty($wrongKeyword)) {
                    $wrongKeywords = array_filter(array_map('trim', explode(',', $wrongKeyword)));
                    if (!empty($wrongKeywords)) {
                        $query->where(function($q) use ($wrongKeywords) {
                            foreach ($wrongKeywords as $wkw) {
                                $q->where('comment', 'NOT LIKE', '%' . $wkw . '%');
                            }
                        });
                    }
                }
            }

            $participants = (clone $query)->inRandomOrder()->limit(200)->get(['id', 'name', 'profile_pic_url', 'comment']);

            return response()->json([
                'success' => true,
                'summary' => $summary,
                'participants' => $participants
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 400);
        }
    }

    public function start(Request $request, Giveaway $giveaway, WinnerSelectionService $selectionService)
    {
        try {
            $keyword = $request->input('keyword');
            $wrongKeyword = $giveaway->wrong_keyword;
            $numberOfWinners = $giveaway->number_of_winners ?? 1;
            $winners = $selectionService->selectWinners($giveaway, $keyword, $wrongKeyword, $numberOfWinners);
            
            $winnerIds = [];
            // Autosave the winners immediately
            foreach ($winners as $winner) {
                $selectionService->saveWinner($giveaway, $winner);
                $winnerIds[] = $winner->id;
            }
            
            // Generate some fake decoy names for the slot machine to spin through
            $decoysQuery = $giveaway->participants()
                ->where('is_eligible', true)
                ->whereNotIn('id', $winnerIds);
                
            $exactKeyword = $giveaway->exact_keyword;
            if (!empty($exactKeyword)) {
                $exactKeywords = array_filter(array_map('trim', explode(',', $exactKeyword)));
                if (!empty($exactKeywords)) {
                    $decoysQuery->where(function($q) use ($exactKeywords) {
                        foreach ($exactKeywords as $ekw) {
                            $q->orWhere('comment', $ekw);
                        }
                    });
                }
            } elseif (!empty($keyword)) {
                $keywords = array_filter(array_map('trim', explode(',', $keyword)));
                if (!empty($keywords)) {
                    $decoysQuery->where(function($q) use ($keywords) {
                        foreach ($keywords as $kw) {
                            $q->orWhere('comment', 'LIKE', '%' . $kw . '%');
                        }
                    });
                }
            }

            $exactWrongKeyword = $giveaway->exact_wrong_keyword;
            if (!empty($exactWrongKeyword)) {
                $exactWrongKeywords = array_filter(array_map('trim', explode(',', $exactWrongKeyword)));
                if (!empty($exactWrongKeywords)) {
                    $decoysQuery->where(function($q) use ($exactWrongKeywords) {
                        foreach ($exactWrongKeywords as $ewkw) {
                            $q->where('comment', '!=', $ewkw);
                        }
                    });
                }
            } else {
                if (!empty($wrongKeyword)) {
                    $wrongKeywords = array_filter(array_map('trim', explode(',', $wrongKeyword)));
                    if (!empty($wrongKeywords)) {
                        $decoysQuery->where(function($q) use ($wrongKeywords) {
                            foreach ($wrongKeywords as $wkw) {
                                $q->where('comment', 'NOT LIKE', '%' . $wkw . '%');
                            }
                        });
                    }
                }
            }
            $totalEligible = (clone $decoysQuery)->count();
            $limit = max(50, (int)($totalEligible * 0.70));
            if ($limit > 200) $limit = 200;
            
            $decoys = (clone $decoysQuery)->inRandomOrder()->limit($limit)->get(['name', 'profile_pic_url']);

            return response()->json([
                'success' => true,
                'winners' => $winners,
                'decoys' => $decoys
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 400);
        }
    }

    public function save(Request $request, Giveaway $giveaway, WinnerSelectionService $selectionService)
    {
        $request->validate(['participant_id' => 'required|exists:participants,id']);
        
        $participant = Participant::findOrFail($request->participant_id);
        
        if ($participant->giveaway_id !== $giveaway->id) {
            return response()->json(['success' => false, 'error' => 'Invalid participant'], 403);
        }

        $selectionService->saveWinner($giveaway, $participant);
        
        return response()->json(['success' => true]);
    }

    public function winners()
    {
        $winners = Winner::with(['giveaway', 'participant'])->latest('selected_at')->paginate(20);
        return view('winners', compact('winners'));
    }

    public function card(Winner $winner)
    {
        $winner->load(['giveaway', 'participant']);
        return view('winner_card', compact('winner'));
    }

    public function destroyWinner(Winner $winner)
    {
        $winner->delete();
        return back()->with('success', 'Winner deleted successfully.');
    }
}

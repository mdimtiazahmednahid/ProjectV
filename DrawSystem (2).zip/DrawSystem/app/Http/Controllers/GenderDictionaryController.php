<?php

namespace App\Http\Controllers;

use App\Models\GenderDictionary;
use Illuminate\Http\Request;

class GenderDictionaryController extends Controller
{
    public function index()
    {
        return response()->json(GenderDictionary::orderBy('keyword')->get());
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'keyword' => 'required|string|unique:gender_dictionaries,keyword',
            'gender' => 'required|in:male,female'
        ]);

        $validated['keyword'] = strtolower(trim($validated['keyword']));

        $entry = GenderDictionary::create($validated);
        return response()->json(['success' => true, 'entry' => $entry]);
    }

    public function destroy(GenderDictionary $dictionary)
    {
        $dictionary->delete();
        return response()->json(['success' => true]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Giveaway;
use App\Models\Participant;
use App\Models\AnalysisRule;
use Illuminate\Http\Request;

class AnalyzerController extends Controller
{
    public function index()
    {
        $giveaways = Giveaway::latest()->get();
        return view('analyzer', compact('giveaways'));
    }

    public function fetchData(Request $request)
    {
        ini_set('memory_limit', '2048M');
        $request->validate([
            'giveaway_ids' => 'required|array',
            'giveaway_ids.*' => 'exists:giveaways,id'
        ]);

        $participants = Participant::whereIn('giveaway_id', $request->giveaway_ids)
                                   ->with('giveaway:id,title')
                                   ->get()
                                   ->map(function ($p) {
                                       return [
                                           'id' => $p->id,
                                           'giveaway_title' => $p->giveaway->title ?? 'Unknown',
                                           'name' => $p->name,
                                           'comment' => $p->comment,
                                           'gender' => $p->gender,
                                           'comment_time' => $p->comment_time,
                                           'profile_url' => $p->profile_url,
                                           'is_eligible' => $p->is_eligible,
                                       ];
                                   });

        return response()->json($participants);
    }

    public function getRules()
    {
        return response()->json(AnalysisRule::all());
    }

    public function saveRule(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string',
            'type' => 'required|string',
            'config' => 'required|array'
        ]);

        $rule = AnalysisRule::create([
            'name' => $validated['name'],
            'type' => $validated['type'],
            'config' => json_encode($validated['config'])
        ]);

        return response()->json(['success' => true, 'rule' => $rule]);
    }
    
    public function deleteRule(AnalysisRule $rule)
    {
        $rule->delete();
        return response()->json(['success' => true]);
    }
}

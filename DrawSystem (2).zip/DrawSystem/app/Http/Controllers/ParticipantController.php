<?php

namespace App\Http\Controllers;

use App\Models\Giveaway;
use App\Models\Participant;
use App\Services\ParticipantImportService;
use Illuminate\Http\Request;

class ParticipantController extends Controller
{
    public function import(Request $request, Giveaway $giveaway, ParticipantImportService $importService)
    {
        $request->validate([
            'file' => 'required|file|max:10240', // 10MB max
        ]);

        $file = $request->file('file');
        
        // Store the file permanently in storage/app/imports
        $filename = date('Y-m-d_H-i-s') . '_' . $file->getClientOriginalName();
        $path = $file->storeAs("imports/giveaway_{$giveaway->id}", $filename, 'local');
        
        $content = \Illuminate\Support\Facades\Storage::disk('local')->get($path);
        $extension = strtolower($file->getClientOriginalExtension());

        try {
            if ($extension === 'json') {
                $count = $importService->importFromJson($giveaway, $content);
            } else {
                $count = $importService->importFromCsv($giveaway, $content);
            }
            return redirect()->route('giveaways.show', $giveaway)->with('success', "Imported $count participants successfully!");
        } catch (\Exception $e) {
            return back()->with('error', 'Import failed: ' . $e->getMessage());
        }
    }

    public function destroy(Participant $participant)
    {
        $giveaway_id = $participant->giveaway_id;
        $participant->delete();
        return redirect()->route('giveaways.show', $giveaway_id)->with('success', 'Participant removed.');
    }

    public function syncFromExtension(Request $request, Giveaway $giveaway, ParticipantImportService $importService)
    {
        $request->validate([
            'participants' => 'required|array',
            'participants.*.name' => 'required|string',
            'participants.*.comment' => 'nullable|string',
            'participants.*.profile_url' => 'nullable|string',
            'participants.*.profile_pic_url' => 'nullable|string',
            'participants.*.comment_time' => 'nullable|string',
            'mode' => 'nullable|string'
        ]);

        try {
            if ($request->input('mode') === 'paste') {
                $count = $importService->blindBulkInsert($giveaway, $request->participants);
                return response()->json(['success' => true, 'count' => $count, 'updated' => 0]);
            } else {
                $result = $importService->bulkInsert($giveaway, $request->participants);
                return response()->json(['success' => true, 'count' => $result['new'], 'updated' => $result['updated']]);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function disqualify(Participant $participant)
    {
        $participant->update(['is_eligible' => false]);
        \App\Models\Winner::where('participant_id', $participant->id)->delete();
        return response()->json(['success' => true]);
    }

    public function update(Request $request, Participant $participant)
    {
        $validated = $request->validate([
            'comment' => 'nullable|string',
        ]);

        $participant->update($validated);
        
        return response()->json([
            'success' => true,
            'comment' => $participant->comment ?: 'No comment'
        ]);
    }

    public function getAll(Giveaway $giveaway)
    {
        ini_set('memory_limit', '1024M');
        $participants = $giveaway->participants()
            ->select('id', 'name', 'comment', 'comment_time', 'profile_url', 'profile_pic_url', 'is_eligible')
            ->orderBy('name')
            ->toBase()
            ->get();
            
        return response()->json([
            'success' => true,
            'participants' => $participants
        ]);
    }

    public function storeApi(Request $request, Giveaway $giveaway)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'comment' => 'nullable|string',
            'profile_url' => 'nullable|string',
            'profile_pic_url' => 'nullable|string',
            'comment_time' => 'nullable|string',
        ]);

        $participant = $giveaway->participants()->create($validated);

        return response()->json([
            'success' => true,
            'participant' => $participant
        ]);
    }

    public function updateApi(Request $request, Participant $participant)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'comment' => 'nullable|string',
            'profile_url' => 'nullable|string',
            'comment_time' => 'nullable|string',
        ]);

        $participant->update($validated);

        return response()->json([
            'success' => true,
            'participant' => $participant
        ]);
    }

    public function updateGender(Request $request, Participant $participant)
    {
        $request->validate(['gender' => 'required|in:male,female,unknown']);
        $participant->update(['gender' => $request->gender]);
        return response()->json(['success' => true]);
    }

    public function destroyApi(Participant $participant)
    {
        $participant->delete();
        return response()->json([
            'success' => true
        ]);
    }

    public function bulkDestroy(Request $request)
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:participants,id'
        ]);

        Participant::whereIn('id', $request->ids)->delete();

        return response()->json(['success' => true]);
    }

    public function bulkDisqualify(Request $request)
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:participants,id',
            'is_eligible' => 'required|boolean'
        ]);

        Participant::whereIn('id', $request->ids)->update([
            'is_eligible' => $request->is_eligible
        ]);

        return response()->json(['success' => true]);
    }

    public function bulkCleanDuplicates(Request $request)
    {
        $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:participants,id'
        ]);

        // Order by ID descending so the first one we see is the "latest"
        $participants = Participant::whereIn('id', $request->ids)->orderByDesc('id')->get();
        
        $seen = [];
        $deletedCount = 0;
        
        foreach ($participants as $p) {
            // Group by name since Facebook profile_urls often contain unique comment_ids
            $key = strtolower(trim($p->name));
            if (!$key) continue;
            
            if (isset($seen[$key])) {
                // We've already seen the latest one, so this is an older duplicate
                $p->delete();
                $deletedCount++;
            } else {
                // First time seeing this person, this is the latest one
                $seen[$key] = true;
            }
        }

        return response()->json([
            'success' => true,
            'message' => "Cleaned $deletedCount older duplicate(s) from selection."
        ]);
    }

    public function bulkMerge(Request $request)
    {
        $request->validate([
            'ids' => 'required|array|min:2',
            'ids.*' => 'exists:participants,id'
        ]);

        $participants = Participant::whereIn('id', $request->ids)->orderBy('id')->get();
        
        if ($participants->count() < 2) {
            return response()->json(['success' => false, 'message' => 'Need at least two participants to merge.']);
        }

        $master = $participants->first();
        $mergedComments = [$master->comment];
        
        $others = $participants->slice(1);
        foreach ($others as $other) {
            if ($other->comment && !in_array($other->comment, $mergedComments)) {
                $mergedComments[] = $other->comment;
            }
            $other->delete();
        }

        $mergedComments = array_filter($mergedComments);
        $master->update([
            'comment' => implode("\n", $mergedComments)
        ]);

        return response()->json(['success' => true]);
    }
}

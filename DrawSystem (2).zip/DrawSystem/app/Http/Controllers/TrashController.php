<?php

namespace App\Http\Controllers;

use App\Models\Giveaway;
use App\Models\Participant;
use Illuminate\Http\Request;

class TrashController extends Controller
{
    /**
     * Display soft-deleted giveaways and participants.
     * Auto-purge items in trash for more than 30 days.
     */
    public function index()
    {
        // 30-day auto purge logic
        $purgeLimit = now()->subDays(30);
        
        // Delete permanently old soft-deleted participants first, then giveaways
        Participant::onlyTrashed()->where('deleted_at', '<', $purgeLimit)->forceDelete();
        Giveaway::onlyTrashed()->where('deleted_at', '<', $purgeLimit)->forceDelete();

        $trashedGiveaways = Giveaway::onlyTrashed()->latest('deleted_at')->get();
        $trashedParticipants = Participant::onlyTrashed()->with('giveaway')->latest('deleted_at')->get();

        return view('trash', compact('trashedGiveaways', 'trashedParticipants'));
    }

    /**
     * Restore a soft-deleted giveaway.
     */
    public function restoreGiveaway(int $id)
    {
        $giveaway = Giveaway::onlyTrashed()->findOrFail($id);
        $giveaway->restore();

        // Also restore its soft-deleted participants that were deleted with it
        Participant::onlyTrashed()
            ->where('giveaway_id', $giveaway->id)
            ->restore();

        return redirect()->route('trash.index')->with('success', 'Giveaway and its participants restored successfully.');
    }

    /**
     * Permanently delete a soft-deleted giveaway.
     */
    public function forceDeleteGiveaway(int $id)
    {
        $giveaway = Giveaway::onlyTrashed()->findOrFail($id);
        $giveaway->forceDelete();

        return redirect()->route('trash.index')->with('success', 'Giveaway permanently deleted.');
    }

    /**
     * Restore a soft-deleted participant.
     */
    public function restoreParticipant(int $id)
    {
        $participant = Participant::onlyTrashed()->findOrFail($id);
        
        // If the parent giveaway is soft-deleted, restore it too
        $parent = $participant->giveaway()->withTrashed()->first();
        if ($parent && $parent->trashed()) {
            $parent->restore();
        }

        $participant->restore();

        return redirect()->route('trash.index')->with('success', 'Participant restored successfully.');
    }

    /**
     * Permanently delete a soft-deleted participant.
     */
    public function forceDeleteParticipant(int $id)
    {
        $participant = Participant::onlyTrashed()->findOrFail($id);
        $participant->forceDelete();

        return redirect()->route('trash.index')->with('success', 'Participant permanently deleted.');
    }

    /**
     * Empty all trash.
     */
    public function empty()
    {
        Participant::onlyTrashed()->forceDelete();
        Giveaway::onlyTrashed()->forceDelete();
        
        return redirect()->route('trash.index')->with('success', 'Trash box emptied successfully.');
    }
    /**
     * Restore all trash.
     */
    public function restoreAll()
    {
        Giveaway::onlyTrashed()->restore();
        Participant::onlyTrashed()->restore();
        
        return redirect()->route('trash.index')->with('success', 'All items restored successfully.');
    }
}

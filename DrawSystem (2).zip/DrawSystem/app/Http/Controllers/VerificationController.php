<?php

namespace App\Http\Controllers;

use App\Models\Giveaway;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class VerificationController extends Controller
{
    public function show(string $id)
    {
        $giveaway = Giveaway::find($id);
        
        if (!$giveaway) {
            abort(404, "Giveaway not found.");
        }
        
        // Fetch draw details
        $draw = DB::table('draws')->where('giveaway_id', $id)->orderBy('id', 'desc')->first();
        
        $winners = [];
        $snapshot = null;
        
        if ($draw) {
            $winners = DB::table('winners as w')
                ->join('participants as p', 'w.participant_id', '=', 'p.id')
                ->where('w.draw_id', $draw->id)
                ->orderBy('w.position', 'asc')
                ->select('p.facebook_name', 'w.is_reserve', 'w.position')
                ->get()
                ->toArray();
                
            $snapshot = DB::table('participant_snapshots')
                ->where('id', $draw->participant_snapshot_id)
                ->first();
        }

        return view('verification.show', [
            'title' => 'Transparency Verification: ' . $giveaway->title,
            'giveaway' => $giveaway,
            'draw' => $draw,
            'winners' => collect($winners)->map(fn($w) => (array)$w)->toArray(),
            'snapshot' => (array)$snapshot
        ]);
    }
}

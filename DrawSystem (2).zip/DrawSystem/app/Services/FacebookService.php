<?php
namespace App\Services;

use App\Core\Database;
use PDO;

class FacebookService {
    private $accessToken;
    private $db;

    public function __construct($accessToken = null) {
        $this->accessToken = $accessToken;
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * In a production environment, this calls the Meta Graph API.
     * Example endpoint: https://graph.facebook.com/v20.0/{post-id}/comments?access_token={token}
     */
    public function fetchComments($giveawayId, $postId) {
        // Since we don't have a real Meta App token in this environment,
        // we simulate importing comments to demonstrate the architecture.
        
        $mockComments = $this->generateMockComments($postId, 50); // Generate 50 mock comments
        
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare("
                INSERT IGNORE INTO facebook_comments 
                (id, giveaway_id, post_id, parent_id, user_id, user_name, message, created_time, permalink_url, reaction_count, mention_count)
                VALUES 
                (:id, :giveaway_id, :post_id, :parent_id, :user_id, :user_name, :message, :created_time, :permalink_url, :reaction_count, :mention_count)
            ");

            foreach ($mockComments as $comment) {
                $stmt->execute([
                    'id' => $comment['id'],
                    'giveaway_id' => $giveawayId,
                    'post_id' => $postId,
                    'parent_id' => $comment['parent_id'],
                    'user_id' => $comment['user_id'],
                    'user_name' => $comment['user_name'],
                    'message' => $comment['message'],
                    'created_time' => $comment['created_time'],
                    'permalink_url' => $comment['permalink_url'],
                    'reaction_count' => $comment['reaction_count'],
                    'mention_count' => $comment['mention_count']
                ]);
            }
            $this->db->commit();
            return count($mockComments);
        } catch (\Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    private function generateMockComments($postId, $count) {
        $comments = [];
        $words = ['Great!', 'I want to WIN', 'Awesome giveaway', 'Count me in', 'WIN WIN WIN', 'Love this page', 'Hope I win'];
        
        for ($i = 0; $i < $count; $i++) {
            $isReply = (rand(1, 10) > 8); // 20% chance to be a reply
            $parentId = $isReply ? $postId . '_' . rand(1, $i) : null;
            
            $comments[] = [
                'id' => $postId . '_' . ($i + 1),
                'parent_id' => $parentId,
                'user_id' => 'USER_' . rand(10000, 99999),
                'user_name' => 'MockUser ' . rand(1, 100),
                'message' => $words[array_rand($words)],
                'created_time' => date('Y-m-d H:i:s', time() - rand(0, 86400)),
                'permalink_url' => "https://facebook.com/{$postId}/comments/" . ($i + 1),
                'reaction_count' => rand(0, 10),
                'mention_count' => rand(0, 2)
            ];
        }
        return $comments;
    }
}

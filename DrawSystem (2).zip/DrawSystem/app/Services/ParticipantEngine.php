<?php
namespace App\Services;

use App\Core\Database;
use PDO;

class ParticipantEngine {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Freeze the participant list to make it immutable.
     */
    public function freeze($giveawayId, $adminId) {
        // Fetch eligible participants
        $stmt = $this->db->prepare("SELECT id, facebook_user_id, facebook_name FROM participants WHERE giveaway_id = :giveaway_id AND is_eligible = 1 ORDER BY id ASC");
        $stmt->execute(['giveaway_id' => $giveawayId]);
        $eligible = $stmt->fetchAll();

        // Fetch total count
        $stmtTotal = $this->db->prepare("SELECT COUNT(id) FROM participants WHERE giveaway_id = :giveaway_id");
        $stmtTotal->execute(['giveaway_id' => $giveawayId]);
        $totalCount = $stmtTotal->fetchColumn();

        $eligibleCount = count($eligible);
        $snapshotData = json_encode($eligible);
        
        // Generate SHA-256 hash
        $snapshotHash = hash('sha256', $snapshotData);

        $this->db->beginTransaction();
        try {
            // Save snapshot
            $snapshotStmt = $this->db->prepare("
                INSERT INTO participant_snapshots (giveaway_id, admin_id, total_participants, eligible_count, snapshot_hash, snapshot_data)
                VALUES (:giveaway_id, :admin_id, :total_participants, :eligible_count, :snapshot_hash, :snapshot_data)
            ");
            $snapshotStmt->execute([
                'giveaway_id' => $giveawayId,
                'admin_id' => $adminId,
                'total_participants' => $totalCount,
                'eligible_count' => $eligibleCount,
                'snapshot_hash' => $snapshotHash,
                'snapshot_data' => $snapshotData
            ]);

            // Update giveaway status to frozen
            $updateStmt = $this->db->prepare("UPDATE giveaways SET status = 'frozen' WHERE id = :id");
            $updateStmt->execute(['id' => $giveawayId]);

            // Audit log
            $auditStmt = $this->db->prepare("
                INSERT INTO audit_logs (admin_id, giveaway_id, action, description, ip_address, browser_user_agent)
                VALUES (:admin_id, :giveaway_id, 'Freeze Participants', 'Generated immutable snapshot with hash: ' . :hash, :ip, :agent)
            ");
            $auditStmt->execute([
                'admin_id' => $adminId,
                'giveaway_id' => $giveawayId,
                'hash' => $snapshotHash,
                'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                'agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
            ]);

            $this->db->commit();
            return true;
        } catch (\Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}

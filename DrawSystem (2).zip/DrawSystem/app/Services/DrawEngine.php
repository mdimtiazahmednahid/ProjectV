<?php
namespace App\Services;

use App\Core\Database;
use PDO;

class DrawEngine {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function execute($giveawayId, $adminId) {
        $stmt = $this->db->prepare("SELECT * FROM giveaways WHERE id = :id");
        $stmt->execute(['id' => $giveawayId]);
        $giveaway = $stmt->fetch();

        if ($giveaway['status'] !== 'frozen') {
            throw new \Exception("Giveaway is not frozen.");
        }

        $stmt = $this->db->prepare("SELECT * FROM participant_snapshots WHERE giveaway_id = :giveaway_id ORDER BY id DESC LIMIT 1");
        $stmt->execute(['giveaway_id' => $giveawayId]);
        $snapshot = $stmt->fetch();

        if (!$snapshot) {
            throw new \Exception("No participant snapshot found.");
        }

        $participants = json_decode($snapshot['snapshot_data'], true);
        if (empty($participants)) {
            throw new \Exception("No eligible participants to draw from.");
        }

        // Generate cryptographically secure random seed (32 bytes)
        $seed = bin2hex(random_bytes(32));

        // Perform Deterministic Fisher-Yates shuffle
        $shuffled = $this->deterministicFisherYates($participants, $seed);

        $numWinners = (int)$giveaway['number_of_winners'];
        $numReserves = (int)$giveaway['reserve_winners'];
        $totalToDraw = $numWinners + $numReserves;

        $winners = array_slice($shuffled, 0, $totalToDraw);

        $this->db->beginTransaction();
        try {
            // Record Draw
            $drawStmt = $this->db->prepare("
                INSERT INTO draws (giveaway_id, admin_id, seed, participant_snapshot_id, algorithm, software_version, status)
                VALUES (:giveaway_id, :admin_id, :seed, :snapshot_id, 'Fisher-Yates (SHA256 PRNG)', '1.0.0', 'completed')
            ");
            $drawStmt->execute([
                'giveaway_id' => $giveawayId,
                'admin_id' => $adminId,
                'seed' => $seed,
                'snapshot_id' => $snapshot['id']
            ]);
            
            $drawId = $this->db->lastInsertId();

            // Record Winners
            $winStmt = $this->db->prepare("
                INSERT INTO winners (draw_id, participant_id, is_reserve, position, status)
                VALUES (:draw_id, :participant_id, :is_reserve, :position, 'pending')
            ");

            foreach ($winners as $index => $w) {
                $isReserve = ($index >= $numWinners) ? 1 : 0;
                $winStmt->execute([
                    'draw_id' => $drawId,
                    'participant_id' => $w['id'],
                    'is_reserve' => $isReserve,
                    'position' => $index + 1
                ]);
            }

            // Update Giveaway Status
            $updStmt = $this->db->prepare("UPDATE giveaways SET status = 'completed' WHERE id = :id");
            $updStmt->execute(['id' => $giveawayId]);

            // Audit
            $auditStmt = $this->db->prepare("
                INSERT INTO audit_logs (admin_id, giveaway_id, action, description, ip_address, browser_user_agent)
                VALUES (:admin_id, :giveaway_id, 'Draw Executed', 'Selected winners using seed: ' . :seed, :ip, :agent)
            ");
            $auditStmt->execute([
                'admin_id' => $adminId,
                'giveaway_id' => $giveawayId,
                'seed' => $seed,
                'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                'agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
            ]);

            $this->db->commit();
            return $drawId;
        } catch (\Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * A deterministic PRNG based Fisher-Yates shuffle using SHA-256 HMAC
     * to ensure reproducibility given the same seed and array.
     */
    private function deterministicFisherYates($array, $seedHex) {
        $n = count($array);
        $counter = 0;
        
        for ($i = $n - 1; $i > 0; $i--) {
            // Generate deterministic pseudo-random integer between 0 and $i
            // We use HMAC-SHA256 with the seed and a counter
            $hash = hash_hmac('sha256', (string)$counter, $seedHex);
            
            // Convert first 8 hex chars (32-bit) to an integer
            $randInt = hexdec(substr($hash, 0, 8));
            
            $j = $randInt % ($i + 1);
            
            // Swap
            $temp = $array[$i];
            $array[$i] = $array[$j];
            $array[$j] = $temp;
            
            $counter++;
        }
        
        return $array;
    }
}

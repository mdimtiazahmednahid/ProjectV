<?php
namespace App\Services;

use App\Core\Database;
use PDO;

class RuleEngine {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Process raw facebook_comments and populate the participants table
     * applying all the rules specified in the giveaway configuration.
     */
    public function applyRules($giveawayId) {
        // Fetch giveaway rules
        $stmt = $this->db->prepare("SELECT rules_json FROM giveaways WHERE id = :id");
        $stmt->execute(['id' => $giveawayId]);
        $giveaway = $stmt->fetch();
        
        if (!$giveaway) return false;
        
        $rules = json_decode($giveaway['rules_json'], true);
        
        // Fetch raw comments
        $stmt = $this->db->prepare("SELECT * FROM facebook_comments WHERE giveaway_id = :giveaway_id");
        $stmt->execute(['giveaway_id' => $giveawayId]);
        $comments = $stmt->fetchAll();

        // Clear existing participants to re-evaluate
        $stmt = $this->db->prepare("DELETE FROM participants WHERE giveaway_id = :giveaway_id");
        $stmt->execute(['giveaway_id' => $giveawayId]);

        $participantsMap = [];

        foreach ($comments as $comment) {
            $isEligible = 1;
            $excludedReason = null;

            // Rule: Ignore Replies
            if (!empty($rules['ignore_replies']) && $comment['parent_id'] !== null) {
                $isEligible = 0;
                $excludedReason = 'Is a reply';
            }

            // Rule: Required Keyword
            if ($isEligible && !empty($rules['required_keyword'])) {
                if (stripos($comment['message'], $rules['required_keyword']) === false) {
                    $isEligible = 0;
                    $excludedReason = 'Missing required keyword';
                }
            }

            // Rule: One Entry Per User
            if (!empty($rules['one_entry_per_user'])) {
                $userId = $comment['user_id'];
                if (isset($participantsMap[$userId])) {
                    $participantsMap[$userId]['comment_count']++;
                    // Only record the exclusion if the new comment would have been eligible
                    // Actually, for one entry per user, we just don't add duplicate entries.
                    continue; 
                }
            }

            $participantsMap[$comment['user_id']] = [
                'facebook_user_id' => $comment['user_id'],
                'facebook_name' => $comment['user_name'],
                'comment_count' => 1,
                'is_eligible' => $isEligible,
                'excluded_reason' => $excludedReason
            ];
        }

        // Insert into participants table
        $this->db->beginTransaction();
        try {
            $insertStmt = $this->db->prepare("
                INSERT INTO participants (giveaway_id, facebook_user_id, facebook_name, comment_count, is_eligible, excluded_reason)
                VALUES (:giveaway_id, :facebook_user_id, :facebook_name, :comment_count, :is_eligible, :excluded_reason)
            ");

            foreach ($participantsMap as $p) {
                $insertStmt->execute([
                    'giveaway_id' => $giveawayId,
                    'facebook_user_id' => $p['facebook_user_id'],
                    'facebook_name' => $p['facebook_name'],
                    'comment_count' => $p['comment_count'],
                    'is_eligible' => $p['is_eligible'],
                    'excluded_reason' => $p['excluded_reason']
                ]);
            }
            $this->db->commit();
            return true;
        } catch (\Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}

<?php

namespace App\Services;

use App\Models\Giveaway;
use Illuminate\Support\Facades\DB;

class ParticipantImportService
{
    /**
     * Import participants from a JSON file path or JSON string
     */
    public function importFromJson(Giveaway $giveaway, string $jsonContent): int
    {
        $data = json_decode($jsonContent, true);
        
        if (!is_array($data)) {
            throw new \Exception("Invalid JSON format");
        }

        $result = $this->bulkInsert($giveaway, $data);
        return $result['new'] + $result['updated'];
    }

    /**
     * Import participants from a CSV string
     */
    public function importFromCsv(Giveaway $giveaway, string $csvContent): int
    {
        $stream = fopen('php://memory', 'r+');
        fwrite($stream, trim($csvContent));
        rewind($stream);
        
        $rows = [];
        while (($row = fgetcsv($stream)) !== false) {
            $rows[] = $row;
        }
        fclose($stream);
        
        if (empty($rows)) {
            return 0;
        }

        // Assuming first row is header
        $header = array_shift($rows);
        $headerLower = array_map('strtolower', $header);
        
        $nameIndex = array_search('name', $headerLower);
        $commentIndex = array_search('comment', $headerLower);
        
        $timeIndex = array_search('comment_time', $headerLower);
        if ($timeIndex === false) $timeIndex = array_search('time', $headerLower);
        if ($timeIndex === false) $timeIndex = array_search('date', $headerLower);
        
        $profileUrlIndex = array_search('profile url', $headerLower);
        if ($profileUrlIndex === false) $profileUrlIndex = array_search('profile_url', $headerLower);
        
        $avatarIndex = array_search('avatar url', $headerLower);
        if ($avatarIndex === false) $avatarIndex = array_search('profile_pic_url', $headerLower);

        // If 'name' is not found in header, it might not be a header row
        if ($nameIndex === false) {
            // Put the row back since it's probably data
            array_unshift($rows, $header);
            $nameIndex = 0; // fallback to first column
            $commentIndex = 1;
        }

        $data = [];
        foreach ($rows as $row) {
            if (empty(trim($row[0] ?? ''))) continue;
            
            $data[] = [
                'name' => $row[$nameIndex] ?? 'Unknown',
                'comment' => $row[$commentIndex] ?? '',
                'comment_time' => ($timeIndex !== false && isset($row[$timeIndex])) ? trim($row[$timeIndex]) : null,
                'profile_url' => ($profileUrlIndex !== false && isset($row[$profileUrlIndex])) ? trim($row[$profileUrlIndex]) : null,
                'profile_pic_url' => ($avatarIndex !== false && isset($row[$avatarIndex])) ? trim($row[$avatarIndex]) : null,
            ];
        }

        $result = $this->bulkInsert($giveaway, $data);
        return $result['new'] + $result['updated'];
    }

    protected ?\Illuminate\Support\Collection $genderRules = null;

    protected function getGenderRules(): \Illuminate\Support\Collection
    {
        if ($this->genderRules === null) {
            $this->genderRules = DB::table('gender_dictionaries')->get();
        }
        return $this->genderRules;
    }

    protected function guessGender(string $name): string
    {
        $rules = $this->getGenderRules();
        $nameLower = strtolower(trim($name));
        $tokens = preg_split('/[\s\.]+/', $nameLower, -1, PREG_SPLIT_NO_EMPTY);
        
        foreach ($rules as $rule) {
            $cleanKeyword = strtolower(trim($rule->keyword, '. '));
            if (in_array($cleanKeyword, $tokens)) {
                return $rule->gender;
            }
        }
        return 'unknown';
    }

    /**
     * Efficiently bulk insert participants
     */
    public function bulkInsert(Giveaway $giveaway, array $data): array
    {
        return DB::transaction(function () use ($giveaway, $data) {
            $insertData = [];
            $now = now();
            $newCount = 0;
            $updateCount = 0;

            // Preload gender rules
            $this->getGenderRules();

            // Fetch existing participants to map their IDs
            $existing = DB::table('participants')
                ->where('giveaway_id', $giveaway->id)
                ->select('id', 'name', 'comment', 'profile_url')
                ->get();
                
            $existingMap = [];
            foreach ($existing as $p) {
                $key = $p->name . '|' . ($p->profile_url ?: '') . '|' . $p->comment;
                $existingMap[$key] = $p->id;
            }

            foreach ($data as $item) {
                $name = $item['name'] ?? 'Unknown';
                if (mb_strlen($name) > 250) {
                    $name = mb_substr($name, 0, 250) . '...';
                }
                
                $comment = $item['comment'] ?? '';
                $profileUrl = $item['profile_url'] ?? '';
                
                $key = $name . '|' . $profileUrl . '|' . $comment;
                
                // If participant & comment already exists, update their profile picture and time
                if (isset($existingMap[$key])) {
                    $existingId = $existingMap[$key];
                    
                    // If it's -1, it means we already added/updated it in THIS batch payload, skip duplicates within batch
                    if ($existingId !== -1) {
                        DB::table('participants')->where('id', $existingId)->update([
                            'comment_time' => $item['comment_time'] ?? null,
                            'profile_pic_url' => $item['profile_pic_url'] ?? null,
                            'updated_at' => $now,
                            'deleted_at' => null, // Restore if it was soft-deleted
                        ]);
                        $updateCount++;
                        // Mark as -1 so we don't update it again if the pasted payload has duplicate entries of it
                        $existingMap[$key] = -1;
                    }
                    continue;
                }
                
                // Mark as -1 in map to prevent duplicates within the same batch payload
                $existingMap[$key] = -1;
                
                $insertData[] = [
                    'giveaway_id' => $giveaway->id,
                    'name' => $name,
                    'comment' => $comment,
                    'comment_time' => $item['comment_time'] ?? null,
                    'profile_url' => $profileUrl,
                    'profile_pic_url' => $item['profile_pic_url'] ?? null,
                    'gender' => $this->guessGender($name),
                    'is_eligible' => true,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];

                $newCount++;

                // Chunk inserts for high performance
                if (count($insertData) >= 1000) {
                    DB::table('participants')->insert($insertData);
                    $insertData = [];
                }
            }

            if (count($insertData) > 0) {
                DB::table('participants')->insert($insertData);
            }

            // We return the separate counts for UI clarity
            return ['new' => $newCount, 'updated' => $updateCount];
        });
    }

    /**
     * Blindly insert participants without checking for duplicates.
     */
    public function blindBulkInsert(Giveaway $giveaway, array $data): int
    {
        return DB::transaction(function () use ($giveaway, $data) {
            $insertData = [];
            $now = now();
            $count = 0;
            
            // Preload gender rules
            $this->getGenderRules();

            foreach ($data as $item) {
                $name = $item['name'] ?? 'Unknown';
                if (mb_strlen($name) > 250) {
                    $name = mb_substr($name, 0, 250) . '...';
                }
                
                $insertData[] = [
                    'giveaway_id' => $giveaway->id,
                    'name' => $name,
                    'comment' => $item['comment'] ?? '',
                    'comment_time' => $item['comment_time'] ?? null,
                    'profile_url' => $item['profile_url'] ?? '',
                    'profile_pic_url' => $item['profile_pic_url'] ?? null,
                    'gender' => $this->guessGender($name),
                    'is_eligible' => true,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];

                $count++;

                if (count($insertData) >= 1000) {
                    DB::table('participants')->insert($insertData);
                    $insertData = [];
                }
            }

            if (count($insertData) > 0) {
                DB::table('participants')->insert($insertData);
            }

            return $count;
        });
    }
}

<?php

namespace App\Services;

use App\Models\Giveaway;
use App\Models\Participant;
use App\Models\Winner;

class WinnerSelectionService
{
    /**
     * Select multiple random winners securely and efficiently without loading all rows into memory
     */
    public function selectWinners(Giveaway $giveaway, ?string $keyword = null, ?string $wrongKeyword = null, int $numberOfWinners = 1): array
    {
        $query = $giveaway->participants()->where('is_eligible', true);
        
        $exactKeyword = $giveaway->exact_keyword;
        if (!empty($exactKeyword)) {
            $exactKeywords = array_filter(array_map('trim', explode(',', $exactKeyword)));
            if (!empty($exactKeywords)) {
                $query->where(function($q) use ($exactKeywords) {
                    foreach ($exactKeywords as $ekw) {
                        $q->orWhere('comment', $ekw);
                    }
                });
            }
        } elseif (!empty($keyword)) {
            $keywords = array_filter(array_map('trim', explode(',', $keyword)));
            if (!empty($keywords)) {
                $query->where(function($q) use ($keywords) {
                    foreach ($keywords as $kw) {
                        $q->orWhere('comment', 'LIKE', '%' . $kw . '%');
                    }
                });
            }
        }

        $exactWrongKeyword = $giveaway->exact_wrong_keyword;
        if (!empty($exactWrongKeyword)) {
            $exactWrongKeywords = array_filter(array_map('trim', explode(',', $exactWrongKeyword)));
            if (!empty($exactWrongKeywords)) {
                $query->where(function($q) use ($exactWrongKeywords) {
                    foreach ($exactWrongKeywords as $ewkw) {
                        $q->where('comment', '!=', $ewkw);
                    }
                });
            }
        } elseif (!empty($wrongKeyword)) {
            $wrongKeywords = array_filter(array_map('trim', explode(',', $wrongKeyword)));
            if (!empty($wrongKeywords)) {
                $query->where(function($q) use ($wrongKeywords) {
                    foreach ($wrongKeywords as $wkw) {
                        $q->where('comment', 'NOT LIKE', '%' . $wkw . '%');
                    }
                });
            }
        }
        
        $count = $query->count();
        if ($count === 0) {
            throw new \Exception('No eligible participants found' . (!empty($keyword) ? ' matching that answer.' : ' for this giveaway.'));
        }

        if ($numberOfWinners > $count) {
            $numberOfWinners = $count;
        }

        $winners = [];
        // Determine the chunk size for each winner
        $chunkSize = floor($count / $numberOfWinners);
        
        for ($i = 0; $i < $numberOfWinners; $i++) {
            $startOffset = $i * $chunkSize;
            $endOffset = ($i == $numberOfWinners - 1) ? $count - 1 : ($startOffset + $chunkSize - 1);
            
            if ($startOffset > $endOffset) {
                $endOffset = $startOffset;
            }

            $randomOffset = random_int($startOffset, $endOffset);
            
            $winner = (clone $query)->orderBy('id')->skip($randomOffset)->first();
            
            if ($winner) {
                $winners[] = $winner;
            }
        }

        if (empty($winners)) {
            throw new \Exception('Failed to retrieve winners.');
        }

        return $winners;
    }

    public function getEligibilitySummary(Giveaway $giveaway, ?string $keyword = null, ?string $wrongKeyword = null): array
    {
        $total = $giveaway->participants()->count();
        $disqualified = $giveaway->participants()->where('is_eligible', false)->count();

        // Calculate qualified
        $query = $giveaway->participants()->where('is_eligible', true);
        
        $exactKeyword = $giveaway->exact_keyword;
        if (!empty($exactKeyword)) {
            $exactKeywords = array_filter(array_map('trim', explode(',', $exactKeyword)));
            if (!empty($exactKeywords)) {
                $query->where(function($q) use ($exactKeywords) {
                    foreach ($exactKeywords as $ekw) {
                        $q->orWhere('comment', $ekw);
                    }
                });
            }
        } elseif (!empty($keyword)) {
            $keywords = array_filter(array_map('trim', explode(',', $keyword)));
            if (!empty($keywords)) {
                $query->where(function($q) use ($keywords) {
                    foreach ($keywords as $kw) {
                        $q->orWhere('comment', 'LIKE', '%' . $kw . '%');
                    }
                });
            }
        }

        $exactWrongKeyword = $giveaway->exact_wrong_keyword;
        if (!empty($exactWrongKeyword)) {
            $exactWrongKeywords = array_filter(array_map('trim', explode(',', $exactWrongKeyword)));
            if (!empty($exactWrongKeywords)) {
                $query->where(function($q) use ($exactWrongKeywords) {
                    foreach ($exactWrongKeywords as $ewkw) {
                        $q->where('comment', '!=', $ewkw);
                    }
                });
            }
        } elseif (!empty($wrongKeyword)) {
            $wrongKeywords = array_filter(array_map('trim', explode(',', $wrongKeyword)));
            if (!empty($wrongKeywords)) {
                $query->where(function($q) use ($wrongKeywords) {
                    foreach ($wrongKeywords as $wkw) {
                        $q->where('comment', 'NOT LIKE', '%' . $wkw . '%');
                    }
                });
            }
        }

        $qualified = $query->count();
        $invalid = $total - $disqualified - $qualified;

        return [
            'total' => $total,
            'disqualified' => $disqualified,
            'qualified' => $qualified,
            'invalid' => $invalid < 0 ? 0 : $invalid
        ];
    }

    /**
     * Save the winner record
     */
    public function saveWinner(Giveaway $giveaway, Participant $participant): Winner
    {
        return Winner::create([
            'giveaway_id' => $giveaway->id,
            'participant_id' => $participant->id,
            'winner_name' => $participant->name,
            'winner_comment' => $participant->comment,
            'selected_at' => now(),
        ]);
    }
}

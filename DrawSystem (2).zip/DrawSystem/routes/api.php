<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ParticipantController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::post('/giveaways/{giveaway}/bookmarklet-sync', [ParticipantController::class, 'syncFromExtension']);

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GiveawayController;
use App\Http\Controllers\ParticipantController;
use App\Http\Controllers\DrawController;
use App\Http\Controllers\TrashController;
use App\Http\Controllers\GenderDictionaryController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AnalyzerController;

Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware(['auth'])->group(function () {
    Route::get('/', [GiveawayController::class, 'index'])->name('dashboard');
Route::post('/giveaways', [GiveawayController::class, 'store'])->name('giveaways.store');
Route::get('/giveaways/{giveaway}', [GiveawayController::class, 'show'])->name('giveaways.show');
Route::delete('/giveaways/{giveaway}', [GiveawayController::class, 'destroy'])->name('giveaways.destroy');
Route::post('/giveaways/bulk-delete', [GiveawayController::class, 'bulkDestroy'])->name('giveaways.bulkDestroy');
Route::put('/giveaways/{giveaway}/update-url', [GiveawayController::class, 'updateUrl'])->name('giveaways.updateUrl');
Route::put('/giveaways/{giveaway}/update-title', [GiveawayController::class, 'updateTitle'])->name('giveaways.updateTitle');

Route::post('/participants/import/{giveaway}', [ParticipantController::class, 'import'])->name('participants.import');
Route::delete('/participants/{participant}', [ParticipantController::class, 'destroy'])->name('participants.destroy');
Route::put('/participants/{participant}', [ParticipantController::class, 'update'])->name('participants.update');
Route::post('/participants/{participant}/disqualify', [ParticipantController::class, 'disqualify'])->name('participants.disqualify');

Route::post('/giveaways/{giveaway}/settings', [GiveawayController::class, 'updateSettings'])->name('giveaways.settings');

Route::get('/draw/{giveaway}', [DrawController::class, 'show'])->name('draw.show');
Route::post('/draw/summary/{giveaway}', [DrawController::class, 'summary'])->name('draw.summary');
Route::post('/draw/start/{giveaway}', [DrawController::class, 'start'])->name('draw.start');
Route::post('/draw/save/{giveaway}', [DrawController::class, 'save'])->name('draw.save');

Route::get('/winners', [DrawController::class, 'winners'])->name('winners.index');
Route::get('/winners/{winner}/card', [DrawController::class, 'card'])->name('winners.card');
Route::delete('/winners/{winner}', [DrawController::class, 'destroyWinner'])->name('winners.destroy');

// Trash routes
Route::get('/trash', [TrashController::class, 'index'])->name('trash.index');
Route::post('/trash/restore/giveaway/{id}', [TrashController::class, 'restoreGiveaway'])->name('trash.restoreGiveaway');
Route::delete('/trash/force-delete/giveaway/{id}', [TrashController::class, 'forceDeleteGiveaway'])->name('trash.forceDeleteGiveaway');
Route::post('/trash/restore/participant/{id}', [TrashController::class, 'restoreParticipant'])->name('trash.restoreParticipant');
Route::delete('/trash/force-delete/participant/{id}', [TrashController::class, 'forceDeleteParticipant'])->name('trash.forceDeleteParticipant');
Route::post('/trash/restore-all', [TrashController::class, 'restoreAll'])->name('trash.restoreAll');
Route::delete('/trash/empty', [TrashController::class, 'empty'])->name('trash.empty');

// Gender Dictionary API
Route::get('/gender-dictionary', [GenderDictionaryController::class, 'index'])->name('gender-dictionary.index');
Route::post('/gender-dictionary', [GenderDictionaryController::class, 'store'])->name('gender-dictionary.store');
Route::delete('/gender-dictionary/{dictionary}', [GenderDictionaryController::class, 'destroy'])->name('gender-dictionary.destroy');

// Analyzer Routes
Route::get('/analyzer', [AnalyzerController::class, 'index'])->name('analyzer.index');
Route::post('/analyzer/fetch-data', [AnalyzerController::class, 'fetchData'])->name('analyzer.fetchData');
Route::get('/analyzer/rules', [AnalyzerController::class, 'getRules'])->name('analyzer.rules.index');
Route::post('/analyzer/rules', [AnalyzerController::class, 'saveRule'])->name('analyzer.rules.store');
Route::delete('/analyzer/rules/{rule}', [AnalyzerController::class, 'deleteRule'])->name('analyzer.rules.destroy');

// Bulk actions AJAX routes
Route::post('/participants/bulk-delete', [ParticipantController::class, 'bulkDestroy'])->name('participants.bulkDestroy');
Route::post('/participants/bulk-disqualify', [ParticipantController::class, 'bulkDisqualify'])->name('participants.bulkDisqualify');
Route::post('/participants/bulk-merge', [ParticipantController::class, 'bulkMerge'])->name('participants.bulkMerge');
Route::post('/participants/bulk-clean-duplicates', [ParticipantController::class, 'bulkCleanDuplicates'])->name('participants.bulkCleanDuplicates');

// Spreadsheet AJAX routes
Route::get('/giveaways/{giveaway}/participants/all', [ParticipantController::class, 'getAll'])->name('participants.all');
Route::post('/giveaways/{giveaway}/participants/store', [ParticipantController::class, 'storeApi'])->name('participants.storeApi');
Route::put('/participants/{participant}/update-all', [ParticipantController::class, 'updateApi'])->name('participants.updateApi');
Route::put('/participants/{participant}/update-gender', [ParticipantController::class, 'updateGender'])->name('participants.updateGender');
Route::delete('/participants/{participant}/delete', [ParticipantController::class, 'destroyApi'])->name('participants.destroyApi');
});


<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;

DB::table('winners')->delete();
DB::table('participants')->delete();

DB::table('participants')->insert([
    ['giveaway_id'=>1, 'name'=>'A', 'comment'=>'apple', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
    ['giveaway_id'=>1, 'name'=>'B', 'comment'=>'I love pineapple', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
    ['giveaway_id'=>1, 'name'=>'C', 'comment'=>'an apple a day', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
    ['giveaway_id'=>1, 'name'=>'D', 'comment'=>'apples are great', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
    ['giveaway_id'=>1, 'name'=>'E', 'comment'=>'14', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
    ['giveaway_id'=>1, 'name'=>'F', 'comment'=>'4', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
    ['giveaway_id'=>1, 'name'=>'G', 'comment'=>'The answer is 4.', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
    ['giveaway_id'=>1, 'name'=>'H', 'comment'=>'আমি ভালো আছি', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
    ['giveaway_id'=>1, 'name'=>'I', 'comment'=>'ভালোবাসি', 'is_eligible'=>true, 'created_at'=>now(), 'updated_at'=>now()],
]);

echo "Testing apple (LIKE %apple%):\n";
$res = DB::table('participants')->where('comment', 'LIKE', '%apple%')->pluck('comment')->toArray();
print_r($res);

echo "\nTesting apple (REGEXP \\bapple\\b):\n";
$res = DB::table('participants')->whereRaw('comment REGEXP ?', ['\\bapple\\b'])->pluck('comment')->toArray();
print_r($res);

echo "\nTesting 4 (REGEXP \\b4\\b):\n";
$res = DB::table('participants')->whereRaw('comment REGEXP ?', ['\\b4\\b'])->pluck('comment')->toArray();
print_r($res);

echo "\nTesting ভালো (REGEXP (^|[[:space:][:punct:]])ভালো([[:space:][:punct:]]|$)):\n";
$res = DB::table('participants')->whereRaw('comment REGEXP ?', ['(^|[[:space:][:punct:]])ভালো([[:space:][:punct:]]|$)'])->pluck('comment')->toArray();
print_r($res);


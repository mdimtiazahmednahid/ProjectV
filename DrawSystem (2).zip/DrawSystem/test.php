<?php

$data = ['participants' => []];
for ($i = 0; $i < 1156; $i++) {
    $data['participants'][] = [
        'name' => 'User ' . $i,
        'comment' => 'This is a test comment ' . $i,
        'profile_url' => 'https://facebook.com/' . $i,
        'profile_pic_url' => 'https://facebook.com/pic/' . $i,
        'comment_time' => '1d'
    ];
}

$ch = curl_init('http://127.0.0.1:8000/api/giveaways/1/bookmarklet-sync');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json'
]);

$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpcode\n";
echo "Response: $response\n";

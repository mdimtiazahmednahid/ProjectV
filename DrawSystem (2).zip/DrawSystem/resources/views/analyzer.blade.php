@extends('layouts.app')

@push('styles')
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- ag-Grid CSS -->
    <script src="https://cdn.jsdelivr.net/npm/ag-grid-community/dist/ag-grid-community.min.js"></script>
    <style>
        /* Custom ag-grid dark theme adjustments to match our premium aesthetic */
        .ag-theme-alpine-dark {
            --ag-background-color: rgba(255, 255, 255, 0.03);
            --ag-header-background-color: rgba(0, 0, 0, 0.2);
            --ag-border-color: rgba(255, 255, 255, 0.08);
            --ag-row-border-color: rgba(255, 255, 255, 0.05);
            --ag-font-family: inherit;
            --ag-font-size: 13px;
            --ag-row-hover-color: rgba(0, 166, 81, 0.1);
            --ag-selected-row-background-color: rgba(0, 166, 81, 0.2);
            --ag-header-foreground-color: #9ca3af;
            --ag-data-color: #e5e7eb;
            --ag-control-panel-background-color: transparent;
            border-radius: 1rem;
            overflow: hidden;
            border: 1px solid rgba(255,255,255,0.08);
        }
        .ag-theme-alpine-dark .ag-header-cell-label {
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-size: 11px;
        }
    </style>
@endpush

@section('content')
<div class="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
    <div class="border-l-4 border-blue-500 pl-4">
        <h2 class="text-3xl font-black text-gray-100 tracking-tight flex items-center gap-2">
            <svg class="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
            Global Analyzer
        </h2>
        <p class="text-gray-400 text-sm mt-1">Cross-campaign data analysis, filtering, and custom intelligence rules.</p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-4 gap-6 relative h-[calc(100vh-180px)] min-h-[600px]">
    
    <!-- Left Sidebar: Controls & Rules -->
    <div class="lg:col-span-1 flex flex-col gap-6 h-full overflow-y-auto pr-2 pb-8">
        
        <!-- Campaign Selector -->
        <div class="glass-card rounded-2xl p-5 border border-bdr">
            <h3 class="text-sm font-black uppercase tracking-wider text-blue-400 mb-3 flex items-center gap-2">
                1. Select Campaigns
            </h3>
            <div class="flex flex-col gap-2 max-h-48 overflow-y-auto mb-3 pr-2">
                @foreach($giveaways as $g)
                    <label class="flex items-start gap-3 p-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors border border-transparent hover:border-white/5">
                        <input type="checkbox" value="{{ $g->id }}" class="campaign-checkbox mt-1 rounded border-gray-600 bg-gray-800 text-blue-500 focus:ring-blue-500 focus:ring-offset-gray-900">
                        <div class="flex flex-col">
                            <span class="text-sm font-bold text-gray-200 leading-tight">{{ $g->title }}</span>
                            <span class="text-[10px] text-gray-500">{{ $g->created_at->format('M d, Y') }} &bull; {{ $g->participants()->count() }} entries</span>
                        </div>
                    </label>
                @endforeach
                @if($giveaways->isEmpty())
                    <p class="text-xs text-gray-500 italic p-2">No campaigns available.</p>
                @endif
            </div>
            <button onclick="loadData()" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-xl text-sm transition-all shadow-lg flex items-center justify-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                Load Data
            </button>
        </div>

        <!-- Rule Builder -->
        <div class="glass-card rounded-2xl p-5 border border-bdr flex-1 flex flex-col">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-sm font-black uppercase tracking-wider text-green-400 flex items-center gap-2">
                    2. Analysis Rules
                </h3>
                <button onclick="openRuleModal()" class="text-green-400 hover:text-white bg-green-500/10 hover:bg-green-500 rounded-lg p-1 transition-colors" title="Create Rule">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"></path></svg>
                </button>
            </div>
            
            <p class="text-[11px] text-gray-400 mb-4 leading-relaxed">Apply smart rules to classify or flag data. Rules add temporary columns to the grid based on your logic.</p>

            <div id="active-rules-container" class="flex flex-col gap-2 flex-1 overflow-y-auto pr-1">
                <div class="text-center py-8 text-gray-500 text-xs italic">
                    No rules active.<br>Create a rule to analyze data.
                </div>
            </div>
        </div>

    </div>

    <!-- Right Area: Data Grid & Dashboard -->
    <div class="lg:col-span-3 h-full flex flex-col gap-4 overflow-y-auto pr-2 pb-8">
        
        <!-- Dashboard Panel -->
        <div id="analyzer-dashboard" class="glass-card rounded-2xl p-5 border border-bdr grid grid-cols-1 md:grid-cols-3 gap-6 hidden">
            <!-- Uniqueness Stats -->
            <div class="flex flex-col justify-center gap-2">
                <h4 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">User Uniqueness</h4>
                <div class="flex justify-between items-end border-b border-white/10 pb-2">
                    <span class="text-sm text-gray-300">Total Entries</span>
                    <span id="stat-total" class="text-xl font-black text-white">0</span>
                </div>
                <div class="flex justify-between items-end border-b border-white/10 pb-2">
                    <span class="text-sm text-gray-300">Unique Users</span>
                    <span id="stat-unique" class="text-xl font-black text-blue-400">0</span>
                </div>
                <div class="flex justify-between items-end">
                    <span class="text-sm text-gray-300">Repeated Users</span>
                    <span id="stat-repeated" class="text-xl font-black text-red-400">0</span>
                </div>
            </div>

            <!-- Gender Chart -->
            <div class="h-40 flex flex-col items-center justify-center relative">
                <h4 class="text-xs font-bold text-gray-400 uppercase tracking-wider absolute top-0 left-0">Gender Distribution</h4>
                <div class="w-full h-full pt-6 pb-2 px-2 flex justify-center">
                    <canvas id="genderChart"></canvas>
                </div>
            </div>

            <!-- Sentiment Chart -->
            <div class="h-40 flex flex-col items-center justify-center relative">
                <h4 class="text-xs font-bold text-gray-400 uppercase tracking-wider absolute top-0 left-0">Basic Sentiment</h4>
                <div class="w-full h-full pt-6 pb-2 px-2 flex justify-center">
                    <canvas id="sentimentChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Grid Toolbar -->
        <div class="glass-card rounded-2xl px-5 py-3 border border-bdr flex flex-wrap justify-between items-center gap-4">
            <div class="flex items-center gap-3">
                <span class="text-xs font-bold text-gray-400 uppercase tracking-wider">Loaded Rows:</span>
                <span id="grid-row-count" class="text-lg font-black text-white">0</span>
            </div>
            
            <div class="flex items-center gap-2">
                <div class="relative">
                    <input type="text" id="grid-search" oninput="onGridFilterTextBoxChanged()" placeholder="Quick Search..." class="bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 w-48 transition-all">
                    <svg class="w-4 h-4 text-gray-500 absolute right-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </div>
                <button onclick="exportGridData()" class="bg-white/10 hover:bg-white/20 text-white font-bold py-2 px-4 rounded-xl text-sm transition-all border border-white/10 flex items-center gap-2">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                    Export CSV
                </button>
            </div>
        </div>

        <!-- ag-Grid Container -->
        <div id="myGrid" class="ag-theme-alpine-dark flex-1 shadow-2xl"></div>

    </div>
</div>

<!-- Rule Builder Modal -->
<div id="ruleModal" class="hidden fixed inset-0 bg-gray-900/90 backdrop-blur-md z-[9999] flex items-center justify-center p-4 opacity-0 transition-opacity duration-300">
    <div class="glass-card w-full max-w-lg rounded-3xl p-6 relative border border-bdr bg-gray-900 shadow-2xl transform scale-95 transition-transform duration-300">
        <div class="flex justify-between items-center mb-6 border-b border-white/10 pb-4">
            <h3 class="text-xl font-black text-gray-100 tracking-tight flex items-center gap-2">
                <svg class="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path></svg>
                Create Rule
            </h3>
            <button onclick="closeRuleModal()" class="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        
        <form id="rule-form" onsubmit="saveRule(event)" class="flex flex-col gap-4">
            <div>
                <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Rule Name (Column Header)</label>
                <input type="text" id="rule-name" required placeholder="e.g. Is Spam?" class="w-full bg-white/5 border border-gray-600 rounded-xl px-4 py-2.5 text-sm text-white focus:border-green-500 focus:outline-none transition-colors">
            </div>
            
            <div>
                <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Rule Logic Type</label>
                <select id="rule-type" required onchange="onRuleTypeChange()" class="w-full bg-white/5 border border-gray-600 rounded-xl px-4 py-2.5 text-sm text-white focus:border-green-500 focus:outline-none transition-colors">
                    <option value="">-- Select Type --</option>
                    <option value="keyword_match">Keyword Match (Contains words)</option>
                    <option value="keyword_exact">Exact Match (Strictly exact answer)</option>
                    <option value="keyword_exclude">Keyword Exclude (Does not contain words)</option>
                    <option value="regex_match">Regex Match (Advanced)</option>
                    <option value="length_greater">Comment Length > X</option>
                    <option value="has_tags">Has Mentions (@tags)</option>
                </select>
            </div>
            
            <div id="rule-config-area" class="hidden flex-col gap-4 mt-2 p-4 bg-white/5 rounded-xl border border-white/5">
                <!-- Dynamic config fields injected here -->
            </div>

            <button type="submit" class="mt-4 w-full bg-green-500 hover:bg-green-600 text-white font-black text-sm py-3 rounded-xl transition-all shadow-[0_4px_15px_rgba(34,197,94,0.3)] hover:shadow-[0_6px_20px_rgba(34,197,94,0.4)]">
                Save & Apply Rule
            </button>
        </form>
    </div>
</div>

@endsection

@push('scripts')
<script>
    let gridOptions = null;
    let gridApi = null;
    let allData = [];
    let rules = [];
    let genderChartInst = null;
    let sentimentChartInst = null;

    // Initialize Grid
    document.addEventListener('DOMContentLoaded', () => {
        initGrid();
        loadSavedRules();
    });

    function initGrid() {
        const gridDiv = document.querySelector('#myGrid');
        
        gridOptions = {
            columnDefs: getBaseColumns(),
            defaultColDef: {
                flex: 1,
                minWidth: 100,
                sortable: true,
                filter: true,
                resizable: true,
            },
            rowData: [],
            pagination: true,
            paginationPageSize: 100,
            animateRows: true,
            enableCellTextSelection: true,
            getRowStyle: params => {
                if (!params.data.is_eligible) return { opacity: 0.6, textDecoration: 'line-through' };
            }
        };
        
        gridApi = agGrid.createGrid(gridDiv, gridOptions);
    }

    function getBaseColumns() {
        return [
            { field: 'giveaway_title', headerName: 'Campaign', minWidth: 150 },
            { field: 'name', headerName: 'Participant', minWidth: 150 },
            { field: 'gender', headerName: 'Gender', width: 100, cellRenderer: p => {
                if(p.value === 'male') return '♂ Male';
                if(p.value === 'female') return '♀ Female';
                return '? Unk';
            }},
            { field: 'comment', headerName: 'Comment Text', minWidth: 300, wrapText: true, autoHeight: true },
            { field: 'comment_time', headerName: 'Time', width: 120 },
            { field: 'is_eligible', headerName: 'Eligible', width: 100, cellRenderer: p => p.value ? '✅ Yes' : '❌ No' }
        ];
    }

    function onGridFilterTextBoxChanged() {
        gridApi.setQuickFilter(document.getElementById('grid-search').value);
    }

    function exportGridData() {
        gridApi.exportDataAsCsv({ fileName: 'analysis_export.csv' });
    }

    async function loadData() {
        const checkboxes = document.querySelectorAll('.campaign-checkbox:checked');
        const ids = Array.from(checkboxes).map(c => c.value);
        
        if (ids.length === 0) {
            appAlert('Please select at least one campaign.');
            return;
        }

        const btn = event.currentTarget;
        const originalHtml = btn.innerHTML;
        btn.innerHTML = 'Loading...';
        btn.disabled = true;

        try {
            const res = await fetch('{{ route("analyzer.fetchData") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ giveaway_ids: ids })
            });
            const data = await res.json();
            allData = data;
            
            // Calculate uniqueness strictly by name AND comment
            const uniqueSet = new Set();
            let maleCount = 0, femaleCount = 0, unknownCount = 0;
            let posCount = 0, negCount = 0, neuCount = 0;
            
            const positiveWords = ['good', 'great', 'awesome', 'nice', 'love', 'amazing', 'best', 'excellent', 'fantastic', 'perfect', 'thanks', 'thank you'];
            const negativeWords = ['bad', 'fake', 'scam', 'terrible', 'awful', 'worst', 'hate', 'poor', 'bullshit', 'lie'];

            allData.forEach(row => {
                // Uniqueness
                const uniqueKey = `${(row.name || '').trim().toLowerCase()}|${(row.comment || '').trim().toLowerCase()}`;
                uniqueSet.add(uniqueKey);

                // Gender
                if(row.gender === 'male') maleCount++;
                else if(row.gender === 'female') femaleCount++;
                else unknownCount++;

                // Sentiment
                const text = (row.comment || '').toLowerCase();
                const hasPos = positiveWords.some(w => text.includes(w));
                const hasNeg = negativeWords.some(w => text.includes(w));
                if(hasPos && !hasNeg) posCount++;
                else if(hasNeg && !hasPos) negCount++;
                else neuCount++;
            });

            const totalEntries = allData.length;
            const uniqueCount = uniqueSet.size;
            const repeatedCount = totalEntries - uniqueCount;

            document.getElementById('stat-total').innerText = totalEntries;
            document.getElementById('stat-unique').innerText = uniqueCount;
            document.getElementById('stat-repeated').innerText = repeatedCount;
            document.getElementById('analyzer-dashboard').classList.remove('hidden');

            renderCharts(maleCount, femaleCount, unknownCount, posCount, neuCount, negCount);
            
            // Reapply rules to new data
            applyRulesToData();
            
            gridApi.setGridOption('rowData', allData);
            document.getElementById('grid-row-count').innerText = allData.length;
        } catch(e) {
            appAlert('Error loading data.', 'error');
        } finally {
            btn.innerHTML = originalHtml;
            btn.disabled = false;
        }
    }

    function renderCharts(male, female, unknown, pos, neu, neg) {
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'right', labels: { color: '#9ca3af', font: { size: 10 } } }
            }
        };

        if (genderChartInst) genderChartInst.destroy();
        genderChartInst = new Chart(document.getElementById('genderChart'), {
            type: 'doughnut',
            data: {
                labels: ['Male', 'Female', 'Unknown'],
                datasets: [{
                    data: [male, female, unknown],
                    backgroundColor: ['#3b82f6', '#ec4899', '#4b5563'],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: chartOptions
        });

        if (sentimentChartInst) sentimentChartInst.destroy();
        sentimentChartInst = new Chart(document.getElementById('sentimentChart'), {
            type: 'bar',
            data: {
                labels: ['Positive', 'Neutral', 'Negative'],
                datasets: [{
                    label: 'Comments',
                    data: [pos, neu, neg],
                    backgroundColor: ['#10b981', '#6b7280', '#ef4444'],
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { display: false, beginAtZero: true },
                    x: { ticks: { color: '#9ca3af', font: { size: 10 } }, grid: { display: false } }
                }
            }
        });
    }

    /* ---- Rule Engine ---- */

    async function loadSavedRules() {
        try {
            const res = await fetch('{{ route("analyzer.rules.index") }}');
            rules = await res.json();
            renderActiveRules();
            rebuildColumns();
        } catch(e) {
            console.error('Failed to load rules');
        }
    }

    function renderActiveRules() {
        const container = document.getElementById('active-rules-container');
        if (rules.length === 0) {
            container.innerHTML = '<div class="text-center py-8 text-gray-500 text-xs italic">No rules active.<br>Create a rule to analyze data.</div>';
            return;
        }

        container.innerHTML = '';
        rules.forEach(rule => {
            const div = document.createElement('div');
            div.className = 'bg-white/5 border border-white/10 rounded-xl p-3 flex justify-between items-center group';
            
            const config = JSON.parse(rule.config);
            let desc = rule.type;
            if(rule.type === 'keyword_match') desc = `Contains: ${config.keywords}`;
            if(rule.type === 'keyword_exact') desc = `Exactly: ${config.keywords}`;
            if(rule.type === 'length_greater') desc = `Length > ${config.length}`;
            
            div.innerHTML = `
                <div>
                    <h4 class="text-sm font-bold text-gray-200">${rule.name}</h4>
                    <p class="text-[10px] text-gray-500 uppercase">${desc}</p>
                </div>
                <button onclick="deleteRule(${rule.id})" class="text-red-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-1">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                </button>
            `;
            container.appendChild(div);
        });
    }

    function rebuildColumns() {
        const cols = getBaseColumns();
        rules.forEach(rule => {
            const safeField = 'rule_' + rule.id;
            cols.push({
                field: safeField,
                headerName: rule.name,
                width: 120,
                cellRenderer: p => {
                    if (p.value === undefined) return '';
                    if (typeof p.value === 'boolean') {
                        return p.value ? '<span class="text-green-400 font-bold">TRUE</span>' : '<span class="text-red-400 font-bold opacity-50">FALSE</span>';
                    }
                    return p.value;
                }
            });
        });
        
        if (gridApi) {
            gridApi.setGridOption('columnDefs', cols);
        }
    }

    function applyRulesToData() {
        if (!allData || allData.length === 0) return;
        
        allData.forEach(row => {
            const text = (row.comment || '').toLowerCase();
            
            rules.forEach(rule => {
                const config = JSON.parse(rule.config);
                const safeField = 'rule_' + rule.id;
                let result = false;

                try {
                    switch (rule.type) {
                        case 'keyword_match':
                            const words = config.keywords.toLowerCase().split(',').map(w => w.trim()).filter(w => w);
                            result = words.some(w => text.includes(w));
                            break;
                        case 'keyword_exact':
                            const exactWords = config.keywords.toLowerCase().split(',').map(w => w.trim()).filter(w => w);
                            result = exactWords.some(w => text === w);
                            break;
                        case 'keyword_exclude':
                            const exWords = config.keywords.toLowerCase().split(',').map(w => w.trim()).filter(w => w);
                            result = !exWords.some(w => text.includes(w));
                            break;
                        case 'regex_match':
                            const re = new RegExp(config.regex, 'i');
                            result = re.test(text);
                            break;
                        case 'length_greater':
                            result = text.length > parseInt(config.length || 0);
                            break;
                        case 'has_tags':
                            result = /@[^\s]+/.test(row.comment); // Simple mention check
                            break;
                    }
                } catch(e) {
                    result = 'ERROR';
                }

                row[safeField] = result;
            });
        });
    }

    async function saveRule(e) {
        e.preventDefault();
        
        const name = document.getElementById('rule-name').value;
        const type = document.getElementById('rule-type').value;
        const config = {};

        if (type === 'keyword_match' || type === 'keyword_exact' || type === 'keyword_exclude') {
            config.keywords = document.getElementById('rule-keywords').value;
        } else if (type === 'regex_match') {
            config.regex = document.getElementById('rule-regex').value;
        } else if (type === 'length_greater') {
            config.length = document.getElementById('rule-length').value;
        }

        try {
            const res = await fetch('{{ route("analyzer.rules.store") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ name, type, config })
            });
            const data = await res.json();
            
            if (data.success) {
                rules.push(data.rule);
                closeRuleModal();
                renderActiveRules();
                rebuildColumns();
                applyRulesToData();
                gridApi.setGridOption('rowData', allData); // Refresh grid
            } else {
                appAlert('Validation Error', 'error');
            }
        } catch(err) {
            appAlert('Failed to save rule', 'error');
        }
    }

    async function deleteRule(id) {
        if (!confirm('Delete this rule?')) return;
        
        try {
            await fetch(`/analyzer/rules/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                }
            });
            
            rules = rules.filter(r => r.id !== id);
            
            // Clean up data
            const safeField = 'rule_' + id;
            allData.forEach(row => delete row[safeField]);
            
            renderActiveRules();
            rebuildColumns();
            gridApi.setGridOption('rowData', allData);
        } catch(err) {
            appAlert('Failed to delete rule', 'error');
        }
    }

    /* ---- Modal UI ---- */

    function openRuleModal() {
        const modal = document.getElementById('ruleModal');
        modal.classList.remove('hidden');
        document.getElementById('rule-form').reset();
        onRuleTypeChange();
        setTimeout(() => {
            modal.classList.remove('opacity-0');
            modal.querySelector('.glass-card').classList.remove('scale-95');
        }, 10);
    }

    function closeRuleModal() {
        const modal = document.getElementById('ruleModal');
        modal.classList.add('opacity-0');
        modal.querySelector('.glass-card').classList.add('scale-95');
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 300);
    }

    function onRuleTypeChange() {
        const type = document.getElementById('rule-type').value;
        const area = document.getElementById('rule-config-area');
        area.innerHTML = '';
        
        if (!type) {
            area.classList.add('hidden');
            return;
        }
        
        area.classList.remove('hidden');
        
        if (type === 'keyword_match' || type === 'keyword_exact' || type === 'keyword_exclude') {
            area.innerHTML = `
                <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Keywords (Comma separated)</label>
                <input type="text" id="rule-keywords" required placeholder="e.g. good, best, awesome" class="w-full bg-black/20 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none">
            `;
        } else if (type === 'regex_match') {
            area.innerHTML = `
                <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Regex Pattern</label>
                <input type="text" id="rule-regex" required placeholder="e.g. ^[0-9]+$" class="w-full bg-black/20 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none font-mono">
            `;
        } else if (type === 'length_greater') {
            area.innerHTML = `
                <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Minimum Length</label>
                <input type="number" id="rule-length" required min="1" placeholder="e.g. 50" class="w-full bg-black/20 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-green-500 focus:outline-none">
            `;
        } else if (type === 'has_tags') {
            area.innerHTML = `<p class="text-xs text-gray-400">This rule checks if the comment contains any @mentions. No extra configuration needed.</p>`;
        }
    }
</script>
@endpush

<!DOCTYPE html>
<html lang="en" class="h-full bg-gray-50 dark:bg-gray-900">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ isset($title) ? $title . ' - ' . config('app.name') : config('app.name') }}</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#3b82f6',
                        secondary: '#10b981'
                    },
                    fontFamily: {
                        sans: ['"Hind Siliguri"', '"Avenir Next"', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', 'Helvetica', 'Arial', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        html, body {
            background-color: #005535 !important;
            color: #F8FAF9 !important;
            font-family: "Hind Siliguri", "Avenir Next", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
            min-height: 100vh;
        }
        header, footer {
            background-color: rgba(0, 73, 44, 0.8) !important;
            backdrop-filter: blur(12px);
            border-color: rgba(255, 255, 255, 0.08) !important;
        }
        
        /* Direct CSS overrides for Tailwind light/dark utilities to keep it dark green glassmorphic */
        .text-gray-900, .dark\:text-white, .text-gray-700, .dark\:text-gray-300 { color: #F8FAF9 !important; }
        .text-gray-600, .dark\:text-gray-400, .text-gray-500 { color: #9ca3af !important; }
        
        .bg-white, .dark\:bg-gray-800, .bg-gray-50, .dark\:bg-gray-900 { background-color: rgba(255, 255, 255, 0.03) !important; }
        .bg-gray-100 { background-color: rgba(255, 255, 255, 0.05) !important; }
        .border-gray-200, .dark\:border-gray-700, .border-gray-300 { border-color: rgba(255, 255, 255, 0.08) !important; }
        
        /* Ensure buttons/links with bg-white are solid white with high contrast dark text */
        button.bg-white, a.bg-white {
            background-color: #ffffff !important;
            color: #005535 !important;
            border-color: #ffffff !important;
        }
        button.bg-white:hover, a.bg-white:hover {
            background-color: #f3f8f5 !important;
            color: #00733B !important;
            border-color: #f3f8f5 !important;
        }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: rgba(0, 85, 53, 0.2); }
        ::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.15); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #00A651; }
    </style>
</head>
<body class="h-full bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 flex flex-col">
    <!-- Navbar -->
    <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex">
                    <div class="flex-shrink-0 flex items-center">
                        <span class="text-2xl font-bold text-gray-900 dark:text-white">Vejal Nai | Draw</span>
                    </div>
                </div>
                <div class="flex items-center">
                    <span class="text-sm text-gray-500 dark:text-gray-400">Public Verification System</span>
                </div>
            </div>
        </div>
    </header>

    <main class="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        @yield('content')
    </main>

    <footer class="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 mt-auto">
        <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 text-center text-sm text-gray-500 dark:text-gray-400">
            &copy; {{ date('Y') }} Vejal Nai | Draw. All rights reserved. Cryptographically Secure Winner Selection.
        </div>
    </footer>
</body>
</html>

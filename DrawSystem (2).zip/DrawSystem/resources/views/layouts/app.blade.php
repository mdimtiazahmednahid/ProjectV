<!DOCTYPE html>
<html lang="en" class="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vejal Nai | Draw v1.0 - Vejal Nai Giveaway</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#00A651', // Brand Green
                        primaryDark: '#00733B',
                        primaryDeep: '#015730',
                        bglight: '#005535',
                        bdr: 'rgba(255, 255, 255, 0.08)',
                        mint: '#BDE3D9',
                    },
                    fontFamily: {
                        sans: ['"Hind Siliguri"', '"Avenir Next"', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', 'Helvetica', 'Arial', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        body {
            background-color: #005535;
            color: #F8FAF9;
            font-family: "Hind Siliguri", "Avenir Next", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
        }
        nav {
            background-color: rgba(0, 73, 44, 0.8) !important;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.03) !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            backdrop-filter: blur(12px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            border-radius: 1rem;
        }
        
        /* Direct CSS overrides for Tailwind light mode utilities */
        .text-gray-900 { color: #F8FAF9 !important; }
        .text-gray-800 { color: #f3f4f6 !important; }
        .text-gray-700 { color: #e5e7eb !important; }
        .text-gray-600 { color: #d1d5db !important; }
        .text-gray-500 { color: #9ca3af !important; }
        
        .bg-white { background-color: rgba(255, 255, 255, 0.03) !important; }
        .bg-gray-50 { background-color: rgba(255, 255, 255, 0.02) !important; }
        .bg-gray-100 { background-color: rgba(255, 255, 255, 0.05) !important; }
        .bg-gray-200 { background-color: rgba(255, 255, 255, 0.08) !important; }
        .border-gray-200 { border-color: rgba(255, 255, 255, 0.08) !important; }
        .border-gray-300 { border-color: rgba(255, 255, 255, 0.12) !important; }
        
        /* Ensure buttons/links with bg-white are solid white with high contrast dark text */
        button.bg-white, a.bg-white {
            background-color: #ffffff !important;
            color: #005535 !important;
            border-color: #ffffff !important;
        }
        button.bg-white:hover, a.bg-white:hover {
            background-color: #f3f8f5 !important;
            color: #00733B !important;
            border-color: #f3f8f5 !important;
        }
        
        /* Custom Scrollbar for list */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: rgba(0, 85, 53, 0.2); }
        ::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.15); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: #00A651; }
    </style>
    @stack('styles')
</head>
<body class="antialiased flex flex-col">
    <nav class="sticky top-0 bg-white/80 backdrop-blur-md border-b border-bdr z-50 px-6 py-4">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <div class="flex items-center gap-6">
                <a href="{{ route('dashboard') }}" class="flex items-center gap-2">
                    <span class="text-2xl font-black tracking-tight text-primary">Vejal Nai | Draw</span>
                    <span class="text-[10px] bg-primary/20 text-primary px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">v2.0</span>
                </a>
                <div class="hidden md:flex items-center gap-1">
                    <a href="{{ route('dashboard') }}" class="px-4 py-2 rounded-lg text-sm font-semibold transition-all {{ request()->routeIs('dashboard') || request()->routeIs('giveaways.show') ? 'bg-primary/10 text-primary' : 'text-gray-300 hover:bg-white/5 hover:text-white' }}">
                        Dashboard
                    </a>
                    <a href="{{ route('winners.index') }}" class="px-4 py-2 rounded-lg text-sm font-semibold transition-all {{ request()->routeIs('winners.index') ? 'bg-primary/10 text-primary' : 'text-gray-300 hover:bg-white/5 hover:text-white' }}">
                        Winner History
                    </a>
                    <a href="{{ route('analyzer.index') }}" class="px-4 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-1.5 {{ request()->routeIs('analyzer.*') ? 'bg-blue-500/10 text-blue-400' : 'text-gray-300 hover:bg-white/5 hover:text-white' }}">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                        Global Analyzer
                    </a>
                    @php
                        $trashCount = \App\Models\Giveaway::onlyTrashed()->count() + \App\Models\Participant::onlyTrashed()->count();
                    @endphp
                    <a href="{{ route('trash.index') }}" class="px-4 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-1.5 {{ request()->routeIs('trash.index') ? 'bg-primary/10 text-primary' : 'text-gray-300 hover:bg-white/5 hover:text-white' }}">
                        <span>Trash Box</span>
                        @if($trashCount > 0)
                            <span class="bg-red-500/20 text-red-400 text-[10px] px-1.5 py-0.5 rounded-full font-bold font-mono">{{ $trashCount }}</span>
                        @endif
                    </a>
                    @auth
                    <form method="POST" action="{{ route('logout') }}" class="ml-2 border-l border-white/10 pl-4 flex items-center">
                        @csrf
                        <button type="submit" class="text-sm font-semibold text-red-400 hover:text-red-300 transition-colors">Logout</button>
                    </form>
                    @endauth
                </div>
            </div>
            
            <div class="flex items-center gap-3">
                <span class="text-xs text-gray-400 font-medium uppercase tracking-widest hidden sm:inline-block">Vejal Nai Giveaway Picker</span>
                <!-- Mobile Navigation Menu Toggle -->
                <div class="flex md:hidden items-center gap-1">
                    <a href="{{ route('dashboard') }}" class="p-2 rounded-lg {{ request()->routeIs('dashboard') || request()->routeIs('giveaways.show') ? 'text-primary' : 'text-gray-300' }}">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                    </a>
                    <a href="{{ route('winners.index') }}" class="p-2 rounded-lg {{ request()->routeIs('winners.index') ? 'text-primary' : 'text-gray-300' }}">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138z"></path></svg>
                    </a>
                    <a href="{{ route('trash.index') }}" class="p-2 rounded-lg relative {{ request()->routeIs('trash.index') ? 'text-primary' : 'text-gray-300' }}">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        @if($trashCount > 0)
                            <span class="absolute top-1.5 right-1.5 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-gray-900"></span>
                        @endif
                    </a>
                    @auth
                    <form method="POST" action="{{ route('logout') }}" class="ml-1 flex items-center">
                        @csrf
                        <button type="submit" class="p-2 text-red-400 hover:text-red-300" title="Logout">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                        </button>
                    </form>
                    @endauth
                </div>
            </div>
        </div>
    </nav>
    <main class="flex-1 max-w-7xl w-full mx-auto p-6 flex flex-col gap-6">
        @if(session('success'))
            <div class="p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl mb-4 shadow-sm font-medium">
                {{ session('success') }}
            </div>
        @endif
        @if(session('error'))
            <div class="p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl mb-4 shadow-sm font-medium">
                {{ session('error') }}
            </div>
        @endif
        @yield('content')
    </main>

    <!-- Global Custom Modal -->
    <div id="globalModal" class="hidden fixed inset-0 bg-gray-900/80 backdrop-blur-sm z-[99999] flex items-center justify-center p-4 opacity-0 transition-opacity duration-300">
        <div class="glass-card w-full max-w-md rounded-3xl p-6 relative border border-bdr bg-gray-900 shadow-2xl transform scale-95 transition-transform duration-300 flex flex-col gap-5">
            <h3 id="globalModalTitle" class="text-xl font-black text-gray-100 tracking-tight"></h3>
            <p id="globalModalMessage" class="text-sm text-gray-400 leading-relaxed"></p>
            <div class="flex items-center gap-3 mt-2 justify-end" id="globalModalButtons">
                <!-- Buttons injected dynamically -->
            </div>
        </div>
    </div>

    <script>
        let resolveGlobalModal = null;
        
        function showGlobalModal(title, message, isConfirm = false) {
            return new Promise((resolve) => {
                const modal = document.getElementById('globalModal');
                const titleEl = document.getElementById('globalModalTitle');
                const messageEl = document.getElementById('globalModalMessage');
                const buttonsEl = document.getElementById('globalModalButtons');
                
                titleEl.innerText = title || (isConfirm ? 'Confirm Action' : 'Notice');
                messageEl.innerText = message || '';
                
                buttonsEl.innerHTML = '';
                
                if (isConfirm) {
                    const cancelBtn = document.createElement('button');
                    cancelBtn.className = "text-xs text-gray-500 hover:text-gray-300 font-bold px-4 py-2 transition-colors";
                    cancelBtn.innerText = "Cancel";
                    cancelBtn.onclick = () => { closeGlobalModal(); resolve(false); };
                    
                    const confirmBtn = document.createElement('button');
                    confirmBtn.className = "bg-primary hover:bg-primaryDark text-white px-5 py-2 rounded-xl text-sm font-bold shadow-md transition-all";
                    confirmBtn.innerText = "Confirm";
                    confirmBtn.onclick = () => { closeGlobalModal(); resolve(true); };
                    
                    buttonsEl.appendChild(cancelBtn);
                    buttonsEl.appendChild(confirmBtn);
                } else {
                    const okBtn = document.createElement('button');
                    okBtn.className = "bg-primary hover:bg-primaryDark text-white px-6 py-2 rounded-xl text-sm font-bold shadow-md transition-all";
                    okBtn.innerText = "OK";
                    okBtn.onclick = () => { closeGlobalModal(); resolve(true); };
                    buttonsEl.appendChild(okBtn);
                }
                
                modal.classList.remove('hidden');
                // Trigger reflow
                void modal.offsetWidth;
                modal.classList.remove('opacity-0');
                modal.querySelector('.glass-card').classList.remove('scale-95');
                modal.querySelector('.glass-card').classList.add('scale-100');
            });
        }
        
        function closeGlobalModal() {
            const modal = document.getElementById('globalModal');
            modal.classList.add('opacity-0');
            modal.querySelector('.glass-card').classList.remove('scale-100');
            modal.querySelector('.glass-card').classList.add('scale-95');
            setTimeout(() => {
                modal.classList.add('hidden');
            }, 300);
        }

        window.appAlert = function(message, title = 'Notice') {
            return showGlobalModal(title, message, false);
        };
        
        window.appConfirm = function(message, title = 'Confirm Action') {
            return showGlobalModal(title, message, true);
        };

        window.formConfirm = function(event, form, message) {
            event.preventDefault();
            appConfirm(message).then(confirmed => {
                if (confirmed) {
                    form.submit();
                }
            });
            return false;
        };
    </script>

    @stack('scripts')
</body>
</html>

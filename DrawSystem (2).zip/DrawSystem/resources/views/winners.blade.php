@extends('layouts.app')

@section('content')
<div class="mb-6">
    <a href="{{ route('dashboard') }}" class="text-gray-500 hover:text-primary font-medium mb-4 inline-block flex items-center gap-1.5 transition-colors">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M15 19l-7-7 7-7"></path></svg>
        Back to Dashboard
    </a>
    <div class="border-l-4 border-primary pl-4">
        <h2 class="text-3xl font-black text-gray-900 tracking-tight">Winner History</h2>
        <p class="text-xs text-gray-500 mt-1 uppercase tracking-wider font-medium">Full records of all random giveaway selections</p>
    </div>
</div>

<div class="glass-card rounded-2xl p-6 border border-bdr bg-white/5 shadow-sm overflow-hidden">
    @if($winners->count() > 0)
        <div class="overflow-x-auto rounded-xl">
            <table class="w-full text-left border-collapse min-w-[700px]">
                <thead>
                    <tr class="border-b border-bdr text-gray-500 text-xs uppercase tracking-wider sticky top-0 bg-gray-900/80 z-10">
                        <th class="py-4 px-4 font-black">Winner Name</th>
                        <th class="py-4 px-4 font-black">Comment</th>
                        <th class="py-4 px-4 font-black">Giveaway Title</th>
                        <th class="py-4 px-4 font-black">Selected At</th>
                        <th class="py-4 px-4 font-black text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-white/5 text-sm">
                    @foreach($winners as $winner)
                        <tr class="hover:bg-white/5 transition-colors group">
                            <td class="py-4 px-4 whitespace-nowrap">
                                <div class="flex items-center gap-3">
                                    @if($winner->participant && $winner->participant->profile_pic_url)
                                        <img src="{{ preg_replace('/\/[sp]\d+x\d+\//', '/s600x600/', $winner->participant->profile_pic_url) }}" class="w-10 h-10 rounded-full object-cover border border-white/10 shadow-sm" alt="Avatar">
                                    @else
                                        <div class="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-black border border-primary/20 text-sm shadow-sm">
                                            {{ mb_substr($winner->winner_name, 0, 1) }}
                                        </div>
                                    @endif
                                    <span class="text-gray-900 font-bold tracking-tight">
                                        @if($winner->participant && $winner->participant->profile_url)
                                            <a href="{{ $winner->participant->profile_url }}" target="_blank" class="hover:text-primary transition-colors flex items-center gap-1">
                                                {{ $winner->winner_name }}
                                                <svg class="w-3.5 h-3.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                                            </a>
                                        @else
                                            {{ $winner->winner_name }}
                                        @endif
                                    </span>
                                </div>
                            </td>
                            <td class="py-4 px-4 text-gray-400 italic max-w-xs md:max-w-md truncate leading-relaxed">"{{ $winner->winner_comment ?: 'No comment' }}"</td>
                            <td class="py-4 px-4 whitespace-nowrap">
                                <span class="px-2.5 py-1 bg-primary/10 border border-primary/20 text-primary text-xs font-bold rounded-lg transition-colors group-hover:bg-primary/20 group-hover:text-white">{{ $winner->giveaway->title }}</span>
                            </td>
                            <td class="py-4 px-4 text-gray-500 whitespace-nowrap font-medium">{{ $winner->selected_at->format('M d, Y - g:i A') }}</td>
                            <td class="py-4 px-4 text-right">
                                <a href="{{ route('winners.card', $winner) }}" target="_blank" class="inline-block text-primary hover:text-primaryDark bg-primary/10 hover:bg-primary/20 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors border border-primary/20 mr-2">
                                    Card
                                </a>
                                <form action="{{ route('winners.destroy', $winner) }}" method="POST" class="inline-block" onsubmit="return confirm('Are you sure you want to delete this winner record?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-400 hover:text-red-300 bg-red-400/10 hover:bg-red-400/20 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors border border-red-500/20">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        
        @if($winners->hasPages())
            <div class="mt-8 flex justify-center">
                {{ $winners->links('pagination::tailwind') }}
            </div>
        @endif
    @else
        <div class="text-center py-20 text-gray-500 flex flex-col items-center justify-center gap-4">
            <div class="p-4 bg-primary/10 rounded-full text-primary">
                <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-14L4 7m8 4v10M4 7v10l8 4"></path></svg>
            </div>
            <div>
                <p class="text-lg font-black text-gray-900">No winners recorded yet.</p>
                <p class="text-sm mt-1 text-gray-500 leading-relaxed">Select active giveaways and run a random draw to generate lucky winner entries.</p>
            </div>
        </div>
    @endif
</div>
@endsection

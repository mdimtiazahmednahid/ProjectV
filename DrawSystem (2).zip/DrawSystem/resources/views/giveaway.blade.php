@extends('layouts.app')

@push('styles')
    <script src="https://cdn.jsdelivr.net/npm/ag-grid-community/dist/ag-grid-community.min.js"></script>
    <style>
        .ag-theme-alpine-dark {
            --ag-background-color: rgba(255, 255, 255, 0.03);
            --ag-header-background-color: rgba(0, 0, 0, 0.2);
            --ag-border-color: rgba(255, 255, 255, 0.08);
            --ag-row-border-color: rgba(255, 255, 255, 0.05);
            --ag-font-family: inherit;
            --ag-font-size: 13px;
            --ag-row-hover-color: rgba(0, 166, 81, 0.1);
            --ag-selected-row-background-color: rgba(0, 166, 81, 0.2);
            --ag-header-foreground-color: #9ca3af;
            --ag-data-color: #e5e7eb;
            --ag-control-panel-background-color: transparent;
            border-radius: 1rem;
            overflow: hidden;
        }
        .ag-theme-alpine-dark .ag-header {
            border-bottom: 1px solid var(--ag-border-color);
        }
        .ag-theme-alpine-dark .ag-row {
            transition: background-color 0.2s ease;
        }
        .ag-theme-alpine-dark .ag-body-viewport::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        .ag-theme-alpine-dark .ag-body-viewport::-webkit-scrollbar-track {
            background: rgba(0,0,0,0.2);
        }
        .ag-theme-alpine-dark .ag-body-viewport::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.1);
            border-radius: 4px;
        }
        .ag-theme-alpine-dark .ag-body-viewport::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.2);
        }
    </style>
@endpush

@section('content')

<div class="mb-6">
    <a href="{{ route('dashboard') }}" class="text-gray-500 hover:text-primary font-medium mb-4 inline-block flex items-center gap-1.5 transition-colors">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M15 19l-7-7 7-7"></path>
        </svg>
        Back to Dashboard
    </a>
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div class="border-l-4 border-primary pl-4 group">
            <div class="flex items-center gap-2">
                <h2 id="giveaway-title-display" class="text-3xl font-black text-gray-900 tracking-tight">{{ $giveaway->title }}</h2>
                <button onclick="editGiveawayTitle()" class="text-gray-400 hover:text-primary transition-all p-1.5 rounded-full hover:bg-primary/10 opacity-0 group-hover:opacity-100 mt-1" title="Rename Campaign">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                    </svg>
                </button>
            </div>
            @if($giveaway->description)
            <p class="text-gray-500 text-sm mt-1 leading-relaxed">{{ $giveaway->description }}</p>
            @endif
            <div class="mt-2 flex items-center gap-2">
                <span class="text-xs text-gray-400 font-medium">FB URL:</span>
                <span id="fb-url-display" class="text-xs text-gray-400 font-semibold truncate max-w-[250px] sm:max-w-md block">
                    @if($giveaway->source_url)
                    <a href="{{ $giveaway->source_url }}" target="_blank" class="text-primary hover:underline">{{ $giveaway->source_url }}</a>
                    @else
                    <span class="italic text-gray-500">No URL linked</span>
                    @endif
                </span>
                <button onclick="editGiveawayUrl()" class="text-gray-400 hover:text-primary transition-colors p-1" title="Change URL">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                    </svg>
                </button>
            </div>
        </div>
        <div class="flex gap-3 w-full md:w-auto">
            <a href="{{ route('draw.show', $giveaway) }}?mode=presentation" class="flex-1 md:flex-none bg-primary hover:bg-primaryDark text-white px-8 py-3.5 rounded-xl font-bold shadow-[0_4px_20px_0_rgba(0,166,81,0.5)] transition-all transform hover:-translate-y-0.5 text-lg text-center whitespace-nowrap flex items-center justify-center gap-2">
                <span>🎰 Start Draw</span>
            </a>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8 relative pb-24">
    <!-- Left Column: Operations (Tabbing Panel) -->
    <div class="glass-card rounded-2xl p-6 h-fit border border-bdr flex flex-col">
        <!-- Tab Navigation -->
        <div class="flex border-b border-bdr mb-6">
            <button onclick="switchTab('tab-file')" id="btn-tab-file" class="flex-1 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-primary text-primary transition-all focus:outline-none">
                File
            </button>
            <button onclick="switchTab('tab-facebook')" id="btn-tab-facebook" class="flex-1 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-transparent text-gray-400 hover:text-gray-200 transition-all focus:outline-none">
                FB Sync
            </button>
            <button onclick="switchTab('tab-settings')" id="btn-tab-settings" class="flex-1 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-transparent text-gray-400 hover:text-gray-200 transition-all focus:outline-none">
                Settings
            </button>
        </div>

        <!-- Tab 1: File Upload -->
        <div id="tab-file" class="tab-panel">
            <h3 class="text-lg font-black mb-2 text-gray-900 tracking-tight">Import Participants</h3>
            <p class="text-xs text-gray-500 mb-5 leading-relaxed">Upload a JSON or CSV file containing participants. Format should include at least 'name' and 'comment' fields.</p>

            <form action="{{ route('participants.import', $giveaway) }}" method="POST" enctype="multipart/form-data" class="flex flex-col gap-4">
                @csrf
                <div class="border-2 border-dashed border-bdr rounded-xl p-8 text-center hover:border-primary transition-colors bg-white/5 group relative overflow-hidden">
                    <input type="file" name="file" id="file" accept=".json,.csv,.txt" required class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" onchange="document.getElementById('fileName').textContent = this.files[0].name">
                    <div class="flex flex-col items-center gap-2 text-gray-400 group-hover:text-primary pointer-events-none transition-colors">
                        <svg class="w-10 h-10 text-gray-500 group-hover:text-primary transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                        </svg>
                        <span id="fileName" class="font-bold text-sm">Drag & drop or click to select file</span>
                    </div>
                </div>
                <button type="submit" class="bg-white hover:bg-gray-50 text-gray-900 py-3 rounded-xl font-bold transition-all border border-gray-300 mt-2 shadow-sm">Upload & Process</button>
            </form>
        </div>

        <!-- Tab 2: Sync from Facebook -->
        <div id="tab-facebook" class="tab-panel hidden">
            <h3 class="text-lg font-black mb-2 text-primary flex items-center gap-2 tracking-tight">
                <svg class="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                </svg>
                Sync with Facebook
            </h3>
            <p class="text-xs text-gray-500 mb-5 leading-relaxed">Drag the button below to your bookmarks bar, click it on any Facebook post to copy comments & timestamps, then click "Paste from Clipboard".</p>

            <div class="flex flex-col items-center">
                <a href="javascript:(function(){let cfg={replies:{{ $giveaway->grab_replies ? 'true' : 'false' }},pUrl:{{ $giveaway->grab_profile_url ? 'true' : 'false' }},pPic:{{ $giveaway->grab_profile_pic ? 'true' : 'false' }},time:{{ $giveaway->grab_comment_time ? 'true' : 'false' }}};function showInitModal(){let ov=document.createElement('div');ov.style.cssText='position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.7);z-index:999999;display:flex;align-items:center;justify-content:center;font-family:sans-serif;';let box=document.createElement('div');box.style.cssText='background:#fff;border-radius:16px;padding:30px;max-width:400px;text-align:center;box-shadow:0 10px 25px rgba(0,0,0,0.5);';let lastIdx=parseInt(sessionStorage.getItem('drawSyncLastIndex'))||0;let subtitle=lastIdx>0?'You previously processed up to '+lastIdx+' comments.':'You haven\'t copied any comments in this tab yet.';box.innerHTML='<h2 style=\'margin:0 0 10px;color:#111827;font-size:22px;font-weight:800;\'>Vejal Nai Sync</h2><p style=\'margin:0 0 20px;color:#4B5563;font-size:14px;\'>'+subtitle+'<br><br>Choose an action:</p><div style=\'display:flex;flex-direction:column;gap:10px;\'><button id=\'btnCopyAll\' style=\'background:#4F46E5;color:#fff;border:none;padding:12px 24px;border-radius:8px;font-weight:bold;font-size:16px;cursor:pointer;width:100%;\'>Copy All (Start from 0)</button><button id=\'btnCopyLatest\' style=\'background:#10B981;color:#fff;border:none;padding:12px 24px;border-radius:8px;font-weight:bold;font-size:16px;cursor:pointer;width:100%;\'>Copy Latest (Continue)</button><button id=\'btnCancel\' style=\'background:transparent;color:#6B7280;border:1px solid #D1D5DB;padding:12px 24px;border-radius:8px;font-weight:bold;font-size:16px;cursor:pointer;width:100%;\'>Cancel</button></div>';ov.appendChild(box);document.body.appendChild(ov);box.querySelector('#btnCopyAll').onclick=function(){ov.remove();sessionStorage.setItem('drawSyncLastIndex',0);processComments();};box.querySelector('#btnCopyLatest').onclick=function(){ov.remove();processComments();};box.querySelector('#btnCancel').onclick=function(){ov.remove();};}function processComments(){let cSelector='div[role=\'article\'], div[aria-label=\'Comment\'], div[aria-label^=\'Comment\']';if(cfg.replies){cSelector+=', div[aria-label=\'Reply\'], div[aria-label^=\'Reply\']';}let c=document.querySelectorAll(cSelector);let p=[];c.forEach(x=>{let name='';let pUrl='';let picUrl='';let com='No comment';let cTime='';let links=Array.from(x.querySelectorAll('a'));let nameLink=links.find(a=>{let txt=a.innerText.trim();return txt.length>0&&!/^(Like|Reply|Share|See more|View edit history|Follow)$/i.test(txt);});if(nameLink){name=nameLink.innerText.trim();if(cfg.pUrl)pUrl=nameLink.href;}if(!name)return;if(cfg.pPic){let images=x.querySelectorAll('image, img');if(images.length>0){picUrl=images[0].getAttribute('src')||images[0].getAttribute('xlink:href')||images[0].getAttribute('href')||'';picUrl=picUrl.replace(/\/[a-z]\d+x\d+\//gi,'/s600x600/').replace(/\/w\d+-h\d+\//gi,'/s600x600/').replace(/\/c[\d\.]+\//gi,'/s600x600/');}}let timeRegex=/^(Just\s+now|\d+\s*[hmsdw]\b|Yesterday|\d+\s+hrs?|\d+\s+mins?|\d+\s+(days?|weeks?|months?|years?)\s+ago|\d{1,2}\s+[a-zA-Z]{3,10}(\s*,?\s*\d{4})?|[a-zA-Z]{3,10}\s+\d{1,2}(\s*,?\s*\d{4})?)$/i;let ignoreRegex=/^(Like|Reply|Share|See more|View edit history|Follow|Top fan|Author|Edited|Hidden|See Translation)$/i;let leafDivs=Array.from(x.querySelectorAll('div[dir=\'auto\'], span[dir=\'auto\']')).filter(d=>!d.querySelector('div[dir=\'auto\'], span[dir=\'auto\']'));let textParts=[];for(let d of leafDivs){let t=d.innerText.trim();if(t&&t!==name&&!ignoreRegex.test(t)&&!timeRegex.test(t)){textParts.push(t);}}if(textParts.length>0){com=textParts.join(' ');}if(cfg.time){let timeElements=Array.from(x.querySelectorAll('a, span, div')).filter(el=>{let t=el.innerText.trim();return timeRegex.test(t);});if(timeElements.length>0){cTime=timeElements[0].innerText.trim();}}p.push({name:name,comment:com,profile_url:pUrl,profile_pic_url:picUrl,comment_time:cTime});});let u=[];let s=new Set();p.forEach(x=>{let k=x.name+'|'+x.profile_url+'|'+x.comment;if(!s.has(k)){s.add(k);u.push(x);}});function showMsg(m,isErr=false){let ov=document.createElement('div');ov.style.cssText='position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.7);z-index:999999;display:flex;align-items:center;justify-content:center;font-family:sans-serif;';let box=document.createElement('div');box.style.cssText='background:#fff;border-radius:16px;padding:30px;max-width:400px;text-align:center;box-shadow:0 10px 25px rgba(0,0,0,0.5);';let icon=isErr?'<div style=\'width:60px;height:60px;background:#EF4444;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:30px;margin:0 auto 20px;\'>!</div>':'<div style=\'width:60px;height:60px;background:#10B981;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:30px;margin:0 auto 20px;\'>✓</div>';box.innerHTML=icon+'<h2 style=\'margin:0 0 10px;color:#111827;font-size:22px;font-weight:800;\'>'+(isErr?'Oops!':'Success!')+'</h2><p style=\'margin:0 0 20px;color:#4B5563;font-size:16px;\'>'+m+'</p><button style=\'background:#4F46E5;color:#fff;border:none;padding:12px 24px;border-radius:8px;font-weight:bold;font-size:16px;cursor:pointer;width:100%;\'>Close</button>';let btn=box.querySelector('button');btn.onclick=function(){ov.remove();};ov.appendChild(box);document.body.appendChild(ov);}if(u.length===0){showMsg('No comments found! Please ensure you are viewing a post with comments and try scrolling down to load them.',true);return;}let lastIdx=parseInt(sessionStorage.getItem('drawSyncLastIndex'))||0;if(lastIdx>=u.length){showMsg('All loaded comments ('+u.length+') are already copied! <br><br>If you want to copy more, scroll down to load them or close the tab to restart.',false);return;}let batchSize=2000;let batch=u.slice(lastIdx,lastIdx+batchSize);let el=document.createElement('textarea');el.value=JSON.stringify({participants:batch});document.body.appendChild(el);el.select();document.execCommand('copy');document.body.removeChild(el);let nextIdx=lastIdx+batch.length;sessionStorage.setItem('drawSyncLastIndex',nextIdx);let msg='Copied <strong style=\'color:#4F46E5;\'>'+batch.length+'</strong> comments.<br><span style=\'font-size:14px;color:#6B7280;\'>Total processed: '+nextIdx+' / '+u.length+'</span><br><br>';if(nextIdx<u.length){msg+='<span style=\'font-size:14px;color:#EF4444;font-weight:bold;\'>MAX REACHED COPIED '+batch.length+' COMMENTS</span><br><br><span style=\'font-size:14px;color:#6B7280;\'>Paste them in the system, then click the bookmarklet again to copy the next batch!</span>';}else{msg+='<span style=\'font-size:14px;color:#6B7280;\'>Go back to Vejal Nai | Draw and click Paste & Sync. You have copied all available comments!</span>';}showMsg(msg);}showInitModal();})();"
                    class="bg-primary/10 text-primary hover:bg-primary hover:text-white px-6 py-3.5 rounded-xl font-bold transition-all cursor-grab border border-primary/20 hover:border-primary w-full text-center text-sm shadow-sm"
                    title="Drag me to your Bookmarks Bar!">
                    1. Drag to Bookmarks Bar
                </a>

                <button type="button" onclick="pasteFromClipboard(event)" class="mt-3 bg-mint text-primaryDeep hover:bg-primary hover:text-white border border-mint hover:border-primary px-6 py-3.5 rounded-xl font-bold w-full transition-all flex items-center justify-center gap-2 text-sm shadow-sm">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                    </svg>
                    2. Paste & Sync Data
                </button>

                <!-- Fallback Paste Area (Hidden by default) -->
                <div id="manual-paste-area" class="hidden w-full mt-4">
                    <p class="text-xs text-orange-400 font-semibold mb-2">Browser blocked clipboard access. Please paste text here (Ctrl+V):</p>
                    <textarea id="manual-paste-input" class="w-full h-24 bg-white/5 border border-gray-300 rounded-xl p-3 text-gray-900 text-xs font-mono mb-2 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary shadow-inner placeholder-gray-500" placeholder='{"participants": [...]}'></textarea>
                    <button type="button" onclick="processManualPaste(event)" class="bg-primary hover:bg-primaryDark text-white px-4 py-2.5 rounded-lg font-bold w-full text-sm transition-colors shadow">Process Pasted Data</button>
                </div>

                <p class="text-[10px] text-gray-500 mt-4 leading-relaxed font-semibold text-center">Browser bookmarklets enable rapid scraping of social page components directly without login details.</p>
            </div>
        </div>

        <!-- Tab 3: Settings -->
        <div id="tab-settings" class="tab-panel hidden">
            <h3 class="text-lg font-black mb-2 text-gray-900 tracking-tight">Giveaway Settings</h3>
            <p class="text-xs text-gray-500 mb-5 leading-relaxed">Customize settings for the random slot machine and filter options.</p>

            <form action="{{ route('giveaways.settings', $giveaway) }}" method="POST" enctype="multipart/form-data" class="flex flex-col gap-5">
                @csrf

                <!-- Display Customization -->
                <div class="border-b border-white/10 pb-4 mb-2">
                    <h4 class="text-sm font-bold text-primary uppercase tracking-wider mb-4">Display Customization</h4>

                    <div class="flex flex-col gap-4">
                        <div>
                            <label class="block text-xs text-gray-400 mb-1 font-semibold">Custom Title (Optional)</label>
                            <input type="text" name="custom_title" value="{{ $giveaway->custom_title }}" class="w-full bg-white/5 border border-gray-300 rounded-lg px-3 py-2 text-gray-900 focus:outline-none focus:border-primary text-sm" placeholder="e.g. Vejal Nai | Draw Engine">
                        </div>
                        <div>
                            <label class="block text-xs text-gray-400 mb-1 font-semibold">Custom Subtitle (Optional)</label>
                            <input type="text" name="custom_subtitle" value="{{ $giveaway->custom_subtitle }}" class="w-full bg-white/5 border border-gray-300 rounded-lg px-3 py-2 text-gray-900 focus:outline-none focus:border-primary text-sm" placeholder="e.g. Ready to pick a random winner...">
                        </div>
                        <div>
                            <label class="block text-xs text-gray-400 mb-1 font-semibold">Winner Card Title (Optional)</label>
                            <input type="text" name="custom_winner_title" value="{{ $giveaway->custom_winner_title }}" class="w-full bg-white/5 border border-gray-300 rounded-lg px-3 py-2 text-gray-900 focus:outline-none focus:border-primary text-sm" placeholder="e.g. 🎉 Winner Selected 🎉">
                        </div>
                        <div>
                            <label class="block text-xs text-gray-400 mb-1 font-semibold">Custom Logo (Optional)</label>
                            <input type="file" name="custom_logo_file" accept="image/*" class="w-full text-xs text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20">
                            @if($giveaway->custom_logo_url)
                            <p class="text-[10px] text-green-400 mt-1">✓ Custom logo is active.</p>
                            @endif
                        </div>
                        <div>
                            <label class="block text-xs text-gray-400 mb-1 font-semibold">Custom Background (Optional)</label>
                            <input type="file" name="custom_background_file" accept="image/*" class="w-full text-xs text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20">
                            @if($giveaway->custom_background_url)
                            <p class="text-[10px] text-green-400 mt-1">✓ Custom background is active.</p>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Technical Settings -->
                <h4 class="text-sm font-bold text-primary uppercase tracking-wider mb-2">Algorithm Settings</h4>
                <div>
                    <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Number of Winners</label>
                    <input type="number" name="number_of_winners" value="{{ $giveaway->number_of_winners ?? 1 }}" min="1" max="10" required class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors">
                    <p class="text-[10px] text-gray-500 mt-1">Sets how many winners to pick at the same time (max 10).</p>
                </div>
                <div>
                    <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Spin Duration (Seconds)</label>
                    <input type="number" name="spin_duration" value="{{ $giveaway->spin_duration ?? 20 }}" min="1" max="60" required class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors">
                    <p class="text-[10px] text-gray-500 mt-1">Sets how long the slot machine animation spins.</p>
                </div>
                <div>
                    <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Default Required Answer</label>
                    <input type="text" name="required_keyword" value="{{ $giveaway->required_keyword }}" class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors" placeholder="e.g. Yes, 2026, Apple">
                    <p class="text-[10px] text-gray-500 mt-1">This pre-fills the filter keyword. Separate variations with commas.</p>
                </div>
                <div>
                    <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Wrong Answer Keywords</label>
                    <input type="text" name="wrong_keyword" value="{{ $giveaway->wrong_keyword }}" class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-colors" placeholder="e.g. 2025, No, Orange">
                    <p class="text-[10px] text-gray-500 mt-1">If present, disqualifies comments containing these wrong answers.</p>
                </div>
                <div class="border-t border-bdr pt-4 mt-2">
                    <h4 class="text-sm font-bold text-primary uppercase tracking-wider mb-2">Advanced Settings</h4>
                    <div>
                        <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Exact Required Keyword</label>
                        <input type="text" name="exact_keyword" value="{{ $giveaway->exact_keyword }}" class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors" placeholder="e.g. Yes, 2026, Apple">
                        <p class="text-[10px] text-gray-500 mt-1">If set, comment must EXACTLY match this keyword (ignoring case). Overrides partial default answer.</p>
                    </div>
                    <div class="mt-4">
                        <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Exact Wrong Keyword</label>
                        <input type="text" name="exact_wrong_keyword" value="{{ $giveaway->exact_wrong_keyword }}" class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-colors" placeholder="e.g. 2025, No, Orange">
                        <p class="text-[10px] text-gray-500 mt-1">If set, exactly matching this keyword disqualifies the comment. Overrides partial wrong answer.</p>
                    </div>
                </div>

                <div class="border-t border-bdr pt-4 mt-2">
                    <h4 class="text-sm font-bold text-primary uppercase tracking-wider mb-2">Bookmarklet Sync Settings</h4>
                    <p class="text-xs text-gray-500 mb-3 leading-relaxed">Choose what data the bookmarklet should copy from Facebook.</p>

                    <div class="flex flex-col gap-2">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="grab_replies" value="1" {{ $giveaway->grab_replies ? 'checked' : '' }} class="rounded border-gray-300 text-primary focus:ring-primary">
                            <span class="text-sm text-gray-700 font-semibold">Include nested replies (unchecked = top-level comments only)</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="grab_profile_url" value="1" {{ $giveaway->grab_profile_url ? 'checked' : '' }} class="rounded border-gray-300 text-primary focus:ring-primary">
                            <span class="text-sm text-gray-700 font-semibold">Copy Profile URL</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="grab_profile_pic" value="1" {{ $giveaway->grab_profile_pic ? 'checked' : '' }} class="rounded border-gray-300 text-primary focus:ring-primary">
                            <span class="text-sm text-gray-700 font-semibold">Copy Profile Picture</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" name="grab_comment_time" value="1" {{ $giveaway->grab_comment_time ? 'checked' : '' }} class="rounded border-gray-300 text-primary focus:ring-primary">
                            <span class="text-sm text-gray-700 font-semibold">Copy Comment Timestamp</span>
                        </label>
                    </div>
                </div>

                <button type="submit" class="bg-primary hover:bg-primaryDark text-white py-3 rounded-xl font-bold transition-colors shadow-lg mt-2">Save Settings</button>
            </form>
        </div>
    </div>

    <!-- Right Column: List -->
    <div class="lg:col-span-2 glass-card rounded-2xl p-6 border border-bdr flex flex-col h-full">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div>
                <div class="flex items-center gap-3">
                    <h3 class="text-xl font-black text-gray-900 tracking-tight">Participants List</h3>
                    <button onclick="openSpreadsheet()" class="bg-primary/10 text-primary border border-primary/20 hover:bg-primary hover:text-white px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                        Sheet
                    </button>
                </div>
                <p class="text-xs text-gray-500 mt-1 font-semibold">Total: <span class="text-primary font-bold">{{ number_format($giveaway->participants_count) }}</span> eligible</p>
            </div>
            <form action="{{ route('giveaways.show', $giveaway) }}" method="GET" class="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                <input type="hidden" name="filter" value="{{ $filter ?? '' }}">
                <input type="text" name="search" value="{{ $search }}" placeholder="Search name..." class="bg-white/5 border border-gray-300 rounded-lg px-4 py-2 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary text-sm w-full sm:w-64 transition-colors placeholder-gray-500">
                <button type="submit" class="bg-white hover:bg-gray-50 px-4 py-2 rounded-lg text-sm transition-colors border border-gray-300 text-gray-700 font-semibold shadow-sm">Search</button>
            </form>
        </div>

        <!-- Filter Chips & Select All -->
        <div class="flex flex-wrap items-center justify-between gap-4 mb-5 border-b border-white/5 pb-4">
            <div class="flex flex-wrap gap-2">
                <a href="{{ request()->fullUrlWithQuery(['filter' => '']) }}" class="flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-bold transition-colors border {{ empty($filter) ? 'bg-primary text-white border-primary shadow-sm' : 'bg-white/5 text-gray-400 border-white/10 hover:border-white/20' }}">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"></path></svg> All
                </a>
                <a href="{{ request()->fullUrlWithQuery(['filter' => 'duplicates']) }}" class="flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-bold transition-colors border {{ ($filter ?? '') === 'duplicates' ? 'bg-orange-500 text-white border-orange-500 shadow-sm' : 'bg-white/5 text-gray-400 border-white/10 hover:border-white/20' }}">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg> Dups
                </a>
                <a href="{{ request()->fullUrlWithQuery(['filter' => 'no_comments']) }}" class="flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-bold transition-colors border {{ ($filter ?? '') === 'no_comments' ? 'bg-blue-500 text-white border-blue-500 shadow-sm' : 'bg-white/5 text-gray-400 border-white/10 hover:border-white/20' }}">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg> Empty
                </a>
            </div>

            <div class="flex items-center gap-2">
                <input type="checkbox" id="main-select-all" onclick="toggleSelectAllCards(event)" class="rounded border-white/20 bg-white/5 text-primary focus:ring-primary">
                <label for="main-select-all" class="flex items-center gap-1.5 text-xs text-gray-400 font-bold select-none cursor-pointer">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg> Select All
                </label>
            </div>
        </div>

        <div class="overflow-y-auto pr-2" style="max-height: calc(100vh - 350px); min-height: 400px;">
            @if($participants->count() > 0)
            <div class="grid gap-3">
                @foreach($participants as $participant)
                <div onclick="handleCardClick(event, '{{ $loop->index }}', '{{ $participant->id }}')" class="participant-card bg-white/5 border border-white/5 rounded-2xl p-4 flex justify-between items-start hover:border-primary/30 hover:bg-white/10 hover:shadow-lg transition-all duration-300 relative cursor-pointer select-none group/card" data-id="{{ $participant->id }}">
                    <div class="flex-1 pr-4 flex gap-3">
                        <!-- Checkbox -->
                        <input type="checkbox" id="card-chk-{{ $participant->id }}" onclick="handleCheckboxToggle(event, '{{ $participant->id }}')" class="participant-chk rounded border-white/20 bg-white/5 text-primary focus:ring-primary mt-1.5 z-20">

                        @if($participant->profile_pic_url)
                        <img src="{{ preg_replace('/\\/[sp]\\d+x\\d+\\//', '/s600x600/', $participant->profile_pic_url) }}" class="w-10 h-10 rounded-full object-cover border border-white/10 mt-1 shadow-sm pointer-events-none" alt="Avatar">
                        @else
                        <div class="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-black mt-1 border border-primary/20 text-sm shadow-sm pointer-events-none">
                            {{ mb_substr($participant->name, 0, 1) }}
                        </div>
                        @endif
                        <div class="w-full">
                            <h4 class="font-black text-gray-900 text-base flex items-center justify-between tracking-tight">
                                @if($participant->profile_url)
                                <a href="{{ $participant->profile_url }}" onclick="event.stopPropagation()" target="_blank" class="hover:text-primary transition-colors flex items-center gap-1 z-20">
                                    {{ $participant->name }}
                                    <svg class="w-3.5 h-3.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                                    </svg>
                                </a>
                                @else
                                {{ $participant->name }}
                                @endif
                            </h4>

                            <div class="mt-1 flex items-center">
                                <select onchange="updateGender('{{ $participant->id }}', this.value); event.stopPropagation()" onclick="event.stopPropagation()" class="bg-white/5 border border-white/10 text-[10px] text-gray-400 font-bold rounded px-1 py-0.5 focus:outline-none focus:border-primary z-20" title="Gender">
                                    <option value="unknown" {{ $participant->gender === 'unknown' ? 'selected' : '' }}>? Unknown</option>
                                    <option value="male" {{ $participant->gender === 'male' ? 'selected' : '' }}>♂ Male</option>
                                    <option value="female" {{ $participant->gender === 'female' ? 'selected' : '' }}>♀ Female</option>
                                </select>
                            </div>

                            <!-- Comment Display & Edit -->
                            <div class="mt-1 group relative">
                                <div id="comment-display-{{ $participant->id }}" class="flex items-start gap-2">
                                    <p class="text-sm text-gray-400 break-words flex-1 leading-relaxed">{{ $participant->comment ?? 'No comment' }}</p>
                                    @if($participant->comment_time)
                                    <span class="text-[10px] text-gray-500 mt-0.5 whitespace-nowrap font-medium">{{ $participant->comment_time }}</span>
                                    @endif
                                    <button onclick="event.stopPropagation(); toggleEdit('{{ $participant->id }}')" class="opacity-0 group-hover:opacity-100 group-hover/card:opacity-100 text-gray-500 hover:text-primary transition-all p-1 shrink-0 z-20" title="Edit Comment">
                                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                                        </svg>
                                    </button>
                                </div>

                                <div id="comment-edit-{{ $participant->id }}" class="hidden mt-2" onclick="event.stopPropagation()">
                                    <textarea id="comment-input-{{ $participant->id }}" class="w-full bg-white/5 border border-gray-300 rounded-xl p-3 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary text-gray-900 transition-colors shadow-inner" rows="2">{{ $participant->comment }}</textarea>
                                    <div class="flex gap-2 mt-2">
                                        <button onclick="saveComment('{{ $participant->id }}')" class="bg-primary hover:bg-primaryDark text-white text-xs px-3 py-1.5 rounded-lg font-bold transition-colors shadow-sm">Save</button>
                                        <button onclick="toggleEdit('{{ $participant->id }}')" class="bg-white/10 hover:bg-white/20 border border-white/10 text-gray-300 text-xs px-3 py-1.5 rounded-lg font-bold transition-colors">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Delete button shown on card hover -->
                    <form action="{{ route('participants.destroy', $participant) }}" method="POST" onsubmit="return formConfirm(event, this, 'Remove this participant?');" class="shrink-0 opacity-0 group-hover/card:opacity-100 transition-opacity z-20" onclick="event.stopPropagation()">
                        @csrf @method('DELETE')
                        <button type="submit" class="text-red-400 hover:text-red-500 transition-colors p-1" title="Remove Participant">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                            </svg>
                        </button>
                    </form>
                </div>
                @endforeach
            </div>

            @if($participants->hasPages())
            <div class="mt-6 flex justify-center pb-2">
                {{ $participants->links('pagination::tailwind') }}
            </div>
            @endif
            @else
            <div class="h-full flex flex-col items-center justify-center p-12 bg-white/5 rounded-2xl border border-dashed border-bdr text-gray-500 text-center min-h-[300px] gap-3">
                <svg class="w-16 h-16 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                </svg>
                <div>
                    <p class="text-lg font-black text-gray-900">No participants found.</p>
                    <p class="text-sm mt-1 max-w-sm">Use the forms on the left to import participants from a JSON/CSV file or directly sync comments from Facebook.</p>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>

<!-- Floating Bulk Action Bar -->
<div id="bulk-actions-bar" class="hidden fixed bottom-6 left-1/2 transform -translate-x-1/2 z-[60] bg-gray-900/90 border border-primary/30 backdrop-blur-md rounded-2xl px-6 py-4 flex items-center gap-6 shadow-[0_10px_35px_rgba(0,0,0,0.6)] border-b-4 border-primaryDeep transition-all">
    <span class="text-xs text-gray-200 font-bold"><span id="selected-count" class="text-primary font-black text-sm">0</span> items selected</span>
    <div class="h-4 border-l border-white/10"></div>
    <div class="flex items-center gap-2">
        <button onclick="bulkDisqualifySelected(false)" class="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/20 px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1">
            Disqualify
        </button>
        <button onclick="bulkDisqualifySelected(true)" class="bg-white/10 hover:bg-white/20 border border-white/10 text-gray-300 px-3.5 py-2 rounded-xl text-xs font-bold transition-all">
            Qualify
        </button>
        <button onclick="bulkMergeSelected()" class="bg-blue-500 hover:bg-blue-600 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1" title="Combine comments of selected participants">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
            </svg>
            Merge
        </button>
        <button onclick="bulkCleanDuplicates()" id="btn-clean-duplicates" class="bg-yellow-500 hover:bg-yellow-600 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1" title="Keep the newest and delete older duplicates among selection">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
            </svg>
            Clean Duplicates
        </button>
        <button onclick="bulkDeleteSelected()" class="bg-red-500 hover:bg-red-600 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1">
            Move to Trash
        </button>
    </div>
</div>

<script>
    // Gender Dictionary JS
    async function updateGender(id, gender) {
        try {
            const response = await fetch(`/participants/${id}/update-gender`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    gender: gender
                })
            });
            const data = await response.json();
            if (!data.success) {
                appAlert('Failed to update gender', 'error');
            }
        } catch (e) {
            console.error(e);
            appAlert('Error updating gender', 'error');
        }
    }

    function openGenderDictionaryModal() {
        const modal = document.getElementById('genderDictModal');
        modal.classList.remove('hidden');
        setTimeout(() => {
            modal.classList.remove('opacity-0');
            modal.querySelector('.glass-card').classList.remove('scale-95');
        }, 10);
        loadGenderDictionary();
    }

    function closeGenderDictionaryModal() {
        const modal = document.getElementById('genderDictModal');
        modal.classList.add('opacity-0');
        modal.querySelector('.glass-card').classList.add('scale-95');
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 300);
    }

    async function loadGenderDictionary() {
        const tbody = document.getElementById('gender-dict-list');
        tbody.innerHTML = '<tr><td colspan="3" class="text-center py-4 text-gray-500">Loading...</td></tr>';

        try {
            const res = await fetch('{{ route("gender-dictionary.index") }}');
            const data = await res.json();

            tbody.innerHTML = '';
            if (data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3" class="text-center py-4 text-gray-500">No keywords found.</td></tr>';
                return;
            }

            data.forEach(item => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                <td class="py-2 pl-2 font-mono text-primary">${item.keyword}</td>
                <td class="py-2">${item.gender === 'male' ? '♂ Male' : '♀ Female'}</td>
                <td class="py-2 text-right">
                    <button onclick="deleteGenderKeyword(${item.id})" class="text-red-400 hover:text-red-500 p-1 rounded hover:bg-white/10 transition-colors">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    </button>
                </td>
            `;
                tbody.appendChild(tr);
            });
        } catch (e) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center py-4 text-red-400">Failed to load</td></tr>';
        }
    }

    async function addGenderKeyword(e) {
        e.preventDefault();
        const keywordInput = document.getElementById('gender-keyword-input');
        const genderSelect = document.getElementById('gender-select-input');

        try {
            const res = await fetch('{{ route("gender-dictionary.store") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    keyword: keywordInput.value,
                    gender: genderSelect.value
                })
            });
            const data = await res.json();
            if (data.success) {
                keywordInput.value = '';
                loadGenderDictionary();
            } else {
                appAlert(data.message || 'Error saving keyword', 'error');
            }
        } catch (err) {
            appAlert('Error saving keyword', 'error');
        }
    }

    async function deleteGenderKeyword(id) {
        if (!confirm('Delete this keyword?')) return;
        try {
            const res = await fetch('/gender-dictionary/' + id, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                }
            });
            const data = await res.json();
            if (data.success) {
                loadGenderDictionary();
            }
        } catch (err) {
            appAlert('Error deleting keyword', 'error');
        }
    }

    async function editGiveawayTitle() {
        const currentTitle = document.getElementById('giveaway-title-display').innerText.trim();
        const newTitle = prompt("Enter new Campaign Name:", currentTitle);
        if (newTitle === null || newTitle.trim() === '') return; // cancelled or empty

        try {
            const response = await fetch("{{ route('giveaways.updateTitle', $giveaway) }}", {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    title: newTitle.trim()
                })
            });
            const data = await response.json();
            if (data.success) {
                document.getElementById('giveaway-title-display').innerText = data.title;
            } else {
                throw new Error();
            }
        } catch (e) {
            appAlert('Failed to update campaign name.');
        }
    }

    async function editGiveawayUrl() {
        const currentUrl = "{{ $giveaway->source_url }}";
        const newUrl = prompt("Enter Facebook Post URL (or image URL for card background):", currentUrl);
        if (newUrl === null) return; // cancelled

        try {
            const response = await fetch("{{ route('giveaways.updateUrl', $giveaway) }}", {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    source_url: newUrl
                })
            });
            const data = await response.json();
            if (data.success) {
                appAlert('Giveaway URL updated successfully!');
                window.location.reload();
            } else {
                throw new Error();
            }
        } catch (e) {
            appAlert('Invalid URL format. Please make sure to enter a valid URL (starting with http:// or https://) or leave it empty.');
        }
    }

    /* Tab System JS */
    function switchTab(tabId) {
        // Hide all tab panels
        document.querySelectorAll('.tab-panel').forEach(panel => {
            panel.classList.add('hidden');
        });

        // Deactivate all tab buttons
        document.getElementById('btn-tab-file').className = "flex-1 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-transparent text-gray-400 hover:text-gray-200 transition-all focus:outline-none";
        document.getElementById('btn-tab-facebook').className = "flex-1 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-transparent text-gray-400 hover:text-gray-200 transition-all focus:outline-none";
        document.getElementById('btn-tab-settings').className = "flex-1 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-transparent text-gray-400 hover:text-gray-200 transition-all focus:outline-none";

        // Show active panel
        document.getElementById(tabId).classList.remove('hidden');

        // Activate active button
        const activeBtn = document.getElementById('btn-' + tabId);
        activeBtn.className = "flex-1 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-primary text-primary transition-all focus:outline-none";
    }

    let pendingSyncData = null;
    let pendingSyncBtn = null;

    function processData(text, btn) {
        try {
            const data = JSON.parse(text);
            if (!data.participants || !Array.isArray(data.participants)) {
                throw new Error("Invalid format");
            }

            pendingSyncData = data;
            pendingSyncBtn = btn;

            const modal = document.getElementById('pasteSyncModal');
            modal.classList.remove('hidden');
            // trigger reflow
            void modal.offsetWidth;
            modal.classList.remove('opacity-0');
            modal.querySelector('.glass-card').classList.remove('scale-95');
        } catch (e) {
            appAlert('Invalid data format. Make sure you clicked the bookmarklet on Facebook first and pasted exactly what it copied!');
        }
    }

    function closePasteSyncModal() {
        const modal = document.getElementById('pasteSyncModal');
        modal.classList.add('opacity-0');
        modal.querySelector('.glass-card').classList.add('scale-95');
        setTimeout(() => {
            modal.classList.add('hidden');
            pendingSyncData = null;
            pendingSyncBtn = null;
        }, 300);
    }

    async function executeSync(mode) {
        if (!pendingSyncData || !pendingSyncBtn) return;

        const allParticipants = pendingSyncData.participants || [];
        const btn = pendingSyncBtn;

        closePasteSyncModal();
        const btnOriginalText = btn.innerHTML;

        btn.innerHTML = 'Syncing... 0%';
        btn.disabled = true;

        let totalImported = 0;
        let totalUpdated = 0;
        const chunkSize = 200;

        try {
            for (let i = 0; i < allParticipants.length; i += chunkSize) {
                const chunk = allParticipants.slice(i, i + chunkSize);
                const chunkData = {
                    participants: chunk,
                    mode: mode
                };

                const response = await fetch("{{ url('/api/giveaways/'.$giveaway->id.'/bookmarklet-sync') }}", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(chunkData)
                });

                const result = await response.json();
                if (result.success) {
                    totalImported += (result.count || 0);
                    totalUpdated += (result.updated || 0);
                    const percent = Math.round((Math.min(i + chunkSize, allParticipants.length) / allParticipants.length) * 100);
                    btn.innerHTML = `Syncing... ${percent}%`;
                } else {
                    let errorMsg = result.error || result.message || 'Unknown error occurred.';
                    if (result.errors) {
                        errorMsg += '\n' + JSON.stringify(result.errors);
                    }
                    throw new Error(errorMsg);
                }
            }

            if (mode === 'update') {
                appAlert(`Sync complete! Added ${totalImported} new, updated/skipped ${totalUpdated} duplicates.`);
            } else {
                appAlert(`Successfully pasted ${totalImported} participants!`);
            }

            setTimeout(() => window.location.reload(), 2000);

        } catch (e) {
            appAlert('Error while syncing: ' + e.message, 'error');
            btn.innerHTML = btnOriginalText;
            btn.disabled = false;
        }
    }

    async function pasteFromClipboard(event) {
        const btn = event.currentTarget;
        try {
            if (!navigator.clipboard || !navigator.clipboard.readText) {
                throw new Error("Clipboard API not available (requires HTTPS or localhost)");
            }
            const text = await navigator.clipboard.readText();
            if (!text) throw new Error("Clipboard is empty");
            await processData(text, btn);
        } catch (e) {
            // Fallback: Show manual paste textarea if browser blocks automatic clipboard access
            btn.classList.add('hidden');
            document.getElementById('manual-paste-area').classList.remove('hidden');
        }
    }

    function processManualPaste(event) {
        const text = document.getElementById('manual-paste-input').value;
        const btn = event.currentTarget;
        processData(text, btn);
    }

    function toggleEdit(id) {
        const displayDiv = document.getElementById(`comment-display-${id}`);
        const editDiv = document.getElementById(`comment-edit-${id}`);

        if (displayDiv.classList.contains('hidden')) {
            displayDiv.classList.remove('hidden');
            editDiv.classList.add('hidden');
        } else {
            displayDiv.classList.add('hidden');
            editDiv.classList.remove('hidden');
        }
    }

    async function saveComment(id) {
        const textarea = document.getElementById(`comment-input-${id}`);
        const newComment = textarea.value;
        const saveBtn = textarea.nextElementSibling.querySelector('button');
        const originalText = saveBtn.innerText;

        saveBtn.innerText = '...';
        saveBtn.disabled = true;

        try {
            const response = await fetch(`/participants/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    comment: newComment
                })
            });

            const result = await response.json();

            if (result.success) {
                document.getElementById(`comment-display-${id}`).querySelector('p').innerText = result.comment;
                toggleEdit(id);
            } else {
                appAlert('Failed to update comment.');
            }
        } catch (e) {
            appAlert('Error updating comment.');
        }

        saveBtn.innerText = originalText;
        saveBtn.disabled = false;
    }

    /* Multi-Select and Keyboard Shortcuts Logic */
    let selectedIds = new Set();
    let lastSelectedCardIndex = null;
    let lastSelectedSheetIndex = null;

    function handleCheckboxToggle(e, id) {
        e.stopPropagation();
        if (e.target.checked) {
            selectedIds.add(id);
        } else {
            selectedIds.delete(id);
        }
        updateSelectionUI();
    }

    function handleCardClick(e, index, id) {
        const isCheckboxClick = e.target.type === 'checkbox';
        if (isCheckboxClick) return; // handled by checkbox toggle

        if (e.shiftKey && lastSelectedCardIndex !== null) {
            const cards = document.querySelectorAll('.participant-card');
            const start = Math.min(index, lastSelectedCardIndex);
            const end = Math.max(index, lastSelectedCardIndex);
            const shouldSelect = !selectedIds.has(id);

            for (let i = start; i <= end; i++) {
                const cardId = parseInt(cards[i].getAttribute('data-id'));
                const chk = document.getElementById(`card-chk-${cardId}`);
                if (shouldSelect) {
                    selectedIds.add(cardId);
                    if (chk) chk.checked = true;
                } else {
                    selectedIds.delete(cardId);
                    if (chk) chk.checked = false;
                }
            }
        } else if (e.ctrlKey || e.metaKey) {
            const chk = document.getElementById(`card-chk-${id}`);
            if (selectedIds.has(id)) {
                selectedIds.delete(id);
                if (chk) chk.checked = false;
            } else {
                selectedIds.add(id);
                if (chk) chk.checked = true;
            }
        } else {
            // Single select (clears other selections)
            const chks = document.querySelectorAll('.participant-chk');
            chks.forEach(c => c.checked = false);
            selectedIds.clear();

            selectedIds.add(id);
            const chk = document.getElementById(`card-chk-${id}`);
            if (chk) chk.checked = true;
        }

        lastSelectedCardIndex = index;
        updateSelectionUI();
    }

    function toggleSelectAllCards(e) {
        const isChecked = e.target.checked;
        const cards = document.querySelectorAll('.participant-card');

        cards.forEach(card => {
            const id = parseInt(card.getAttribute('data-id'));
            const chk = document.getElementById(`card-chk-${id}`);
            if (isChecked) {
                selectedIds.add(id);
                if (chk) chk.checked = true;
            } else {
                selectedIds.delete(id);
                if (chk) chk.checked = false;
            }
        });

        updateSelectionUI();
    }

    function handleSpreadsheetCheckboxToggle(e, id) {
        e.stopPropagation();
        if (e.target.checked) {
            selectedIds.add(id);
        } else {
            selectedIds.delete(id);
        }
        updateSelectionUI();
    }

    function handleSpreadsheetRowClick(e, index, id) {
        // If clicking cell editor, do nothing
        if (e.target.closest('.editing') || e.target.type === 'text') return;

        if (e.shiftKey && lastSelectedSheetIndex !== null) {
            const rows = document.querySelectorAll('.spreadsheet-row');
            const start = Math.min(index, lastSelectedSheetIndex);
            const end = Math.max(index, lastSelectedSheetIndex);
            const shouldSelect = !selectedIds.has(id);

            for (let i = start; i <= end; i++) {
                const rowId = parseInt(rows[i].getAttribute('data-id'));
                const chk = document.getElementById(`sheet-chk-${rowId}`);
                if (shouldSelect) {
                    selectedIds.add(rowId);
                    if (chk) chk.checked = true;
                } else {
                    selectedIds.delete(rowId);
                    if (chk) chk.checked = false;
                }
            }
        } else if (e.ctrlKey || e.metaKey) {
            const chk = document.getElementById(`sheet-chk-${id}`);
            if (selectedIds.has(id)) {
                selectedIds.delete(id);
                if (chk) chk.checked = false;
            } else {
                selectedIds.add(id);
                if (chk) chk.checked = true;
            }
        } else {
            const chks = document.querySelectorAll('.participant-sheet-chk');
            chks.forEach(c => c.checked = false);
            selectedIds.clear();

            selectedIds.add(id);
            const chk = document.getElementById(`sheet-chk-${id}`);
            if (chk) chk.checked = true;
        }

        lastSelectedSheetIndex = index;
        updateSelectionUI();
    }

    function toggleSelectAllSpreadsheet(e) {
        const isChecked = e.target.checked;
        const rows = document.querySelectorAll('.spreadsheet-row');

        rows.forEach(row => {
            const id = parseInt(row.getAttribute('data-id'));
            const chk = document.getElementById(`sheet-chk-${id}`);
            if (isChecked) {
                selectedIds.add(id);
                if (chk) chk.checked = true;
            } else {
                selectedIds.delete(id);
                if (chk) chk.checked = false;
            }
        });

        updateSelectionUI();
    }

    function updateSelectionUI() {
        const size = selectedIds.size;
        const bar = document.getElementById('bulk-actions-bar');

        if (size > 0) {
            bar.classList.remove('hidden');
            bar.classList.add('flex');
            document.getElementById('selected-count').innerText = size;
        } else {
            bar.classList.remove('flex');
            bar.classList.add('hidden');
        }

        // Sync checkboxes currently present on the DOM
        document.querySelectorAll('.participant-chk').forEach(chk => {
            const id = parseInt(chk.id.replace('card-chk-', ''));
            chk.checked = selectedIds.has(id);
        });

        document.querySelectorAll('.participant-sheet-chk').forEach(chk => {
            const id = parseInt(chk.id.replace('sheet-chk-', ''));
            chk.checked = selectedIds.has(id);
        });

        // Sync master checkboxes
        const mainSelectAll = document.getElementById('main-select-all');
        if (mainSelectAll) {
            const cards = document.querySelectorAll('.participant-card');
            mainSelectAll.checked = cards.length > 0 && Array.from(cards).every(card => {
                const id = parseInt(card.getAttribute('data-id'));
                return selectedIds.has(id);
            });
        }

        const sheetSelectAll = document.getElementById('sheet-select-all');
        if (sheetSelectAll) {
            const rows = document.querySelectorAll('.spreadsheet-row');
            sheetSelectAll.checked = rows.length > 0 && Array.from(rows).every(row => {
                const id = parseInt(row.getAttribute('data-id'));
                return selectedIds.has(id);
            });
        }
    }

    async function bulkDeleteSelected() {
        if (selectedIds.size === 0) return;
        if (!await appConfirm(`Are you sure you want to move the ${selectedIds.size} selected participants to Trash?`)) return;

        try {
            const response = await fetch("{{ route('participants.bulkDestroy') }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    ids: Array.from(selectedIds)
                })
            });
            const data = await response.json();
            if (data.success) {
                appAlert('Selected participants successfully moved to Trash.');
                const isSpreadsheetOpen = !document.getElementById('spreadsheetModal').classList.contains('hidden');
                if (isSpreadsheetOpen) {
                    await refreshSpreadsheetData();
                } else {
                    window.location.reload();
                }
            } else {
                throw new Error();
            }
        } catch (e) {
            appAlert('Error performing bulk delete.');
        }
    }

    async function bulkMergeSelected() {
        if (selectedIds.size < 2) {
            appAlert('Please select at least 2 participants to merge.');
            return;
        }
        if (!await appConfirm(`Are you sure you want to merge the ${selectedIds.size} selected participants into one?\n\nThe comments will be combined under the first selected participant, and the rest will be moved to the Trash.`)) return;

        try {
            const response = await fetch("{{ route('participants.bulkMerge') }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    ids: Array.from(selectedIds)
                })
            });
            const data = await response.json();
            if (data.success) {
                appAlert('Selected participants successfully merged.');
                const isSpreadsheetOpen = !document.getElementById('spreadsheetModal').classList.contains('hidden');
                if (isSpreadsheetOpen) {
                    await refreshSpreadsheetData();
                } else {
                    window.location.reload();
                }
            } else {
                appAlert(data.message || 'Error performing bulk merge.');
            }
        } catch (e) {
            appAlert('Error performing bulk merge.');
        }
    }

    async function bulkDisqualifySelected(isEligible) {
        if (selectedIds.size === 0) return;
        const actionText = isEligible ? 'qualify' : 'disqualify';
        if (!await appConfirm(`Are you sure you want to ${actionText} the ${selectedIds.size} selected participants?`)) return;

        try {
            const response = await fetch("{{ route('participants.bulkDisqualify') }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    ids: Array.from(selectedIds),
                    is_eligible: isEligible
                })
            });
            const data = await response.json();
            if (data.success) {
                appAlert(`Selected participants successfully ${actionText}ed.`);
                const isSpreadsheetOpen = !document.getElementById('spreadsheetModal').classList.contains('hidden');
                if (isSpreadsheetOpen) {
                    await refreshSpreadsheetData();
                } else {
                    window.location.reload();
                }
            } else {
                throw new Error();
            }
        } catch (e) {
            appAlert(`Error performing bulk ${actionText}.`);
        }
    }

    async function bulkCleanDuplicates() {
        if (selectedIds.size === 0) return;

        if (!await appConfirm(`Are you sure you want to clean duplicates among the ${selectedIds.size} selected participants? This will keep the newest entry for each person and move older copies to the Trash.`)) return;

        try {
            const response = await fetch("{{ route('participants.bulkCleanDuplicates') }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    ids: Array.from(selectedIds)
                })
            });
            const data = await response.json();
            if (data.success) {
                appAlert(data.message || 'Duplicates cleaned successfully.');
                const isSpreadsheetOpen = !document.getElementById('spreadsheetModal').classList.contains('hidden');
                if (isSpreadsheetOpen) {
                    await refreshSpreadsheetData();
                } else {
                    window.location.reload();
                }
            } else {
                appAlert(data.message || 'Error cleaning duplicates.');
            }
        } catch (e) {
            appAlert('Error cleaning duplicates.');
        }
    }

    /* Spreadsheet Logic */
    let participantsList = [];
    let hasChanges = false;
    let gridApi = null;
    let currentSpreadsheetFilter = 'all';

    const requiredKeyword = "{{ $giveaway->required_keyword }}";
    const wrongKeyword = "{{ $giveaway->wrong_keyword }}";
    const exactKeyword = "{{ $giveaway->exact_keyword }}";
    const exactWrongKeyword = "{{ $giveaway->exact_wrong_keyword }}";

    async function openSpreadsheet() {
        const modal = document.getElementById('spreadsheetModal');
        modal.classList.remove('hidden');
        await refreshSpreadsheetData();
        hasChanges = false;
    }

    function closeSpreadsheet() {
        document.getElementById('spreadsheetModal').classList.add('hidden');
        if (hasChanges) {
            window.location.reload();
        }
    }

    const escapeRegExp = (string) => string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    
    const containsWord = (text, word) => {
        const regex = new RegExp('(?<![\\p{L}\\p{M}\\p{N}])' + escapeRegExp(word) + '(?![\\p{L}\\p{M}\\p{N}])', 'iu');
        return regex.test(text);
    };
    
    const isCorrect = (comment) => {
        const c = (comment || '').trim().toLowerCase();
        
        const exactKwList = exactKeyword ? exactKeyword.split(',').map(k => k.trim().toLowerCase()).filter(Boolean) : [];
        const exactWrongKwList = exactWrongKeyword ? exactWrongKeyword.split(',').map(k => k.trim().toLowerCase()).filter(Boolean) : [];

        // 1. Exact wrong keyword check
        if (exactWrongKwList.length > 0) {
            const hasExactWrong = exactWrongKwList.some(ewkw => c === ewkw);
            if (hasExactWrong) return false;
        } else {
            // Fallback to partial wrong keyword check
            const wrongKwList = wrongKeyword ? wrongKeyword.split(',').map(k => k.trim().toLowerCase()).filter(Boolean) : [];
            const hasWrong = wrongKwList.some(wkw => c.includes(wkw));
            if (hasWrong) return false;
        }
        
        // 2. Exact required keyword check
        if (exactKwList.length > 0) {
            return exactKwList.some(ekw => c === ekw);
        } else {
            // Fallback to partial required keyword check
            const kwList = requiredKeyword ? requiredKeyword.split(',').map(k => k.trim().toLowerCase()).filter(Boolean) : [];
            if (kwList.length === 0) return true;
            return kwList.some(kw => c.includes(kw));
        }
    };
    
    const isInvalid = (comment) => {
        const c = (comment || '').trim();
        if (!c) return true;
        return !/[a-zA-Z0-9\u0980-\u09FF]/.test(c);
    };

    let duplicateNamesSet = new Set();

    const filterFns = {
        'all': (p) => true,
        'duplicates': (p) => duplicateNamesSet.has((p.name || '').trim().toLowerCase()),
        'no_comments': (p) => !p.comment || p.comment.trim().length === 0,
        'correct': (p) => isCorrect(p.comment) && (p.is_eligible == 1 || p.is_eligible == true),
        'wrong': (p) => p.comment && p.comment.trim().length > 0 && !isCorrect(p.comment) && !isInvalid(p.comment),
        'invalid': (p) => isInvalid(p.comment),
        'qualified': (p) => {
            const eligible = p.is_eligible == 1 || p.is_eligible == true;
            if (!eligible) return false;
            if ((requiredKeyword && requiredKeyword.trim().length > 0) || (wrongKeyword && wrongKeyword.trim().length > 0)) {
                return isCorrect(p.comment);
            }
            return true;
        },
        'disqualified': (p) => p.is_eligible == 0 || p.is_eligible == false
    };

    class AvatarRenderer {
        init(params) {
            this.eGui = document.createElement('div');
            this.eGui.className = "flex items-center justify-center h-full";
            if (!params.data) return;
            const avatarUrl = params.data.profile_pic_url 
                ? params.data.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s600x600/') 
                : '';
            
            if (avatarUrl) {
                this.eGui.innerHTML = `<img src="${avatarUrl}" class="w-8 h-8 rounded-full object-cover border border-white/10" alt="Avatar">`;
            } else {
                this.eGui.innerHTML = `<div class="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold border border-primary/20 text-xs">${(params.data.name || '?').charAt(0).toUpperCase()}</div>`;
            }
        }
        getGui() { return this.eGui; }
    }

    class ActionsRenderer {
        init(params) {
            this.eGui = document.createElement('div');
            this.eGui.className = "flex items-center justify-center gap-2 h-full";
            if (!params.data) return;
            
            const btnProfile = document.createElement('button');
            btnProfile.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>`;
            btnProfile.className = "text-blue-400 hover:text-white p-1 rounded hover:bg-white/10 transition-colors";
            btnProfile.title = "Open Facebook Profile";
            if(params.data.profile_url) {
                btnProfile.onclick = () => window.open(params.data.profile_url, '_blank');
            } else {
                btnProfile.style.opacity = '0.3';
                btnProfile.style.cursor = 'not-allowed';
            }
            
            const btnDel = document.createElement('button');
            btnDel.innerHTML = `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>`;
            btnDel.className = "text-red-400 hover:text-white p-1 rounded hover:bg-red-500/20 transition-colors";
            btnDel.title = "Delete row";
            btnDel.onclick = () => deleteSpreadsheetRow(params.data.id);

            this.eGui.appendChild(btnProfile);
            this.eGui.appendChild(btnDel);
        }
        getGui() { return this.eGui; }
    }

    const gridOptions = {
        columnDefs: [
            { headerCheckboxSelection: true, checkboxSelection: true, width: 50, pinned: 'left', sortable: false, filter: false },
            { field: "id", headerName: "ID", width: 80, sortable: true, filter: "agNumberColumnFilter" },
            { headerName: "Avatar", width: 80, cellRenderer: AvatarRenderer, sortable: false, filter: false },
            { field: "name", headerName: "Name", flex: 1, minWidth: 150, sortable: true, filter: "agTextColumnFilter", editable: true },
            { field: "comment", headerName: "Comment", flex: 2, minWidth: 200, sortable: true, filter: "agTextColumnFilter", editable: true },
            { field: "comment_time", headerName: "Time", width: 120, sortable: true, filter: "agTextColumnFilter", editable: true },
            { field: "profile_url", headerName: "Profile URL", flex: 1, minWidth: 150, sortable: true, filter: "agTextColumnFilter", editable: true },
            { headerName: "Actions", width: 100, cellRenderer: ActionsRenderer, pinned: 'right', sortable: false, filter: false }
        ],
        defaultColDef: { resizable: true, cellClass: "ag-cell-custom" },
        rowSelection: 'multiple',
        rowHeight: 56,
        animateRows: true,
        isExternalFilterPresent: () => true,
        doesExternalFilterPass: (node) => {
            if (!filterFns[currentSpreadsheetFilter]) return true;
            return filterFns[currentSpreadsheetFilter](node.data);
        },
        onSelectionChanged: (event) => {
            const selectedRows = gridApi.getSelectedRows();
            selectedIds.clear();
            selectedRows.forEach(r => selectedIds.add(r.id));
            updateSelectionUI();
        },
        onCellValueChanged: async (params) => {
            if (params.oldValue !== params.newValue) {
                await saveCellToBackend(params.data.id, params.colDef.field, params.newValue, params.node, params.oldValue);
            }
        },
        getRowId: (params) => String(params.data.id)
    };

    async function saveCellToBackend(id, field, newValue, node, oldValue) {
        try {
            const participant = participantsList.find(p => p.id === id);
            const payload = {
                name: participant.name,
                comment: participant.comment,
                profile_url: participant.profile_url,
                comment_time: participant.comment_time
            };
            payload[field] = newValue;
            
            const response = await fetch(`/participants/${id}/update-all`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(payload)
            });
            const data = await response.json();
            if (data.success) {
                participant[field] = newValue;
                appToast('Saved');
                hasChanges = true;
            } else {
                throw new Error(data.message || 'Error');
            }
        } catch (e) {
            appAlert(`Failed to save: ${e.message}`);
            node.setDataValue(field, oldValue);
        }
    }

    async function deleteSpreadsheetRow(id) {
        if (!await appConfirm('Are you sure you want to delete this participant?')) return;
        try {
            const response = await fetch(`/participants/${id}/delete`, {
                method: 'DELETE',
                headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' }
            });
            const data = await response.json();
            if (data.success) {
                participantsList = participantsList.filter(p => p.id !== id);
                gridApi.applyTransaction({ remove: [{ id: id }] });
                hasChanges = true;
                updateGridCounts();
            } else {
                appAlert('Error deleting participant.');
            }
        } catch (e) {
            appAlert('Error deleting participant.');
        }
    }

    function initGrid() {
        const gridDiv = document.querySelector('#spreadsheet-grid');
        gridDiv.innerHTML = '';
        gridApi = agGrid.createGrid(gridDiv, gridOptions);
    }

    async function refreshSpreadsheetData() {
        if(!gridApi) initGrid();
        gridApi.showLoadingOverlay();

        try {
            const response = await fetch("{{ route('participants.all', $giveaway) }}");
            const data = await response.json();
            if (data.success) {
                participantsList = data.participants;

                const nameCounts = {};
                participantsList.forEach(p => {
                    const name = (p.name || '').trim().toLowerCase();
                    nameCounts[name] = (nameCounts[name] || 0) + 1;
                });
                duplicateNamesSet = new Set(Object.keys(nameCounts).filter(name => nameCounts[name] > 1));

                gridApi.setGridOption('rowData', participantsList);

                if ((requiredKeyword && requiredKeyword.trim().length > 0) || (wrongKeyword && wrongKeyword.trim().length > 0)) {
                    document.getElementById('keyword-filters-group').classList.remove('hidden');
                    let disp = [];
                    const formatKw = (kw) => {
                        const arr = kw.split(',').map(s => s.trim()).filter(Boolean);
                        if (arr.length === 0) return '';
                        if (arr.length === 1) return arr[0];
                        return `${arr[0]} (+${arr.length - 1} more)`;
                    };
                    if (requiredKeyword) disp.push('Req: ' + formatKw(requiredKeyword));
                    if (wrongKeyword) disp.push('Wrong: ' + formatKw(wrongKeyword));
                    const span = document.getElementById('keyword-val-display');
                    span.innerText = disp.join(' | ');
                    span.title = (requiredKeyword ? 'Req: ' + requiredKeyword : '') + ' | ' + (wrongKeyword ? 'Wrong: ' + wrongKeyword : '');
                } else {
                    document.getElementById('keyword-filters-group').classList.add('hidden');
                }

                gridApi.forEachNode(node => {
                    if (selectedIds.has(node.data.id)) node.setSelected(true);
                });

                updateGridCounts();
                gridApi.hideOverlay();
            } else {
                throw new Error();
            }
        } catch (e) {
            gridApi.showNoRowsOverlay();
        }
    }
    
    function switchSpreadsheetFilter(filter) {
        currentSpreadsheetFilter = filter;
        gridApi.onFilterChanged();
        
        const filters = ['all', 'duplicates', 'no_comments', 'qualified', 'disqualified', 'correct', 'wrong', 'invalid'];
        filters.forEach(f => {
            const btn = document.getElementById(`sheet-btn-${f}`);
            if (btn) {
                if (f === filter) {
                    btn.classList.remove('bg-white/5', 'text-gray-400', 'border-white/10');
                    btn.classList.add('bg-primary', 'text-white', 'border-primary');
                } else {
                    btn.classList.add('bg-white/5', 'text-gray-400', 'border-white/10');
                    btn.classList.remove('bg-primary', 'text-white', 'border-primary');
                }
            }
        });
        updateGridCounts();
    }
    
    function filterSpreadsheet() {
        gridApi.setGridOption('quickFilterText', document.getElementById('sheet-search').value);
        updateGridCounts();
    }

    function updateGridCounts() {
        if(!gridApi) return;
        
        const btnLabels = {
            'all': 'All', 'duplicates': 'Duplicates', 'no_comments': 'No Comments',
            'correct': 'Correct', 'wrong': 'Wrong', 'invalid': 'Invalid',
            'qualified': 'Qualified', 'disqualified': 'Disqualified'
        };
        
        Object.keys(btnLabels).forEach(key => {
            const btn = document.getElementById(`sheet-btn-${key}`);
            if (btn) {
                const count = participantsList.filter(filterFns[key]).length;
                const total = participantsList.length;
                const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                const badgeText = key === 'all' ? count : `${count} (${pct}%)`;
                btn.innerHTML = `${btnLabels[key]} <span class="ml-1 text-[10px] bg-white/20 px-1.5 py-0.5 rounded-md font-mono text-white tracking-wider">${badgeText}</span>`;
            }
        });
        
        setTimeout(() => {
            document.getElementById('sheet-total-count').innerText = participantsList.length;
            document.getElementById('sheet-filtered-count').innerText = gridApi.getDisplayedRowCount();
            if (gridApi.getDisplayedRowCount() === 0) {
                document.getElementById('sheet-empty-state').classList.remove('hidden');
                document.getElementById('sheet-empty-state').classList.add('flex');
            } else {
                document.getElementById('sheet-empty-state').classList.remove('flex');
                document.getElementById('sheet-empty-state').classList.add('hidden');
            }
        }, 100);
    }
    
    async function addSpreadsheetRow() {
        try {
            const response = await fetch("{{ route('participants.storeApi', $giveaway) }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    name: 'New Participant',
                    comment: '',
                    comment_time: new Date().toLocaleString()
                })
            });
            const data = await response.json();
            if (data.success && data.participant) {
                participantsList.unshift(data.participant);
                gridApi.setGridOption('rowData', participantsList);
                hasChanges = true;
                updateGridCounts();
                gridApi.ensureIndexVisible(0);
                gridApi.startEditingCell({ rowIndex: 0, colKey: 'name' });
            } else {
                appAlert('Error adding participant.');
            }
        } catch (e) {
            appAlert('Error adding participant.');
        }
    }

    function exportToCsv() {
        if(!gridApi) return;
        gridApi.exportDataAsCsv({ fileName: 'giveaway_{{ $giveaway->id }}_participants.csv' });
    }

    function exportToExcel() {
        const rows = gridApi ? gridApi.getModel().rowsToDisplay.map(node => node.data) : participantsList;
        let tableHtml = `
            <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
            <head><meta charset="utf-8"></head>
            <body>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Comment</th>
                            <th>Time</th>
                            <th>Profile URL</th>
                            <th>Eligible</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows.map(p => `
                            <tr>
                                <td>${p.id}</td>
                                <td>${(p.name || '').replace(/</g, '&lt;')}</td>
                                <td>${(p.comment || '').replace(/</g, '&lt;')}</td>
                                <td>${p.comment_time || ''}</td>
                                <td>${p.profile_url || ''}</td>
                                <td>${p.is_eligible ? 'Yes' : 'No'}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </body>
            </html>
        `;
        const blob = new Blob([tableHtml], { type: 'application/vnd.ms-excel' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `giveaway_{{ $giveaway->id }}_participants.xls`;
        a.click();
        URL.revokeObjectURL(url);
    }

</script>

<!-- Spreadsheet Modal Overlay -->
<div id="spreadsheetModal" class="hidden fixed inset-0 bg-gray-900/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
    <div class="glass-card w-full max-w-6xl h-[90vh] rounded-3xl p-6 relative border border-bdr bg-gray-900/80 shadow-2xl flex flex-col overflow-hidden">
        <button onclick="closeSpreadsheet()" class="absolute top-5 right-5 text-gray-400 hover:text-white p-2 rounded-lg hover:bg-white/5 transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
        </button>

        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4 pr-8">
            <div class="border-l-4 border-primary pl-3">
                <h3 class="text-2xl font-black text-gray-900 tracking-tight flex items-center gap-2">
                    <svg class="w-7 h-7 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>
                    Spreadsheet View
                </h3>
                <p class="text-xs text-gray-500 mt-1">Click any cell to edit. Export or sort participants with ease.</p>
            </div>

            <div class="flex flex-wrap items-center gap-3 w-full md:w-auto">
                <div class="relative w-full md:w-48">
                    <input type="text" id="sheet-search" placeholder="Search grid..." oninput="filterSpreadsheet()" class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-2 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary text-xs transition-all placeholder-gray-500">
                </div>
                <button onclick="addSpreadsheetRow()" class="bg-primary hover:bg-primaryDark text-white px-4 py-2 rounded-xl font-bold shadow-lg text-xs transition-all flex items-center gap-1.5">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"></path></svg>
                    Add Row
                </button>
                <div class="flex items-center border border-white/10 rounded-xl bg-white/5 overflow-hidden">
                    <button onclick="exportToCsv()" class="px-3 py-2 text-xs font-bold text-gray-300 hover:bg-white/5 transition-all border-r border-white/10">CSV</button>
                    <button onclick="exportToExcel()" class="px-3 py-2 text-xs font-bold text-gray-300 hover:bg-white/5 transition-all font-semibold">Excel</button>
                </div>
            </div>
        </div>

        <!-- Advanced Filter Tabs in Spreadsheet -->
        <div class="flex flex-wrap items-center gap-2 mb-4 bg-white/5 p-2 rounded-xl border border-white/5">
            <span class="text-[10px] text-gray-500 font-bold uppercase tracking-wider px-2">Filters:</span>
            <button onclick="switchSpreadsheetFilter('all')" id="sheet-btn-all" class="px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border border-primary bg-primary text-white shadow-sm">All</button>
            <button onclick="switchSpreadsheetFilter('duplicates')" id="sheet-btn-duplicates" class="px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border border-white/10 bg-white/5 text-gray-400 hover:border-white/20">Duplicates</button>
            <button onclick="switchSpreadsheetFilter('no_comments')" id="sheet-btn-no_comments" class="px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border border-white/10 bg-white/5 text-gray-400 hover:border-white/20">No Comments</button>
            <button onclick="switchSpreadsheetFilter('qualified')" id="sheet-btn-qualified" class="px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border border-white/10 bg-white/5 text-gray-400 hover:border-white/20">Qualified</button>
            <button onclick="switchSpreadsheetFilter('disqualified')" id="sheet-btn-disqualified" class="px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border border-white/10 bg-white/5 text-gray-400 hover:border-white/20">Disqualified</button>

            <div id="keyword-filters-group" class="hidden items-center gap-2 ml-1 pl-3 border-l border-white/10">
                <span class="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Answer ("<span id="keyword-val-display" class="text-primary font-black"></span>"):</span>
                <button onclick="switchSpreadsheetFilter('correct')" id="sheet-btn-correct" class="px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border border-white/10 bg-white/5 text-gray-400 hover:border-white/20">Correct</button>
                <button onclick="switchSpreadsheetFilter('wrong')" id="sheet-btn-wrong" class="px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border border-white/10 bg-white/5 text-gray-400 hover:border-white/20">Wrong</button>
                <button onclick="switchSpreadsheetFilter('invalid')" id="sheet-btn-invalid" class="px-3.5 py-1.5 rounded-full text-xs font-bold transition-all border border-white/10 bg-white/5 text-gray-400 hover:border-white/20">Invalid</button>
            </div>
        </div>

        <div class="flex-1 rounded-xl overflow-hidden shadow-inner border border-bdr bg-white/5 relative">
            <div id="spreadsheet-grid" class="ag-theme-alpine-dark w-full h-full"></div>
            <div id="sheet-empty-state" class="hidden absolute inset-0 flex-col items-center justify-center p-12 text-gray-500 text-center bg-gray-900/80 z-10">
                <svg class="w-12 h-12 text-gray-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                </svg>
                <p class="text-base font-bold text-gray-400">No matching participants found.</p>
            </div>
        </div>

        <div class="mt-4 flex justify-between items-center text-[10px] text-gray-500 border-t border-bdr pt-4">
            <div>
                Total Rows: <span id="sheet-total-count" class="font-bold text-primary">0</span> |
                Filtered Rows: <span id="sheet-filtered-count" class="font-bold text-primary">0</span>
            </div>
            <div>
                Press <kbd class="px-1.5 py-0.5 bg-white/10 rounded font-mono text-[9px] text-gray-400 border border-white/10">Enter</kbd> to save edit | Click outside to save
            </div>
        </div>
    </div>
</div>

<!-- Gender Dictionary Modal -->
<div id="genderDictModal" class="hidden fixed inset-0 bg-gray-900/80 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 opacity-0 transition-opacity duration-300">
    <div class="glass-card w-full max-w-lg rounded-3xl p-6 relative border border-bdr bg-gray-900 shadow-2xl transform scale-95 transition-transform duration-300 flex flex-col h-[80vh]">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-black text-gray-100 tracking-tight flex items-center gap-2">
                <svg class="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                Gender Dictionary
            </h3>
            <button onclick="closeGenderDictionaryModal()" class="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-white/10 transition-colors">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>

        <p class="text-xs text-gray-400 mb-4">Add keywords (names, prefixes) to automatically assign genders when participants are imported.</p>

        <form id="add-gender-form" class="flex gap-2 mb-4" onsubmit="addGenderKeyword(event)">
            <input type="text" id="gender-keyword-input" required placeholder="Enter keyword (e.g. md, mst, ahmed)" class="flex-1 bg-white/5 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-primary focus:outline-none">
            <select id="gender-select-input" class="bg-white/5 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:border-primary focus:outline-none w-32">
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>
            <button type="submit" class="bg-primary hover:bg-primaryDark text-white px-4 py-2 rounded-lg font-bold text-sm">Add</button>
        </form>

        <div class="flex-1 overflow-y-auto border border-gray-700 rounded-xl bg-gray-800 p-2">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="text-gray-400 border-b border-gray-700">
                        <th class="pb-2 pl-2">Keyword</th>
                        <th class="pb-2">Gender</th>
                        <th class="pb-2 w-10"></th>
                    </tr>
                </thead>
                <tbody id="gender-dict-list" class="divide-y divide-gray-700 text-gray-200">
                    <!-- Populated via JS -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Custom Paste Sync Modal -->
<div id="pasteSyncModal" class="hidden fixed inset-0 bg-gray-900/80 backdrop-blur-sm z-[9999] flex items-center justify-center p-4 opacity-0 transition-opacity duration-300">
    <div class="glass-card w-full max-w-md rounded-3xl p-6 relative border border-bdr bg-gray-900 shadow-2xl transform scale-95 transition-transform duration-300 flex flex-col gap-5">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full bg-primary/20 text-primary flex items-center justify-center border border-primary/30">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"></path>
                </svg>
            </div>
            <h3 class="text-xl font-black text-gray-100 tracking-tight">Sync Data</h3>
        </div>

        <p class="text-sm text-gray-400 leading-relaxed">
            How would you like to import this data?
        </p>

        <div class="flex flex-col gap-3">
            <button onclick="executeSync('update')" class="w-full flex items-center justify-between p-4 rounded-xl border border-gray-700 bg-gray-800 hover:bg-gray-700 hover:border-primary/50 transition-all text-left group">
                <div>
                    <h4 class="text-white font-bold text-sm mb-1 group-hover:text-primary transition-colors flex items-center gap-1.5">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                        Update (Skip Dups)
                    </h4>
                    <p class="text-xs text-gray-500">Safely add new comments alongside existing ones, automatically skipping exact duplicates.</p>
                </div>
                <div class="text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
                    </svg>
                </div>
            </button>

            <button onclick="executeSync('paste')" class="w-full flex items-center justify-between p-4 rounded-xl border border-gray-700 bg-gray-800 hover:bg-gray-700 hover:border-green-500/50 transition-all text-left group">
                <div>
                    <h4 class="text-white font-bold text-sm mb-1 group-hover:text-green-400 transition-colors flex items-center gap-1.5">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
                        Paste All
                    </h4>
                    <p class="text-xs text-gray-500">Blindly insert all copied comments without filtering or checking for existing duplicates.</p>
                </div>
                <div class="text-green-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                    </svg>
                </div>
            </button>
        </div>

        <button onclick="closePasteSyncModal()" class="mt-2 text-xs text-gray-500 hover:text-gray-300 font-bold py-2 transition-colors">Cancel</button>
    </div>
</div>
@endsection
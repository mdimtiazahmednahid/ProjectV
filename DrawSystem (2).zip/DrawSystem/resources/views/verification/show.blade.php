@extends('layouts.public')

@section('content')
<div class="bg-white dark:bg-gray-800 shadow rounded-lg mb-8 overflow-hidden">
    <div class="px-4 py-5 sm:px-6 border-b border-gray-200 dark:border-gray-700">
        <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white">
            Transparency Report
        </h3>
        <p class="mt-1 max-w-2xl text-sm text-gray-500 dark:text-gray-400">
            Official cryptographic proof for the giveaway: <strong class="text-gray-700 dark:text-gray-300">{{ $giveaway->title }}</strong>
        </p>
    </div>
    <div class="px-4 py-5 sm:p-0">
        <dl class="sm:divide-y sm:divide-gray-200 dark:sm:divide-gray-700">
            <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Status</dt>
                <dd class="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                    @if ($giveaway->status === 'completed')
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 border border-green-200">Draw Completed Successfully</span>
                    @else
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800 border border-yellow-200">In Progress / Pending Draw</span>
                    @endif
                </dd>
            </div>
            
            @if ($draw)
            <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6 bg-gray-50 dark:bg-gray-800/50">
                <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Draw Date</dt>
                <dd class="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                    {{ date('F j, Y, g:i a T', strtotime($draw->created_at)) }}
                </dd>
            </div>
            <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Algorithm</dt>
                <dd class="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2">
                    {{ $draw->algorithm }} (v{{ $draw->software_version }})
                </dd>
            </div>
            <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6 bg-gray-50 dark:bg-gray-800/50">
                <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Participant Snapshot Hash (SHA-256)</dt>
                <dd class="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2 font-mono break-all bg-gray-100 dark:bg-gray-900 p-2 rounded text-xs border border-gray-300 dark:border-gray-700">
                    {{ $snapshot['snapshot_hash'] }}
                </dd>
            </div>
            <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">Draw Seed (Hex)</dt>
                <dd class="mt-1 text-sm text-gray-900 dark:text-white sm:mt-0 sm:col-span-2 font-mono break-all bg-gray-100 dark:bg-gray-900 p-2 rounded text-xs border border-gray-300 dark:border-gray-700">
                    {{ $draw->seed }}
                </dd>
            </div>
            @endif
        </dl>
    </div>
</div>

@if (!empty($winners))
<div class="mb-8">
    <h3 class="text-2xl font-bold text-gray-900 dark:text-white mb-6">Official Winners</h3>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        @foreach ($winners as $winner)
            @if ($winner['is_reserve'] == 0)
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow border border-yellow-400 p-6 relative overflow-hidden">
                <div class="absolute top-0 right-0 -mt-2 -mr-2 bg-yellow-400 text-yellow-900 font-bold w-12 h-12 flex items-center justify-center rounded-bl-3xl">
                    {{ $winner['position'] }}
                </div>
                <h4 class="text-xl font-bold text-gray-900 dark:text-white mb-2">{{ $winner['facebook_name'] }}</h4>
                <p class="text-sm text-gray-500 dark:text-gray-400">Position: {{ $winner['position'] }}</p>
            </div>
            @endif
        @endforeach
    </div>
</div>
@endif

<div class="mt-10 text-center">
    <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">
        This report is cryptographically verifiable. The snapshot hash represents the exact, immutable state of eligible participants at the time of the draw. The Draw Seed was used to deterministically select the winners using the Fisher-Yates algorithm.
    </p>
    <a href="#" class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600">
        <svg class="w-5 h-5 mr-2 -ml-1 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
        Download Audit Report (PDF)
    </a>
</div>
@endsection

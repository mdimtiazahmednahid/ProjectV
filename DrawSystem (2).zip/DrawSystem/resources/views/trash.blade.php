@extends('layouts.app')

@section('content')
<div class="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
    <div class="border-l-4 border-primary pl-4">
        <h2 class="text-3xl font-black text-gray-900 tracking-tight">🗑️ Trash Box</h2>
        <p class="text-xs text-gray-500 mt-1 uppercase tracking-wider font-medium">Deleted items are held here for 30 days before permanent deletion</p>
    </div>
    @if($trashedGiveaways->count() > 0 || $trashedParticipants->count() > 0)
        <div class="flex items-center gap-3">
            <form action="{{ route('trash.restoreAll') }}" method="POST" onsubmit="return formConfirm(event, this, 'Are you sure you want to restore all items in the trash?');">
                @csrf
                <button type="submit" class="bg-primary/10 hover:bg-primary hover:text-white border border-primary/20 text-primary px-4 py-2 rounded-xl text-sm font-bold transition-colors flex items-center gap-2 shadow-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                    Restore All
                </button>
            </form>
            <form action="{{ route('trash.empty') }}" method="POST" onsubmit="return formConfirm(event, this, 'Are you sure you want to permanently empty the trash? This action cannot be undone.');">
                @csrf @method('DELETE')
                <button type="submit" class="bg-red-500/10 hover:bg-red-500 hover:text-white border border-red-500/20 text-red-400 px-4 py-2 rounded-xl text-sm font-bold transition-colors flex items-center gap-2 shadow-sm">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    Empty Trash
                </button>
            </form>
        </div>
    @endif
</div>

<div class="glass-card rounded-2xl p-6 border border-bdr bg-white/5 shadow-sm overflow-hidden flex flex-col gap-6">
    <!-- Tab Controls -->
    <div class="flex border-b border-bdr">
        <button onclick="switchTrashTab('tab-giveaways')" id="btn-trash-giveaways" class="flex-1 md:flex-none md:px-8 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-primary text-primary transition-all focus:outline-none flex items-center justify-center gap-2">
            <span>Giveaways</span>
            <span class="bg-primary/20 text-primary text-[10px] px-2 py-0.5 rounded-full font-mono font-bold">{{ $trashedGiveaways->count() }}</span>
        </button>
        <button onclick="switchTrashTab('tab-participants')" id="btn-trash-participants" class="flex-1 md:flex-none md:px-8 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-transparent text-gray-400 hover:text-gray-200 transition-all focus:outline-none flex items-center justify-center gap-2">
            <span>Participants</span>
            <span class="bg-white/10 text-gray-300 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold">{{ $trashedParticipants->count() }}</span>
        </button>
    </div>

    <!-- Tab Panel: Trashed Giveaways -->
    <div id="tab-giveaways" class="trash-tab-panel">
        @if($trashedGiveaways->count() > 0)
            <div class="overflow-x-auto rounded-xl">
                <table class="w-full text-left border-collapse min-w-[600px]">
                    <thead>
                        <tr class="border-b border-bdr text-gray-500 text-xs uppercase tracking-wider sticky top-0 bg-gray-900/80 z-10">
                            <th class="py-4 px-4 font-black">Giveaway Title</th>
                            <th class="py-4 px-4 font-black">Description</th>
                            <th class="py-4 px-4 font-black">Deleted At</th>
                            <th class="py-4 px-4 font-black text-center w-32">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-white/5 text-sm">
                        @foreach($trashedGiveaways as $giveaway)
                            <tr class="hover:bg-white/5 transition-colors group">
                                <td class="py-4 px-4 font-bold text-gray-900 whitespace-nowrap">{{ $giveaway->title }}</td>
                                <td class="py-4 px-4 text-gray-400 max-w-xs truncate leading-relaxed">{{ $giveaway->description ?? 'No description' }}</td>
                                <td class="py-4 px-4 text-gray-500 whitespace-nowrap">{{ $giveaway->deleted_at->format('M d, Y - g:i A') }}</td>
                                <td class="py-4 px-4 text-center whitespace-nowrap">
                                    <div class="flex items-center justify-center gap-2">
                                        <!-- Restore Form -->
                                        <form action="{{ route('trash.restoreGiveaway', $giveaway->id) }}" method="POST">
                                            @csrf
                                            <button type="submit" class="p-2 text-primary hover:bg-primary/10 rounded-lg transition-all" title="Restore Giveaway">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                                            </button>
                                        </form>
                                        <!-- Force Delete Form -->
                                        <form action="{{ route('trash.forceDeleteGiveaway', $giveaway->id) }}" method="POST" onsubmit="return formConfirm(event, this, 'Permanently delete this giveaway and all its participants? This cannot be undone.');">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="p-2 text-red-400 hover:text-red-600 hover:bg-red-500/10 rounded-lg transition-all" title="Delete Permanently">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div class="text-center py-16 text-gray-500 flex flex-col items-center justify-center gap-3">
                <svg class="w-12 h-12 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                <p class="text-base font-bold text-gray-400">No soft-deleted giveaways in Trash.</p>
            </div>
        @endif
    </div>

    <!-- Tab Panel: Trashed Participants -->
    <div id="tab-participants" class="trash-tab-panel hidden">
        @if($trashedParticipants->count() > 0)
            <div class="overflow-x-auto rounded-xl">
                <table class="w-full text-left border-collapse min-w-[700px]">
                    <thead>
                        <tr class="border-b border-bdr text-gray-500 text-xs uppercase tracking-wider sticky top-0 bg-gray-900/80 z-10">
                            <th class="py-4 px-4 font-black">Name</th>
                            <th class="py-4 px-4 font-black">Comment</th>
                            <th class="py-4 px-4 font-black">Parent Giveaway</th>
                            <th class="py-4 px-4 font-black">Deleted At</th>
                            <th class="py-4 px-4 font-black text-center w-32">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-white/5 text-sm">
                        @foreach($trashedParticipants as $participant)
                            <tr class="hover:bg-white/5 transition-colors group">
                                <td class="py-4 px-4 whitespace-nowrap">
                                    <div class="flex items-center gap-3">
                                        @if($participant->profile_pic_url)
                                            <img src="{{ preg_replace('/\/[sp]\d+x\d+\//', '/s600x600/', $participant->profile_pic_url) }}" class="w-8 h-8 rounded-full object-cover border border-white/10 shadow-sm" alt="Avatar">
                                        @else
                                            <div class="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-black border border-primary/20 text-xs shadow-sm">
                                                {{ mb_substr($participant->name, 0, 1) }}
                                            </div>
                                        @endif
                                        <span class="text-gray-900 font-bold tracking-tight">
                                            @if($participant->profile_url)
                                                <a href="{{ $participant->profile_url }}" target="_blank" class="hover:text-primary transition-colors flex items-center gap-1">
                                                    {{ $participant->name }}
                                                    <svg class="w-3 h-3 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                                                </a>
                                            @else
                                                {{ $participant->name }}
                                            @endif
                                        </span>
                                    </div>
                                </td>
                                <td class="py-4 px-4 text-gray-400 italic max-w-xs truncate leading-relaxed">"{{ $participant->comment ?? 'No comment' }}"</td>
                                <td class="py-4 px-4 whitespace-nowrap">
                                    <span class="px-2 py-0.5 bg-white/10 border border-white/10 text-gray-300 text-xs font-semibold rounded">{{ $participant->giveaway->title ?? 'Deleted Giveaway' }}</span>
                                </td>
                                <td class="py-4 px-4 text-gray-500 whitespace-nowrap">{{ $participant->deleted_at->format('M d, Y - g:i A') }}</td>
                                <td class="py-4 px-4 text-center whitespace-nowrap">
                                    <div class="flex items-center justify-center gap-2">
                                        <!-- Restore Form -->
                                        <form action="{{ route('trash.restoreParticipant', $participant->id) }}" method="POST">
                                            @csrf
                                            <button type="submit" class="p-2 text-primary hover:bg-primary/10 rounded-lg transition-all" title="Restore Participant">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                                            </button>
                                        </form>
                                        <!-- Force Delete Form -->
                                        <form action="{{ route('trash.forceDeleteParticipant', $participant->id) }}" method="POST" onsubmit="return formConfirm(event, this, 'Permanently delete this participant? This cannot be undone.');">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="p-2 text-red-400 hover:text-red-600 hover:bg-red-500/10 rounded-lg transition-all" title="Delete Permanently">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div class="text-center py-16 text-gray-500 flex flex-col items-center justify-center gap-3">
                <svg class="w-12 h-12 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                <p class="text-base font-bold text-gray-400">No soft-deleted participants in Trash.</p>
            </div>
        @endif
    </div>
</div>

<script>
function switchTrashTab(tabId) {
    // Hide all panels
    document.querySelectorAll('.trash-tab-panel').forEach(panel => {
        panel.classList.add('hidden');
    });
    
    // Deactivate all buttons
    document.getElementById('btn-trash-giveaways').className = "flex-1 md:flex-none md:px-8 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-transparent text-gray-400 hover:text-gray-200 transition-all focus:outline-none flex items-center justify-center gap-2";
    document.getElementById('btn-trash-participants').className = "flex-1 md:flex-none md:px-8 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-transparent text-gray-400 hover:text-gray-200 transition-all focus:outline-none flex items-center justify-center gap-2";
    
    // Show active panel
    document.getElementById(tabId).classList.remove('hidden');
    
    // Activate button
    const activeBtn = document.getElementById('btn-' + tabId.replace('tab-', 'trash-'));
    activeBtn.className = "flex-1 md:flex-none md:px-8 pb-3 text-xs uppercase tracking-wider font-bold border-b-2 border-primary text-primary transition-all focus:outline-none flex items-center justify-center gap-2";
    
    // Update badge background colors to highlight active
    if (tabId === 'tab-giveaways') {
        document.querySelector('#btn-trash-giveaways span:nth-child(2)').className = "bg-primary/20 text-primary text-[10px] px-2 py-0.5 rounded-full font-mono font-bold";
        document.querySelector('#btn-trash-participants span:nth-child(2)').className = "bg-white/10 text-gray-300 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold";
    } else {
        document.querySelector('#btn-trash-giveaways span:nth-child(2)').className = "bg-white/10 text-gray-300 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold";
        document.querySelector('#btn-trash-participants span:nth-child(2)').className = "bg-primary/20 text-primary text-[10px] px-2 py-0.5 rounded-full font-mono font-bold";
    }
}
</script>
@endsection

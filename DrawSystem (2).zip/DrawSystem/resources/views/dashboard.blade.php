@extends('layouts.app')

@section('content')
<div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
    <div class="border-l-4 border-primary pl-4">
        <h2 class="text-2xl font-black text-gray-900 tracking-tight">Active Giveaways</h2>
        <p class="text-xs text-gray-500 mt-1 uppercase tracking-wider font-medium">Manage and run live random selections</p>
    </div>
    <div class="flex items-center gap-3 w-full sm:w-auto">
        @if($giveaways->count() > 0)
            <button id="btn-toggle-manage" onclick="toggleManagementMode()" class="bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm">
                ⚙️ Manage Campaigns
            </button>
            <div id="select-all-container" class="hidden items-center gap-2 bg-white/5 border border-white/10 px-4 py-2.5 rounded-xl">
                <input type="checkbox" id="dashboard-select-all" onclick="toggleSelectAllGiveaways(event)" class="rounded border-white/20 bg-white/5 text-primary focus:ring-primary">
                <label for="dashboard-select-all" class="text-xs text-gray-400 font-bold select-none cursor-pointer">Select All</label>
            </div>
        @endif
        <button onclick="document.getElementById('createModal').classList.remove('hidden')" class="bg-primary hover:bg-primaryDark text-white px-6 py-3 rounded-xl font-bold shadow-[0_4px_14px_0_rgba(0,166,81,0.39)] transition-all transform hover:-translate-y-0.5 flex items-center gap-2 ml-auto">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"></path></svg>
            New Giveaway
        </button>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative pb-24">
    @forelse($giveaways as $giveaway)
        @php
            $isImageUrl = false;
            if ($giveaway->source_url) {
                $urlLower = strtolower($giveaway->source_url);
                if (
                    str_ends_with($urlLower, '.jpg') || 
                    str_ends_with($urlLower, '.jpeg') || 
                    str_ends_with($urlLower, '.png') || 
                    str_ends_with($urlLower, '.webp') || 
                    str_ends_with($urlLower, '.gif') ||
                    str_contains($urlLower, 'images') ||
                    str_contains($urlLower, 'img')
                ) {
                    $isImageUrl = true;
                }
            }
        @endphp
        <div onclick="handleGiveawayCardClick(event, '{{ $loop->index }}', '{{ $giveaway->id }}', `/giveaways/{{ $giveaway->id }}`)" class="giveaway-card glass-card rounded-2xl p-6 flex flex-col justify-between hover:-translate-y-1.5 hover:shadow-2xl transition-all duration-300 border border-bdr hover:border-primary/40 relative overflow-hidden group cursor-pointer select-none" data-id="{{ $giveaway->id }}">
            
            <!-- Blurred background image if url is image -->
            @if($isImageUrl)
                <div class="absolute inset-0 z-0 bg-cover bg-center opacity-20 filter blur-[2px] transition-all group-hover:scale-105 duration-700" style="background-image: url('{{ $giveaway->source_url }}');"></div>
                <!-- Gradient overlay for text safety -->
                <div class="absolute inset-0 bg-gray-950/10 z-0"></div>
            @else
                <!-- Decorative corner accent -->
                <div class="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-full translate-x-6 -translate-y-6 group-hover:bg-primary/10 transition-colors z-0"></div>
            @endif
            
            <div class="relative z-10">
                <div class="flex justify-between items-start gap-4 mb-3">
                    <div class="flex items-start gap-3">
                        <div class="checkbox-wrapper hidden z-20">
                            <input type="checkbox" id="giveaway-chk-{{ $giveaway->id }}" onclick="handleGiveawayCheckboxToggle(event, '{{ $giveaway->id }}')" class="giveaway-chk rounded border-white/20 bg-white/5 text-primary focus:ring-primary">
                        </div>
                        <div class="flex items-center gap-2">
                            <h3 id="dashboard-title-{{ $giveaway->id }}" class="text-xl font-black text-gray-900 tracking-tight group-hover:text-primary transition-colors">{{ $giveaway->title }}</h3>
                            <button onclick="editGiveawayTitleDashboard(event, '{{ $giveaway->id }}')" class="text-gray-400 hover:text-primary transition-all p-1.5 rounded-full hover:bg-primary/10 opacity-0 group-hover:opacity-100" title="Rename Campaign">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                            </button>
                        </div>
                    </div>
                    
                    <div class="flex items-center gap-1.5">
                        <!-- Individual Delete -->
                        <div class="delete-btn-wrapper hidden" onclick="event.stopPropagation()">
                            <form action="{{ route('giveaways.destroy', $giveaway) }}" method="POST" onsubmit="return formConfirm(event, this, 'Are you sure to delete this giveaway? It will be moved to the Trash.');">
                                @csrf @method('DELETE')
                                <button type="submit" class="text-red-400 hover:text-red-500 p-1 rounded hover:bg-white/5 transition-all" title="Delete Giveaway">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            </form>
                        </div>
                        <span class="text-[10px] bg-white/5 border border-white/10 text-gray-400 px-2 py-0.5 rounded font-mono">#{{ $giveaway->id }}</span>
                    </div>
                </div>
                <p class="text-gray-500 text-sm mb-6 line-clamp-2 leading-relaxed">{{ $giveaway->description ?? 'No description provided.' }}</p>
            </div>
            
            <div class="flex justify-between items-end mt-4 pt-4 border-t border-bdr relative z-10">
                  <div>
                      <p class="text-xs text-gray-500 uppercase tracking-wider mb-1 font-semibold flex items-center gap-1">
                          <svg class="w-3.5 h-3.5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                          Participants
                      </p>
                      <p class="text-2xl font-black text-gray-900 tracking-tight">{{ number_format($giveaway->participants_count) }}</p>
                  </div>
                  <a href="{{ route('giveaways.show', $giveaway) }}" onclick="event.stopPropagation()" class="text-primary hover:text-primaryDeep text-sm font-bold transition-all px-4 py-2.5 bg-primary/10 rounded-xl hover:bg-primary/20 flex items-center gap-1.5 font-semibold">
                      Manage
                      <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M9 5l7 7-7 7"></path></svg>
                  </a>
            </div>
        </div>
    @empty
        <div class="col-span-full text-center p-16 glass-card rounded-2xl border border-bdr flex flex-col items-center justify-center gap-4">
            <div class="p-4 bg-primary/10 rounded-full text-primary">
                <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-14L4 7m8 4v10M4 7v10l8 4"></path></svg>
            </div>
            <div>
                <p class="text-gray-900 text-lg font-black">No giveaways created yet.</p>
                <p class="text-gray-500 text-sm mt-1 leading-relaxed">Create your first giveaway list and begin extracting participants from social media or JSON/CSV files.</p>
            </div>
            <button onclick="document.getElementById('createModal').classList.remove('hidden')" class="mt-2 bg-primary hover:bg-primaryDark text-white px-6 py-2.5 rounded-xl font-bold shadow-md transition-all flex items-center gap-2">
                Create First Giveaway
            </button>
        </div>
    @endforelse
</div>

<!-- Floating Bulk Action Bar for Dashboard -->
<div id="bulk-giveaway-bar" class="hidden fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50 bg-gray-900/90 border border-primary/30 backdrop-blur-md rounded-2xl px-6 py-4 flex items-center gap-6 shadow-[0_10px_35px_rgba(0,0,0,0.6)] border-b-4 border-primaryDeep transition-all">
    <span class="text-xs text-gray-200 font-bold"><span id="selected-giveaway-count" class="text-primary font-black text-sm">0</span> giveaways selected</span>
    <div class="h-4 border-l border-white/10"></div>
    <button onclick="bulkDeleteGiveaways()" class="bg-red-500 hover:bg-red-600 text-white px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-lg">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
        Move Selected to Trash
    </button>
</div>

<div class="mt-16 pt-8 border-t border-bdr flex justify-between items-center mb-8">
    <div class="border-l-4 border-primary pl-4">
        <h2 class="text-2xl font-black text-gray-900 tracking-tight">Winner History</h2>
        <p class="text-xs text-gray-500 mt-1 uppercase tracking-wider font-medium">Recently recorded giveaway winners</p>
    </div>
    <a href="{{ route('winners.index') }}" class="text-primary hover:text-primaryDeep transition-colors font-bold text-sm flex items-center gap-1">
        View All Winners
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M9 5l7 7-7 7"></path></svg>
    </a>
</div>

<!-- Create Modal -->
<div id="createModal" class="hidden fixed inset-0 bg-gray-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="glass-card w-full max-w-md rounded-3xl p-8 relative border border-bdr bg-white shadow-2xl transition-all duration-300">
        <button onclick="document.getElementById('createModal').classList.add('hidden')" class="absolute top-5 right-5 text-gray-400 hover:text-white p-2 rounded-lg hover:bg-white/5 transition-colors">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>
        
        <div class="mb-6">
            <h3 class="text-2xl font-black text-gray-900 tracking-tight">Create Giveaway</h3>
            <p class="text-xs text-gray-500 mt-1">Start a new session to pick random winners.</p>
        </div>

        <form action="{{ route('giveaways.store') }}" method="POST" class="flex flex-col gap-5">
            @csrf
            <div>
                <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Giveaway Title</label>
                <input type="text" name="title" required class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all shadow-inner placeholder-gray-500" placeholder="e.g. Summer Special 2026">
            </div>
            <div>
                <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Description (Optional)</label>
                <textarea name="description" rows="3" class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all shadow-inner placeholder-gray-500" placeholder="Rules, prizes, or live selection details..."></textarea>
            </div>
            <div>
                <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Facebook Post URL (Optional)</label>
                <input type="url" name="source_url" class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all shadow-inner placeholder-gray-500" placeholder="https://facebook.com/...">
            </div>
            <div>
                <label class="block text-sm text-gray-400 mb-1.5 font-semibold">Wrong Answer Keywords (Optional)</label>
                <input type="text" name="wrong_keyword" class="w-full bg-white/5 border border-gray-300 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all shadow-inner placeholder-gray-500" placeholder="e.g. 2025, No, Orange">
            </div>
            
            <div class="flex gap-3 mt-4">
                <button type="button" onclick="document.getElementById('createModal').classList.add('hidden')" class="flex-1 bg-white/10 hover:bg-white/20 border border-white/10 text-gray-200 py-3 rounded-xl font-bold text-sm transition-all text-center">
                    Cancel
                </button>
                <button type="submit" class="flex-1 bg-primary hover:bg-primaryDark text-white py-3 rounded-xl font-bold text-sm transition-colors shadow-lg shadow-primary/20">
                    Create Session
                </button>
            </div>
        </form>
    </div>
</div>

<script>
let selectedGiveaways = new Set();
let lastSelectedGiveawayIndex = null;
let isManagementMode = false;

async function editGiveawayTitleDashboard(event, idStr) {
    event.stopPropagation();
    const id = parseInt(idStr, 10);
    const titleEl = document.getElementById('dashboard-title-' + id);
    const currentTitle = titleEl.innerText.trim();
    const newTitle = prompt("Enter new Campaign Name:", currentTitle);
    if (newTitle === null || newTitle.trim() === '') return;

    try {
        const response = await fetch(`/giveaways/${id}/update-title`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ title: newTitle.trim() })
        });
        const data = await response.json();
        if (data.success) {
            titleEl.innerText = data.title;
        } else {
            throw new Error();
        }
    } catch (e) {
        appAlert('Failed to update campaign name.');
    }
}

function toggleManagementMode() {
    isManagementMode = !isManagementMode;
    
    const btn = document.getElementById('btn-toggle-manage');
    const selectAllCont = document.getElementById('select-all-container');
    const chkWrappers = document.querySelectorAll('.checkbox-wrapper');
    const delWrappers = document.querySelectorAll('.delete-btn-wrapper');
    
    if (isManagementMode) {
        btn.innerHTML = '❌ Cancel Manage';
        btn.className = "bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm";
        
        if (selectAllCont) selectAllCont.classList.remove('hidden');
        chkWrappers.forEach(w => w.classList.remove('hidden'));
        delWrappers.forEach(w => w.classList.remove('hidden'));
    } else {
        btn.innerHTML = '⚙️ Manage Campaigns';
        btn.className = "bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm";
        
        if (selectAllCont) selectAllCont.classList.add('hidden');
        chkWrappers.forEach(w => w.classList.add('hidden'));
        delWrappers.forEach(w => w.classList.add('hidden'));
        
        // Reset selections when cancelling
        selectedGiveaways.clear();
        document.querySelectorAll('.giveaway-chk').forEach(c => c.checked = false);
        updateGiveawaySelectionUI();
    }
}

function handleGiveawayCheckboxToggle(e, idStr) {
    e.stopPropagation();
    const id = parseInt(idStr, 10);
    if (e.target.checked) {
        selectedGiveaways.add(id);
    } else {
        selectedGiveaways.delete(id);
    }
    updateGiveawaySelectionUI();
}

function handleGiveawayCardClick(e, indexStr, idStr, showUrl) {
    // If click was inside delete button/form or checkbox, ignore
    if (e.target.closest('form') || e.target.type === 'checkbox' || e.target.closest('a') || e.target.closest('button')) return;

    const index = parseInt(indexStr, 10);
    const id = parseInt(idStr, 10);

    if (!isManagementMode) {
        // Default mode: Navigate to details page
        window.location.href = showUrl;
        return;
    }

    // In management mode, handle selections
    if (e.shiftKey && lastSelectedGiveawayIndex !== null) {
        const cards = document.querySelectorAll('.giveaway-card');
        const start = Math.min(index, lastSelectedGiveawayIndex);
        const end = Math.max(index, lastSelectedGiveawayIndex);
        const shouldSelect = !selectedGiveaways.has(id);

        for (let i = start; i <= end; i++) {
            const cardId = parseInt(cards[i].getAttribute('data-id'));
            const chk = document.getElementById(`giveaway-chk-${cardId}`);
            if (shouldSelect) {
                selectedGiveaways.add(cardId);
                if (chk) chk.checked = true;
            } else {
                selectedGiveaways.delete(cardId);
                if (chk) chk.checked = false;
            }
        }
    } else if (e.ctrlKey || e.metaKey) {
        const chk = document.getElementById(`giveaway-chk-${id}`);
        if (selectedGiveaways.has(id)) {
            selectedGiveaways.delete(id);
            if (chk) chk.checked = false;
        } else {
            selectedGiveaways.add(id);
            if (chk) chk.checked = true;
        }
    } else {
        // Toggle selection
        const chk = document.getElementById(`giveaway-chk-${id}`);
        if (selectedGiveaways.has(id)) {
            selectedGiveaways.delete(id);
            if (chk) chk.checked = false;
        } else {
            selectedGiveaways.add(id);
            if (chk) chk.checked = true;
        }
    }

    lastSelectedGiveawayIndex = index;
    updateGiveawaySelectionUI();
}

function toggleSelectAllGiveaways(e) {
    const isChecked = e.target.checked;
    const cards = document.querySelectorAll('.giveaway-card');

    cards.forEach(card => {
        const id = parseInt(card.getAttribute('data-id'));
        const chk = document.getElementById(`giveaway-chk-${id}`);
        if (isChecked) {
            selectedGiveaways.add(id);
            if (chk) chk.checked = true;
        } else {
            selectedGiveaways.delete(id);
            if (chk) chk.checked = false;
        }
    });

    updateGiveawaySelectionUI();
}

function updateGiveawaySelectionUI() {
    const size = selectedGiveaways.size;
    const bar = document.getElementById('bulk-giveaway-bar');

    if (size > 0 && isManagementMode) {
        bar.classList.remove('hidden');
        bar.classList.add('flex');
        document.getElementById('selected-giveaway-count').innerText = size;
    } else {
        bar.classList.remove('flex');
        bar.classList.add('hidden');
    }

    // Sync all checkboxes currently on the screen
    document.querySelectorAll('.giveaway-chk').forEach(chk => {
        const id = parseInt(chk.id.replace('giveaway-chk-', ''));
        chk.checked = selectedGiveaways.has(id);
    });

    const masterSelect = document.getElementById('dashboard-select-all');
    if (masterSelect) {
        const cards = document.querySelectorAll('.giveaway-card');
        masterSelect.checked = cards.length > 0 && Array.from(cards).every(card => {
            const id = parseInt(card.getAttribute('data-id'));
            return selectedGiveaways.has(id);
        });
    }
}

async function bulkDeleteGiveaways() {
    if (selectedGiveaways.size === 0) return;
    
    const confirmed = await appConfirm(`Are you sure to delete the ${selectedGiveaways.size} selected giveaways? They will be moved to the Trash.`);
    if (!confirmed) return;

    try {
        const response = await fetch("{{ route('giveaways.bulkDestroy') }}", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ ids: Array.from(selectedGiveaways) })
        });
        
        if (response.ok) {
            window.location.reload();
        } else {
            appAlert('Error deleting giveaways');
        }
    } catch (e) {
        appAlert('Error deleting giveaways');
    }
}

async function createGiveaway() {
    const title = document.getElementById('new-giveaway-title').value;
    const desc = document.getElementById('new-giveaway-desc').value;
    
    if (!title.trim()) {
        appAlert('Giveaway Title is required');
        return;
    }
}

async function deleteSelectedGiveaways() {
    await bulkDeleteGiveaways();
}
</script>
@endsection

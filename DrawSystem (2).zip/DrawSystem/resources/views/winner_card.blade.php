@extends('layouts.app')

@section('content')
<div class="flex flex-col items-center justify-center min-h-[80vh] px-4">
    <div class="mb-8 text-center">
        <h2 class="text-3xl font-black text-gray-900 tracking-tight">Winner Card</h2>
        <p class="text-xs text-gray-500 mt-1 uppercase tracking-wider font-medium">Download or share this official winner record</p>
    </div>

    <!-- The exact same cyber-card UI from draw.blade.php -->
    <div id="winner-ui-wrapper" class="w-full max-w-sm relative z-50 pointer-events-auto">
        <div id="capture-area" class="w-full rounded-3xl transition-all duration-0">
            <div class="text-center mb-4">
                <div class="inline-block px-5 py-1.5 bg-gradient-to-r from-yellow-400 to-yellow-500 border border-yellow-300 rounded-full shadow-md animate-float">
                    <h3 class="text-xs md:text-sm font-black text-yellow-950 uppercase tracking-[0.2em] drop-shadow-sm">{{ !empty($winner->giveaway->custom_winner_title) ? $winner->giveaway->custom_winner_title : 'WINNER' }}</h3>
                </div>
            </div>

            <div class="cyber-container w-full">
            <div id="winner-card" class="cyber-card glass-panel rounded-[2.5rem] border-2 border-primary/30 shadow-[0_0_50px_rgba(0,166,81,0.2)] w-full relative overflow-hidden bg-gray-900">
                <div class="card-glare"></div>
                <div class="cyber-lines"><span></span><span></span><span></span><span></span></div>
                <div class="corner-elements"><span></span><span></span><span></span><span></span></div>

                <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-mint/20 via-transparent to-transparent pointer-events-none"></div>

                <div class="cyber-content-wrapper p-6 md:p-8 flex flex-col justify-center items-center text-center">
                    <div class="relative z-10 flex flex-col items-center">
                        <svg class="w-12 h-12 text-yellow-400 mb-[-12px] relative z-20 drop-shadow-md" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M5 16L3 5l5.5 5L12 4l3.5 6L21 5l-2 11H5zm14 3c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1v-1h14v1z"></path>
                        </svg>

                        <div class="relative group cursor-pointer" onclick="document.getElementById('avatar-upload').click()" title="Click to change image">
                            @if($winner->participant && $winner->participant->profile_pic_url)
                                <img id="winner-avatar" src="{{ preg_replace('/\/[sp]\d+x\d+\//', '/s600x600/', $winner->participant->profile_pic_url) }}" class="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-white ring-2 ring-yellow-400 shadow-[0_0_30px_rgba(255,210,42,0.4)] object-cover animate-scale-up" alt="Winner Avatar">
                            @else
                                <div id="winner-avatar-fallback" class="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-white ring-2 ring-yellow-400 shadow-[0_0_30px_rgba(255,210,42,0.4)] bg-primary/20 text-primary flex items-center justify-center text-4xl font-black">
                                    {{ mb_substr($winner->winner_name, 0, 1) }}
                                </div>
                                <img id="winner-avatar" src="" class="hidden w-32 h-32 rounded-full mx-auto mb-4 border-4 border-white ring-2 ring-yellow-400 shadow-[0_0_30px_rgba(255,210,42,0.4)] object-cover animate-scale-up" alt="Winner Avatar">
                            @endif
                            <div class="absolute inset-0 bg-black/50 rounded-full mb-4 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity border-4 border-transparent">
                                <svg class="w-8 h-8 text-white drop-shadow-md" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                            </div>
                        </div>
                        <input type="file" id="avatar-upload" class="hidden" accept="image/*" onchange="updateAvatar(event)">

                        <h1 class="text-2xl md:text-3xl font-black mb-3 drop-shadow-sm break-words leading-tight text-center max-w-full">
                            <span class="text-white">{{ $winner->winner_name }}</span>
                        </h1>

                        <div class="w-full bg-black/30 backdrop-blur-md p-3 rounded-2xl border border-white/20 shadow-inner mt-1">
                            <p class="text-[#4ade80] font-bold text-[10px] md:text-xs uppercase tracking-[0.15em] mb-1">Entry Comment</p>
                            <p class="text-base md:text-lg text-white italic font-bold leading-relaxed">"{{ $winner->winner_comment ?: 'No comment' }}"</p>
                        </div>
                        
                        <p class="text-[10px] text-gray-500 mt-4 uppercase tracking-wider font-bold">
                            Drawn on {{ $winner->selected_at->format('M d, Y') }}
                        </p>
                    </div>
                </div>
            </div>
        </div>
        </div>
        
        <div class="mt-8 flex gap-4 w-full">
            <a href="{{ route('winners.index') }}" class="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 py-3 rounded-xl font-bold text-sm shadow-sm transition-all flex items-center justify-center gap-2 border-b-2 border-gray-400 active:border-b-0 active:mt-0.5 select-none cursor-pointer">
                Back to History
            </a>
            <button id="download-btn" class="flex-1 bg-primary hover:bg-primaryDark text-white py-3 rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 border-b-2 border-primaryDark active:border-b-0 active:mt-0.5 select-none cursor-pointer">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                </svg>
                <span id="download-text">Download PNG</span>
            </button>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const downloadBtn = document.getElementById('download-btn');
        if (downloadBtn) {
            downloadBtn.onclick = async () => {
                const originalText = document.getElementById('download-text').textContent;
                document.getElementById('download-text').textContent = 'Generating...';
                downloadBtn.style.pointerEvents = 'none';
                downloadBtn.style.opacity = '0.7';

                try {
                    const card = document.getElementById('capture-area');

                    const canvas = await html2canvas(card, {
                        backgroundColor: '#064e3b',
                        scale: 2,
                        useCORS: true,
                        allowTaint: true,
                        logging: false,
                        onclone: (clonedDoc) => {
                            const clonedCard = clonedDoc.getElementById('capture-area');
                            clonedCard.style.padding = '40px';
                            clonedCard.style.background = '#064e3b';
                            
                            // Remove hover overlay in clone if it somehow got captured
                            const overlays = clonedCard.querySelectorAll('.group-hover\\:opacity-100');
                            overlays.forEach(el => el.style.display = 'none');
                        }
                    });

                    const image = canvas.toDataURL("image/png");
                    const link = document.createElement('a');
                    link.download = 'winner_{{ preg_replace("/\s+/", "_", $winner->winner_name) }}.png';
                    link.href = image;
                    link.click();
                    
                    document.getElementById('download-text').textContent = 'Downloaded!';
                    setTimeout(() => {
                        document.getElementById('download-text').textContent = originalText;
                        downloadBtn.style.pointerEvents = 'auto';
                        downloadBtn.style.opacity = '1';
                    }, 3000);
                } catch (e) {
                    console.error(e);
                    alert('Could not generate image.');
                    document.getElementById('download-text').textContent = originalText;
                    downloadBtn.style.pointerEvents = 'auto';
                    downloadBtn.style.opacity = '1';
                }
            };
        }
    });

    function updateAvatar(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.getElementById('winner-avatar');
                const fallback = document.getElementById('winner-avatar-fallback');
                if (fallback) fallback.classList.add('hidden');
                img.src = e.target.result;
                img.classList.remove('hidden');
            }
            reader.readAsDataURL(file);
        }
    }
</script>
@endpush

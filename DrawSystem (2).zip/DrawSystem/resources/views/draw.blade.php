@extends('layouts.app')

@push('styles')
<style>
    .slot-container {
        height: 150px;
        position: relative;
        overflow: hidden;
        mask-image: linear-gradient(to bottom, transparent, black 15%, black 85%, transparent);
        -webkit-mask-image: linear-gradient(to bottom, transparent, black 15%, black 85%, transparent);
    }

    .slot-track {
        position: relative;
        width: 100%;
    }

    .slot-item {
        position: absolute;
        width: 100%;
        height: 150px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-size: 3.5rem;
        font-weight: 900;
        color: rgba(255, 255, 255, 0.15);
        transition: all 0.3s ease;
        text-align: center;
        white-space: nowrap;
    }

    .slot-item.winner {
        color: var(--primary);
        text-shadow: 0 0 30px rgba(0, 166, 81, 0.4);
        transform: scale(1.1);
    }

    .slot-item-comment {
        font-size: 1.25rem;
        font-weight: normal;
        color: #a1a09a;
        margin-top: 0.5rem;
        opacity: 0;
        transition: opacity 0.5s ease;
    }

    .slot-item.winner .slot-item-comment {
        opacity: 1;
    }

    #confetti-canvas {
        position: fixed;
        inset: 0;
        pointer-events: none;
        z-index: 100;
    }

    @keyframes pulseGlow {

        0%,
        100% {
            box-shadow: 0 10px 40px -10px rgba(0, 166, 81, 0.4);
        }

        50% {
            box-shadow: 0 15px 50px -5px rgba(0, 166, 81, 0.7);
        }
    }

    .pulse-glow-btn {
        animation: pulseGlow 2s infinite ease-in-out;
    }

    @keyframes float {

        0%,
        100% {
            transform: translateY(0);
        }

        50% {
            transform: translateY(-8px);
        }
    }

    .animate-float {
        animation: float 6s ease-in-out infinite;
    }

    @keyframes slideUpFade {
        0% {
            opacity: 0;
            transform: translateY(30px) scale(0.95);
        }

        100% {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }

    .animate-slide-up {
        animation: slideUpFade 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }

    @keyframes jarSpinFast {
        0% {
            transform: scale(1.1) rotate(0deg);
        }

        50% {
            transform: scale(1.3) rotate(180deg);
        }

        100% {
            transform: scale(1.1) rotate(360deg);
        }
    }

    @keyframes jarShake {

        0%,
        100% {
            transform: translateX(0) scale(1);
        }

        25% {
            transform: translateX(-4px) scale(1.02);
        }

        50% {
            transform: translateX(4px) scale(1.02);
        }

        75% {
            transform: translateX(-4px) scale(1.02);
        }
    }

    @keyframes avatarDrop {
        0% {
            transform: translateY(-50px) scale(1);
            opacity: 0;
        }

        20% {
            opacity: 1;
        }

        80% {
            transform: translateY(120px) scale(0.6);
            opacity: 0.8;
        }

        100% {
            transform: translateY(160px) scale(0.4);
            opacity: 0;
        }
    }

    .jar-container {
        position: relative;
        width: 220px;
        height: 250px;
        margin: 0 auto;
        cursor: pointer;
        transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    .jar-container:hover {
        transform: scale(1.05);
    }

    .jar-image {
        width: 100%;
        height: 100%;
        object-fit: contain;
        position: relative;
        z-index: 20;
        filter: drop-shadow(0 10px 25px rgba(0, 166, 81, 0.4));
        transition: filter 0.3s ease;
    }

    .jar-container.full .jar-image {
        filter: drop-shadow(0 0 30px rgba(255, 210, 42, 0.8)) brightness(1.2);
        animation: jarShake 0.5s ease-in-out infinite;
    }

    .jar-particles {
        position: absolute;
        inset: 0;
        z-index: 10;
        overflow: hidden;
    }

    .particle-avatar {
        position: absolute;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: 2px solid white;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        object-fit: cover;
        opacity: 0;
    }

    .spinning-jar {
        animation: jarSpinFast 1.5s linear infinite;
    }

    .glass-panel {
        background: rgba(0, 0, 0, 0.35);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.1) inset;
        color: white;
    }

    /* Cyber Card 3D Effect */
    .cyber-container {
        display: grid;
        width: 100%;
        transition: 200ms;
        perspective: 1500px;
    }

    .cyber-card {
        grid-area: 1 / 1;
        z-index: 10;
        transition: transform 0.1s ease-out, filter 0.1s ease-out;
    }

    .cyber-card.resetting {
        transition: transform 0.5s cubic-bezier(0.23, 1, 0.32, 1), filter 0.5s ease-out;
    }

    .cyber-content-wrapper {
        position: relative;
        z-index: 30;
        height: 100%;
    }

    .card-glare {
        position: absolute;
        inset: 0;
        background: linear-gradient(125deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.05) 45%, rgba(255, 255, 255, 0.1) 50%, rgba(255, 255, 255, 0.05) 55%, rgba(255, 255, 255, 0) 100%);
        opacity: 0;
        transition: opacity 300ms;
        pointer-events: none;
        border-radius: inherit;
    }

    .cyber-container:hover .card-glare {
        opacity: 1;
    }

    .cyber-lines span {
        position: absolute;
        background: linear-gradient(90deg, transparent, rgba(0, 255, 170, 0.4), transparent);
        pointer-events: none;
        border-radius: inherit;
    }

    .cyber-lines span:nth-child(1) {
        top: 20%;
        left: 0;
        width: 100%;
        height: 1px;
        animation: lineGrow 3s linear infinite;
    }

    .cyber-lines span:nth-child(2) {
        top: 40%;
        right: 0;
        width: 100%;
        height: 1px;
        animation: lineGrow 3s linear infinite 1s;
    }

    .cyber-lines span:nth-child(3) {
        top: 60%;
        left: 0;
        width: 100%;
        height: 1px;
        animation: lineGrow 3s linear infinite 2s;
    }

    .cyber-lines span:nth-child(4) {
        top: 80%;
        right: 0;
        width: 100%;
        height: 1px;
        animation: lineGrow 3s linear infinite 1.5s;
    }

    .corner-elements span {
        position: absolute;
        width: 20px;
        height: 20px;
        border: 2px solid rgba(0, 255, 170, 0.3);
        transition: all 0.3s ease;
        pointer-events: none;
    }

    .corner-elements span:nth-child(1) {
        top: 15px;
        left: 15px;
        border-right: 0;
        border-bottom: 0;
    }

    .corner-elements span:nth-child(2) {
        top: 15px;
        right: 15px;
        border-left: 0;
        border-bottom: 0;
    }

    .corner-elements span:nth-child(3) {
        bottom: 15px;
        left: 15px;
        border-right: 0;
        border-top: 0;
    }

    .corner-elements span:nth-child(4) {
        bottom: 15px;
        right: 15px;
        border-left: 0;
        border-top: 0;
    }

    .cyber-container:hover .corner-elements span {
        border-color: rgba(0, 255, 170, 0.9);
        box-shadow: 0 0 15px rgba(0, 255, 170, 0.6);
    }

    .scan-line {
        position: absolute;
        inset: 0;
        background: linear-gradient(to bottom, transparent, rgba(0, 255, 170, 0.15), transparent);
        transform: translateY(-100%);
        animation: scanMove 2.5s linear infinite;
        pointer-events: none;
        border-radius: inherit;
        z-index: 5;
    }

    @keyframes lineGrow {
        0% {
            transform: scaleX(0);
            opacity: 0;
        }

        50% {
            transform: scaleX(1);
            opacity: 1;
        }

        100% {
            transform: scaleX(0);
            opacity: 0;
        }
    }

    @keyframes scanMove {
        0% {
            transform: translateY(-100%);
        }

        100% {
            transform: translateY(100%);
        }
    }
</style>
@endpush

@section('content')
<div id="draw-container" class="fixed inset-0 w-full flex flex-col justify-center items-center overflow-hidden text-white px-4 z-30 transition-all duration-500" {!! $giveaway->custom_background_url ? 'style="background-image: url(\'' . asset('storage/' . $giveaway->custom_background_url) . '\'); background-size: cover; background-position: center; height: 100dvh;"' : 'style="background-color: #005535; height: 100dvh;"' !!}>


    <!-- Presentation Mode Toggle -->
    <button onclick="togglePresentationMode()" class="absolute top-6 right-6 text-white/50 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10" title="Toggle Full Display">
        <svg id="fullscreen-icon" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path>
        </svg>
    </button>
    <!-- Initial State -->
    <div id="setup-screen" class="text-center w-full max-w-lg mx-auto z-10 px-4">
        <div class="cyber-container">
            <div class="cyber-card glass-panel rounded-[2.5rem] border border-white/20 overflow-hidden shadow-2xl">
                <div class="card-glare"></div>
                <div class="cyber-lines"><span></span><span></span><span></span><span></span></div>
                <div class="corner-elements"><span></span><span></span><span></span><span></span></div>
                <div class="scan-line"></div>

                <div class="cyber-content-wrapper p-8 md:p-10 flex flex-col justify-center items-center">
                    @if($giveaway->custom_logo_url)
                        <img src="{{ asset('storage/' . $giveaway->custom_logo_url) }}" class="h-24 md:h-32 w-auto mb-4 pointer-events-none drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]" alt="Campaign Logo">
                    @else
                        <img src="{{ asset('images/logo.png') }}" class="h-24 md:h-32 w-auto mb-4 pointer-events-none drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]" alt="Draw Engine Logo">
                    @endif
                    
                    @if($giveaway->custom_title)
                        <h2 class="text-3xl md:text-4xl font-black mb-2 text-white drop-shadow-sm pointer-events-auto">{{ $giveaway->custom_title }}</h2>
                    @endif
                    
                    @if($giveaway->custom_subtitle)
                        <p class="text-lg text-gray-200 mb-6 pointer-events-auto">{{ $giveaway->custom_subtitle }}</p>
                    @endif

                    <div class="mb-8 text-left w-full pointer-events-auto relative z-40">
                        <label for="required-keyword" class="block text-sm font-bold text-gray-200 mb-2">Required Keyword (Optional)</label>
                        <input type="text" id="required-keyword" value="{{ $giveaway->required_keyword }}" class="w-full bg-black/40 border border-white/20 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-white focus:ring-2 focus:ring-white/20 transition-all placeholder-gray-400 shadow-sm" placeholder="e.g. 2026, Yes, Apple">
                        <p class="text-xs text-gray-300 mt-2 font-medium">If provided, only participants whose comments contain at least one of these keywords (comma-separated) will be eligible.</p>
                    </div>

                    <button id="analyze-btn" class="w-full bg-primary hover:bg-primaryDark text-white px-12 py-6 rounded-2xl font-black text-2xl transition-all transform hover:-translate-y-2 active:scale-95 flex items-center justify-center gap-3 tracking-wide border-b-4 border-primaryDeep active:border-b-0 active:mt-1 pulse-glow-btn pointer-events-auto relative z-40">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                        </svg>
                        ANALYZE DATA
                    </button>
                    <div class="mt-8 pointer-events-auto relative z-40">
                        <a href="{{ route('giveaways.show', $giveaway) }}" class="text-gray-400 hover:text-white transition-colors text-sm uppercase tracking-widest font-bold">← Cancel</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Loading Screen -->
    <div id="loading-screen" class="hidden text-center w-full max-w-sm mx-auto z-10 px-4">
        <div class="cyber-container">
            <div class="cyber-card glass-panel rounded-[2.5rem] border border-white/20 overflow-hidden shadow-2xl flex flex-col justify-center items-center py-16">
                <div class="card-glare"></div>
                <div class="cyber-lines"><span></span><span></span><span></span><span></span></div>
                <div class="corner-elements"><span></span><span></span><span></span><span></span></div>
                <div class="scan-line"></div>
                <div class="cyber-content-wrapper flex flex-col items-center pointer-events-auto w-full">
                    <svg class="animate-spin w-16 h-16 text-primary mb-6 drop-shadow-[0_0_15px_rgba(0,166,81,0.8)]" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <h3 id="loading-text" class="text-xl font-black text-white uppercase tracking-[0.2em] animate-pulse">PROCESSING...</h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Data Summary Screen -->
    <div id="summary-screen" class="hidden text-center w-full max-w-sm mx-auto z-10 px-4">
        <div class="cyber-container">
            <div class="cyber-card glass-panel rounded-[2.5rem] border border-white/20 overflow-hidden shadow-2xl relative">
                <!-- Particles Container -->
                <div id="summary-card-particles" class="absolute inset-0 z-0 pointer-events-none overflow-hidden"></div>

                <div class="card-glare"></div>
                <div class="cyber-lines"><span></span><span></span><span></span><span></span></div>
                <div class="corner-elements"><span></span><span></span><span></span><span></span></div>
                <div class="scan-line"></div>

                <div class="cyber-content-wrapper p-6 md:p-8 flex flex-col justify-center items-center relative z-10 bg-black/30 rounded-[2.5rem] m-2 shadow-2xl backdrop-blur-xl border border-white/10">
                    <h2 class="text-3xl font-black mb-6 text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.8)] uppercase tracking-wider pointer-events-auto">Draw Summary</h2>

                    <div class="flex flex-col gap-4 mb-8 w-full pointer-events-auto relative z-40">
                        <!-- Total Participant -->
                        <div class="bg-blue-500/20 rounded-2xl p-4 border border-blue-500/30 flex justify-between items-center shadow-sm">
                            <span class="text-sm font-bold text-blue-300 uppercase tracking-wider">Total Participant</span>
                            <span class="text-3xl font-black text-blue-400 block leading-none" id="summary-total">0</span>
                        </div>
                        <!-- Disqualified (Hidden) -->
                        <div class="hidden bg-red-500/20 rounded-2xl p-4 border border-red-500/30 justify-between items-center shadow-sm">
                            <span class="text-sm font-bold text-red-300 uppercase tracking-wider">Total Wrong Answer</span>
                            <div class="text-right">
                                <span class="text-2xl font-black text-red-400 block leading-none" id="summary-disq">0</span>
                                <span class="hidden text-xs font-bold text-red-300" id="summary-disq-pct">0%</span>
                            </div>
                        </div>
                        <!-- Qualified -->
                        <div class="bg-green-500/20 rounded-2xl p-4 border border-green-500/30 flex justify-between items-center shadow-sm relative overflow-hidden">
                            <div class="absolute inset-0 bg-gradient-to-r from-transparent via-green-400/20 to-transparent -translate-x-full animate-[shimmer_2s_infinite]"></div>
                            <span class="text-sm font-bold text-green-300 uppercase tracking-wider z-10 relative">Total Correct Answer</span>
                            <div class="text-right z-10 relative">
                                <span class="text-3xl font-black text-green-400 block leading-none" id="summary-qual">0</span>
                                <span class="hidden text-xs font-bold text-green-300" id="summary-qual-pct">0%</span>
                            </div>
                        </div>
                    </div>

                    <button id="start-btn" class="w-full bg-primary hover:bg-primaryDark text-white px-8 py-5 rounded-2xl font-black text-xl transition-all transform hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-3 tracking-wide border-b-4 border-primaryDeep active:border-b-0 active:mt-1 pulse-glow-btn pointer-events-auto relative z-40 mt-4">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        SELECT WINNER
                    </button>
                    <button type="button" onclick="switchScreenSmooth('summary-screen', 'setup-screen')" class="text-gray-400 hover:text-white transition-colors text-sm uppercase tracking-widest font-bold">← Back</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Draw Animation Screen -->
<div id="draw-screen" class="hidden text-center w-full max-w-3xl mx-auto z-10 px-4">
    <div class="text-center mb-8">
        <h3 class="text-2xl md:text-3xl font-black text-white animate-pulse tracking-[0.3em] uppercase drop-shadow-sm pointer-events-auto">Processing Draw</h3>
    </div>

    <div class="cyber-container w-full h-[60vh] min-h-[500px]">
        <div class="cyber-card bg-black/80 rounded-[2.5rem] border border-white/20 shadow-2xl w-full h-full">
            <div class="card-glare"></div>
            <div class="cyber-lines"><span></span><span></span><span></span><span></span></div>
            <div class="corner-elements"><span></span><span></span><span></span><span></span></div>
            <div class="scan-line"></div>

            <div class="cyber-content-wrapper p-6 md:p-8 flex flex-col justify-center items-center w-full h-full relative">
                <div id="spinning-card-container" class="absolute inset-0 w-full h-full pointer-events-none z-10 flex items-center justify-center">
                    <div id="draw-card-particles" class="w-full h-full relative overflow-visible"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Winner Reveal Screen -->
<div id="winner-screen" class="hidden text-center w-full mx-auto flex flex-col justify-center items-center z-50 px-4 relative mt-12 max-w-7xl">
    <div id="winner-ui-wrapper" class="w-full flex flex-col items-center opacity-0 transition-opacity duration-700 pointer-events-none relative z-50">
        
        <div id="capture-area" class="w-full rounded-3xl transition-all duration-0 flex flex-col items-center">
            <div id="winner-banner-btn" class="inline-block px-5 py-1.5 bg-gradient-to-r from-yellow-400 to-yellow-500 border border-yellow-300 rounded-full mb-4 shadow-md animate-float pointer-events-auto cursor-pointer select-none">
                <h3 class="text-xs md:text-sm font-black text-yellow-950 uppercase tracking-[0.2em] drop-shadow-sm">{{ !empty($giveaway->custom_winner_title) ? $giveaway->custom_winner_title : 'WINNER' }}</h3>
            </div>

            <div class="cyber-container w-full max-w-4xl" id="main-cyber-container">
                <div id="winner-card" class="cyber-card glass-panel rounded-[2rem] sm:rounded-[2.5rem] border border-white/20 overflow-hidden shadow-2xl w-full relative z-10 transition-all duration-700 scale-0 opacity-0">
                    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-mint/20 via-transparent to-transparent pointer-events-none"></div>

                    <div class="cyber-content-wrapper p-4 sm:p-6 md:p-8 flex flex-col justify-center items-center w-full">
                        
                        <!-- Master Slot Machine Window -->
                        <div id="master-swiper-container" class="inline-flex max-w-full h-32 sm:h-40 mb-4 sm:mb-6 relative overflow-hidden bg-black/40 rounded-2xl sm:rounded-[2rem] border-2 border-primary/50 shadow-inner items-center justify-center transition-all duration-700 hidden pointer-events-auto mx-auto">
                            <!-- Horizontal Target Line -->
                            <div class="absolute top-1/2 left-0 right-0 h-1 bg-yellow-400 z-20 shadow-[0_0_15px_#FFD22A] -translate-y-1/2 pointer-events-none"></div>
                            
                            <!-- Vertical Reels injected here -->
                            <div id="reels-container" class="flex flex-row items-center justify-center relative z-10 overflow-hidden h-full">
                                <!-- Reels go here -->
                            </div>
                        </div>

                        <!-- Winner Details Grid (Populated after spinning) -->
                        <div id="winner-details-grid" class="w-full flex flex-wrap justify-center items-stretch gap-3 sm:gap-6 pointer-events-auto mt-2 sm:mt-4">
                            <!-- Winner detail cards go here -->
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div id="winner-actions-box" class="mt-6 flex flex-col gap-2 w-full max-w-sm relative z-10 pointer-events-auto transition-all duration-500 !hidden" style="display: none !important;">
            <div class="flex gap-2">
                <div class="relative hidden" id="disqualify-wrapper">
                    <!-- Disqualify handled collectively or via other logic -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Template for a vertical reel (track) -->
<template id="reel-template">
    <div class="reel-wrapper shrink w-20 sm:w-28 h-full relative overflow-hidden flex flex-col items-center border-r border-white/10 last:border-r-0">
        <div class="swiper-track flex flex-col w-full items-center absolute top-1/2 transition-transform"></div>
    </div>
</template>

<!-- Template for a winner detail card -->
<template id="winner-detail-template">
    <div class="winner-detail-card shrink-0 w-32 sm:w-40 relative flex flex-col items-center bg-black/20 rounded-2xl p-3 border border-white/10 transition-all duration-700 opacity-0 transform translate-y-4">
        
        <div class="relative group cursor-pointer avatar-upload-trigger" title="Click to change image">
            <img class="winner-avatar w-12 h-12 sm:w-16 sm:h-16 rounded-full mx-auto mb-2 border-2 border-white ring-1 ring-yellow-400 shadow-md object-cover animate-scale-up" alt="Winner Avatar">
            <div class="absolute inset-0 bg-black/50 rounded-full mb-2 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity border-2 border-transparent hidden avatar-hover-overlay">
                <svg class="w-6 h-6 text-white drop-shadow-md" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
            </div>
        </div>
        <input type="file" class="avatar-upload hidden" accept="image/*">

        <h1 class="text-sm sm:text-base font-black mb-1 drop-shadow-sm break-words leading-tight text-center max-w-full">
            <a href="#" target="_blank" class="winner-name text-white hover:text-gray-200 transition-colors decoration-yellow-400 underline-offset-2 pointer-events-none animate-pulse">Selecting...</a>
        </h1>

        <div class="winner-comment-box w-full bg-black/30 backdrop-blur-md p-2 rounded-xl border border-white/10 shadow-inner mt-1 transition-all duration-500 opacity-0 flex-1 flex flex-col justify-center">
            <p class="winner-comment text-[10px] sm:text-xs text-white italic font-medium leading-relaxed line-clamp-3">""</p>
        </div>
    </div>
</template>

<!-- Fullscreen Prompt Modal -->
<div id="fullscreen-prompt" class="fixed inset-0 z-[100] hidden bg-gray-900/90 backdrop-blur-md flex items-center justify-center p-4 transition-all duration-300">
    <div class="glass-panel p-8 md:p-12 rounded-[2rem] max-w-lg w-full text-center shadow-2xl animate-scale-up border border-white/20 relative overflow-hidden">
        <!-- background glow -->
        <div class="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent pointer-events-none"></div>

        <div class="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-primary/50 relative z-10">
            <svg class="w-10 h-10 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path>
            </svg>
        </div>

        <h3 class="text-3xl font-black text-white mb-4 relative z-10">Immersive Experience</h3>
        <p class="text-gray-300 mb-8 font-medium relative z-10 text-sm md:text-base">For the best possible experience, we recommend running the Draw Engine in true fullscreen mode.</p>

        <div class="flex flex-col gap-3 relative z-10">
            <button onclick="acceptFullscreen()" class="w-full bg-primary hover:bg-primaryDark text-white py-4 rounded-xl font-bold text-lg transition-all transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                </svg>
                Start in Fullscreen
            </button>
            <button onclick="declineFullscreen()" class="w-full bg-white/10 hover:bg-white/20 text-white py-3.5 rounded-xl font-bold transition-all text-sm border border-white/10">
                Continue in Standard Mode
            </button>
        </div>
    </div>
</div>
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
    async function switchScreenSmooth(fromId, toId) {
        const fromEl = document.getElementById(fromId);
        const toEl = document.getElementById(toId);

        if (!fromEl || !toEl) return;

        // Prepare toEl immediately to prevent the screen from ever being completely empty
        toEl.classList.remove('hidden');
        toEl.style.transition = 'none';
        toEl.style.opacity = '0';
        toEl.style.transform = 'translateY(10px) scale(0.98) translateZ(0)';
        toEl.style.willChange = 'opacity, transform';
        
        // Force reflow
        void toEl.offsetWidth; 

        // Crossfade: Fade out fromEl, but don't wait for it to finish before showing toEl
        fromEl.style.position = 'absolute';
        fromEl.style.transition = 'opacity 0.2s ease, transform 0.2s ease';
        fromEl.style.opacity = '0';
        fromEl.style.transform = 'translateY(-10px) scale(0.98) translateZ(0)';

        // Fade in toEl concurrently
        toEl.style.transition = 'opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
        toEl.style.opacity = '1';
        toEl.style.transform = 'translateY(0) scale(1) translateZ(0)';

        // Wait for animations to finish
        await new Promise(r => setTimeout(r, 400));

        fromEl.classList.add('hidden');
        fromEl.style = '';
        
        toEl.style.transition = '';
    }

    function shootConfetti() {
        var canvas = document.getElementById('confetti-canvas');
        if (!canvas) {
            canvas = document.createElement('canvas');
            canvas.id = 'confetti-canvas';
            canvas.style.position = 'absolute';
            canvas.style.top = '0';
            canvas.style.left = '0';
            canvas.style.width = '100%';
            canvas.style.height = '100%';
            canvas.style.pointerEvents = 'none';
            canvas.style.zIndex = '9999';
            document.getElementById('draw-container').appendChild(canvas);
        }
        var customConfetti = confetti.create(canvas, {
            resize: true,
            useWorker: true
        });

        var duration = 40 * 1000; // 40 seconds
        var animationEnd = Date.now() + duration;
        var defaults = {
            startVelocity: 30,
            spread: 360,
            ticks: 60,
            zIndex: 9999
        };

        function randomInRange(min, max) {
            return Math.random() * (max - min) + min;
        }

        // Firework blasts & Side Sprays
        var interval = setInterval(function() {
            var timeLeft = animationEnd - Date.now();
            if (timeLeft <= 0) return clearInterval(interval);

            var particleCount = 80 * (timeLeft / duration);

            // Left Cannon
            customConfetti({
                particleCount: particleCount,
                angle: 60,
                spread: 55,
                origin: {
                    x: 0,
                    y: 0.9
                },
                colors: ['#00A651', '#ffffff', '#FFD22A', '#f59e0b', '#FF3B30'],
                zIndex: 9999
            });
            // Right Cannon
            customConfetti({
                particleCount: particleCount,
                angle: 120,
                spread: 55,
                origin: {
                    x: 1,
                    y: 0.9
                },
                colors: ['#00A651', '#ffffff', '#FFD22A', '#f59e0b', '#FF3B30'],
                zIndex: 9999
            });

            // Random sky fireworks
            if (Math.random() > 0.4) {
                customConfetti({
                    ...defaults,
                    particleCount: 60,
                    origin: {
                        x: randomInRange(0.1, 0.9),
                        y: randomInRange(0.1, 0.4)
                    },
                    colors: ['#FFD22A', '#ffffff', '#00A651'],
                    zIndex: 9999
                });
            }
        }, 300);

        // Initial Massive Central Bursts
        const colors = ['#FFD22A', '#ffffff', '#00A651', '#FF3B30', '#f59e0b'];

        // Burst 1
        customConfetti({
            particleCount: 200,
            spread: 120,
            origin: {
                y: 0.6
            },
            colors: colors,
            zIndex: 9999
        });

        // Burst 2 (delay)
        setTimeout(() => {
            customConfetti({
                particleCount: 300,
                spread: 180,
                startVelocity: 45,
                origin: {
                    y: 0.6
                },
                colors: colors,
                zIndex: 9999
            });
        }, 400);

        // Burst 3 (Golden rain)
        setTimeout(() => {
            customConfetti({
                particleCount: 400,
                spread: 360,
                startVelocity: 60,
                origin: {
                    y: 0.4
                },
                colors: ['#FFD22A', '#F59E0B', '#ffffff'],
                zIndex: 9999
            });
        }, 800);

        // Continuous falling Glitter/Snow
        (function frame() {
            var timeLeft = animationEnd - Date.now();
            if (timeLeft > 0) {
                customConfetti({
                    particleCount: 15,
                    angle: 90,
                    spread: 360,
                    startVelocity: 20,
                    origin: {
                        x: Math.random(),
                        y: -0.1
                    },
                    colors: ['#ffffff', '#FFD22A', '#F59E0B'],
                    shapes: ['circle', 'square'],
                    gravity: 0.7,
                    scalar: 0.9,
                    zIndex: 9999
                });
                requestAnimationFrame(frame);
            }
        }());
    }


    document.getElementById('analyze-btn').addEventListener('click', async () => {
        const btn = document.getElementById('analyze-btn');
        btn.disabled = true;

        const loadingText = document.getElementById('loading-text');
        if (loadingText) loadingText.textContent = 'ANALYZING DATA...';
        await switchScreenSmooth('setup-screen', 'loading-screen');

        try {
            const keyword = document.getElementById('required-keyword').value;
            const response = await fetch("{{ route('draw.summary', $giveaway) }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    keyword: keyword
                })
            });

            const data = await response.json();

            if (!data.success) {
                appAlert(data.error);
                await switchScreenSmooth('loading-screen', 'setup-screen');
                btn.disabled = false;
                return;
            }

            // Populate summary
            const sum = data.summary;
            const trueDisqualified = sum.total - sum.qualified;

            document.getElementById('summary-total').innerText = sum.total;
            document.getElementById('summary-disq').innerText = trueDisqualified;
            document.getElementById('summary-disq-pct').innerText = (sum.total > 0 ? Math.round((trueDisqualified / sum.total) * 100) : 0) + '%';
            document.getElementById('summary-qual').innerText = sum.qualified;
            document.getElementById('summary-qual-pct').innerText = (sum.total > 0 ? Math.round((sum.qualified / sum.total) * 100) : 0) + '%';

            await switchScreenSmooth('loading-screen', 'summary-screen');
            animateSkyDrop(data.participants);

            btn.disabled = false;

        } catch (e) {
            appAlert('An error occurred. Ensure your database is connected.');
            await switchScreenSmooth('loading-screen', 'setup-screen');
            btn.disabled = false;
        }
    });

    document.getElementById('start-btn').addEventListener('click', async () => {
        const btn = document.getElementById('start-btn');
        btn.disabled = true;

        const loadingText = document.getElementById('loading-text');
        if (loadingText) loadingText.textContent = 'CONNECTING...';

        const winnerScreen = document.getElementById('winner-screen');
        if (!winnerScreen.classList.contains('hidden')) {
            await switchScreenSmooth('winner-screen', 'loading-screen');
        } else {
            await switchScreenSmooth('summary-screen', 'loading-screen');
        }

        try {
            const keyword = document.getElementById('required-keyword').value;
            const response = await fetch("{{ route('draw.start', $giveaway) }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    keyword: keyword
                })
            });

            const data = await response.json();

            if (!data.success) {
                appAlert(data.error);
                await switchScreenSmooth('loading-screen', 'summary-screen');
                btn.disabled = false;
                return;
            }

            // Hide header section
            const navbar = document.querySelector('nav');
            if (navbar) {
                navbar.classList.add('hidden');
            }

            // Go straight to the winner slot machine
            showWinnerReveal(data.winners, data.decoys, 'loading-screen');

        } catch (e) {
            appAlert('An error occurred during the draw. Ensure your database is connected.');
            await switchScreenSmooth('loading-screen', 'summary-screen');
            btn.disabled = false;
        }
    });

    async function animateSkyDrop(participants) {
        let bgContainer = document.getElementById('sky-drop-container');
        if (!bgContainer) {
            bgContainer = document.createElement('div');
            bgContainer.id = 'sky-drop-container';
            bgContainer.className = 'fixed inset-0 pointer-events-none z-0 overflow-hidden';
            document.body.appendChild(bgContainer);
        }
        bgContainer.innerHTML = '';
        bgContainer.style.opacity = '1';

        let cardContainer = document.getElementById('summary-card-particles');
        if (cardContainer) {
            cardContainer.innerHTML = '';
            cardContainer.style.opacity = '1';
        }

        if (!participants || participants.length === 0) return;

        for (let i = 0; i < participants.length; i++) {
            const p = participants[i];

            const imgHtml = p.profile_pic_url ? `<img src="${p.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s100x100/')}" class="w-10 h-10 rounded-full border border-white/20 mb-1 object-cover">` : '';
            const commentStr = p.comment ? (p.comment.length > 20 ? p.comment.substring(0, 20) + '...' : p.comment) : '';
            const cardHtml = `
                ${imgHtml}
                <div class="text-[10px] text-gray-300 font-bold mb-1 max-w-[100px] truncate text-center">"${commentStr}"</div>
                <div class="text-[9px] text-primary uppercase font-black tracking-widest bg-primary/20 px-1 rounded">Entry</div>
            `;

            // Drop into background
            const bgWrapper = document.createElement('div');
            bgWrapper.className = 'absolute flex flex-col items-center bg-black/60 p-2 rounded-xl border border-white/10 shadow-sm';
            bgWrapper.style.left = `${Math.random() * 90 + 5}%`;
            bgWrapper.innerHTML = cardHtml;
            bgContainer.appendChild(bgWrapper);

            const bgRot = Math.random() * 40 - 20;
            const bgEndY = Math.random() * (window.innerHeight - 150) + 50;
            const bgEndX = Math.random() * 100 - 50;

            bgWrapper.animate([{
                    transform: `translateY(-150px) translateX(0) scale(0.8) rotate(${Math.random() * 360}deg)`,
                    opacity: 0
                },
                {
                    opacity: 0.8,
                    offset: 0.1
                },
                {
                    transform: `translateY(${bgEndY}px) translateX(${bgEndX}px) scale(0.9) rotate(${bgRot}deg)`,
                    opacity: 0.35
                }
            ], {
                duration: 1000 + Math.random() * 1000,
                easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
                fill: 'forwards'
            });

            // Drop into Card
            if (cardContainer) {
                const cardWrapper = document.createElement('div');
                cardWrapper.className = 'absolute flex flex-col items-center bg-black/60 p-2 rounded-xl border border-white/10 shadow-sm';
                cardWrapper.style.left = `${Math.random() * 80 + 10}%`;
                cardWrapper.innerHTML = cardHtml;
                cardContainer.appendChild(cardWrapper);

                const cardRot = Math.random() * 40 - 20;
                const cardEndY = 150 + Math.random() * 150;
                const cardEndX = Math.random() * 100 - 50;

                cardWrapper.animate([{
                        transform: `translateY(-150px) translateX(0) scale(0.8) rotate(${Math.random() * 360}deg)`,
                        opacity: 0
                    },
                    {
                        opacity: 0.8,
                        offset: 0.1
                    },
                    {
                        transform: `translateY(${cardEndY}px) translateX(${cardEndX}px) scale(0.9) rotate(${cardRot}deg)`,
                        opacity: 0.35
                    }
                ], {
                    duration: 1000 + Math.random() * 500,
                    easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
                    fill: 'forwards'
                });
            }

            await new Promise(r => setTimeout(r, 40));
        }
    }

    function spinCardParticles(winners, decoys) {
        const drawParticles = document.getElementById('draw-card-particles');
        if (!drawParticles) return;
        drawParticles.innerHTML = '';

        const all = [...winners, ...(decoys || [])];
        for (let i = 0; i < 30; i++) {
            const p = all[i % all.length];
            if (!p || !p.profile_pic_url) continue;

            const wrapper = document.createElement('div');
            wrapper.className = 'absolute flex flex-col items-center bg-black/60 p-2 rounded-xl border border-white/10 shadow-sm';
            wrapper.style.left = `${Math.random() * 80 + 10}%`;

            const imgHtml = `<img src="${p.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s100x100/')}" class="w-10 h-10 rounded-full border border-white/20 mb-1 object-cover">`;
            const commentStr = p.comment ? (p.comment.length > 20 ? p.comment.substring(0, 20) + '...' : p.comment) : '';

            wrapper.innerHTML = `
                ${imgHtml}
                <div class="text-[10px] text-gray-300 font-bold mb-1 max-w-[100px] truncate text-center">"${commentStr}"</div>
                <div class="text-[9px] text-primary uppercase font-black tracking-widest bg-primary/20 px-1 rounded">Entry</div>
            `;

            const rot = Math.random() * 360;
            const endY = 50 + Math.random() * 200;
            const endX = Math.random() * 100 - 50;

            wrapper.style.transform = `translateY(${endY}px) translateX(${endX}px) scale(0.9) rotate(${rot}deg)`;
            wrapper.style.opacity = '0.8';

            drawParticles.appendChild(wrapper);
        }

        const totalSpinMs = Number("{{ $giveaway->spin_duration ?? 20 }}") * 1000;
        const swiperDuration = Math.min(5000, Math.max(2000, totalSpinMs * 0.3)); // 2 to 5 seconds for final slot machine
        const tornadoDuration = Math.max(100, totalSpinMs - swiperDuration);

        const container = document.getElementById('spinning-card-container');
        if (container) {
            container.classList.remove('spinning-jar');
            void container.offsetWidth; // trigger reflow
        }
        
        showWinnerReveal(winners, decoys, 'loading-screen');
    }

    async function showWinnerReveal(winners, decoys, fromScreenId = 'loading-screen') {
        const uiWrapperEl = document.getElementById('winner-ui-wrapper');
        const actionBox = document.getElementById('winner-actions-box');
        const grid = document.getElementById('winners-slot-grid');

        // Hide previous screen smoothly
        await switchScreenSmooth(fromScreenId, 'winner-screen');
        
        // Show UI wrapper immediately
        uiWrapperEl.classList.remove('opacity-0', 'pointer-events-none');
        uiWrapperEl.classList.add('opacity-100', 'pointer-events-auto');

        const reelTemplate = document.getElementById('reel-template').content;
        const detailTemplate = document.getElementById('winner-detail-template').content;
        const allCards = [];
        
        // Show the main winner card container
        const mainCardEl = document.getElementById('winner-card');
        mainCardEl.classList.remove('scale-0', 'opacity-0');
        mainCardEl.classList.add('scale-100', 'opacity-100');

        const masterSwiper = document.getElementById('master-swiper-container');
        masterSwiper.classList.remove('hidden');

        const reelsContainer = document.getElementById('reels-container');
        const detailsGrid = document.getElementById('winner-details-grid');
        reelsContainer.innerHTML = '';
        detailsGrid.innerHTML = '';

        winners.forEach((winner, idx) => {
            // 1. Setup the reel
            const reelClone = document.importNode(reelTemplate, true);
            const track = reelClone.querySelector('.swiper-track');
            
            // 2. Setup the detail card
            const detailClone = document.importNode(detailTemplate, true);
            const detailCardEl = detailClone.querySelector('.winner-detail-card');
            const avatarEl = detailClone.querySelector('.winner-avatar');
            const nameEl = detailClone.querySelector('.winner-name');
            const commentBox = detailClone.querySelector('.winner-comment-box');

            // Setup Swiper sequence
            const all = decoys && decoys.length > 0 ? decoys : [winner];
            let sequence = [];
            
            const spinSeconds = Number("{{ $giveaway->spin_duration ?? 20 }}");
            const targetSequenceLength = Math.max(100, spinSeconds * 15);
            
            for (let i = 0; i < targetSequenceLength; i++) {
                sequence.push(all[i % all.length]);
            }
            sequence.sort(() => Math.random() - 0.5);

            let direction = idx % 2 === 0 ? 'up' : 'down';

            let winnerIndex;
            if (direction === 'up') {
                sequence.push(winner);
                sequence.push(all[0]); 
                winnerIndex = sequence.length - 2;
            } else {
                sequence.unshift(winner);
                sequence.unshift(all[0]);
                winnerIndex = 1;
            }

            track.innerHTML = sequence.map((u, i) => {
                const img = u.profile_pic_url ? `<img src="${u.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s100x100/')}" class="w-16 h-16 sm:w-20 sm:h-20 max-w-full max-h-full rounded-full border-2 border-white/20 object-cover my-4 shadow-lg">` : `<div class="w-16 h-16 sm:w-20 sm:h-20 max-w-full max-h-full rounded-full bg-gray-500 my-4"></div>`;
                return `<div class="shrink-0 flex items-center justify-center h-[96px] sm:h-[112px] w-full px-1">${img}</div>`;
            }).join('');
            
            reelsContainer.appendChild(reelClone);
            detailsGrid.appendChild(detailClone);
            
            allCards.push({
                detailCardEl, avatarEl, nameEl, commentBox, track, sequence, winner, direction, winnerIndex
            });
        });

        await switchScreenSmooth('draw-screen', 'winner-screen');

        const duration = Number("{{ $giveaway->spin_duration ?? 20 }}") * 1000;
        
        function getCustomEase(timeElapsed, totalDuration) {
            const easeOutDuration = Math.min(5000, totalDuration * 0.4);
            const linearDuration = totalDuration - easeOutDuration;
            
            if (totalDuration <= easeOutDuration) {
                const progress = Math.min(timeElapsed / totalDuration, 1);
                return 1 - Math.pow(1 - progress, 5);
            }
            
            if (timeElapsed < linearDuration) {
                return (timeElapsed / linearDuration) * 0.85;
            } else {
                const easeTime = timeElapsed - linearDuration;
                const easeProgress = Math.min(easeTime / easeOutDuration, 1);
                const easeValue = 1 - Math.pow(1 - easeProgress, 5);
                return 0.85 + (easeValue * 0.15);
            }
        }

        allCards.forEach(cardData => {
            // Determine item height dynamically based on window width (sm vs default)
            const itemHeight = window.innerWidth >= 640 ? 112 : 96;
            const targetYOffset = -(cardData.winnerIndex * itemHeight) - (itemHeight / 2);
            let startY = 0;
            let targetY = targetYOffset;
            
            if (cardData.direction === 'up') {
                startY = 0;
            } else {
                startY = -((cardData.sequence.length - 1) * itemHeight) - (itemHeight / 2);
            }

            let currentY = 0;
            let startTime = null;

            function animateSwiper(time) {
                if (!startTime) startTime = time;
                const elapsed = time - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const eased = getCustomEase(elapsed, duration);
                currentY = startY + (targetY - startY) * eased;
                cardData.track.style.transform = `translateY(${currentY}px)`;

                if (progress < 1) {
                    requestAnimationFrame(animateSwiper);
                } else {
                    setTimeout(() => revealActualCard(cardData), 800);
                }
            }
            requestAnimationFrame(animateSwiper);
        });

        let revealedCount = 0;

        async function revealActualCard(cardData) {
            // Note: Unlike the single card, we do NOT fade out the swiper here. 
            // The reel stays visible with the winner's avatar on the payline!

            // Fade in the detail card
            cardData.detailCardEl.classList.remove('opacity-0', 'translate-y-4');
            cardData.detailCardEl.classList.add('opacity-100', 'translate-y-0');

            cardData.nameEl.classList.remove('animate-pulse');
            cardData.nameEl.textContent = cardData.winner.name;
            if (cardData.winner.profile_url) {
                cardData.nameEl.href = cardData.winner.profile_url;
                cardData.nameEl.classList.add('underline', 'decoration-primary/30', 'underline-offset-8', 'pointer-events-auto');
            }

            if (cardData.winner.profile_pic_url) {
                cardData.avatarEl.src = cardData.winner.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s600x600/');
            }

            if (cardData.winner.comment && cardData.winner.comment !== "No comment") {
                const commentP = cardData.commentBox.querySelector('.winner-comment');
                if(commentP) commentP.textContent = `"${cardData.winner.comment}"`;
                cardData.commentBox.classList.remove('opacity-0');
            }
            
            revealedCount++;
            if (revealedCount === winners.length) {
                actionBox.classList.remove('opacity-0', 'pointer-events-none');
                actionBox.style.setProperty('display', 'flex', 'important');
                actionBox.classList.remove('!hidden');
                setTimeout(() => {
                    shootConfetti();
                    initWinnerActions(winners);
                }, 600);
            }
        }
    }

    function initWinnerActions(winners) {
        const bannerBtn = document.getElementById('winner-banner-btn');
        let bannerClickCount = 0;
        
        if (bannerBtn) {
            bannerBtn.onclick = async () => {
                bannerClickCount++;
                if (bannerClickCount >= 5) {
                    bannerClickCount = 0;
                    
                    // Auto Disqualify and Respin without confirmation (disqualifies the first winner as fallback)
                    bannerBtn.style.pointerEvents = 'none';
                    
                    try {
                        const firstWinnerId = winners[0].id;
                        const res = await fetch(`/participants/${firstWinnerId}/disqualify`, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            }
                        });

                        const data = await res.json();
                        if (data.success) {
                            // Reset UI card styles before triggering new draw
                            const uiWrapperEl = document.getElementById('winner-ui-wrapper');
                            const mainCard = document.getElementById('winner-card');
                            const reelsContainer = document.getElementById('reels-container');
                            const detailsGrid = document.getElementById('winner-details-grid');
                            
                            uiWrapperEl.classList.remove('opacity-100', 'pointer-events-auto');
                            uiWrapperEl.classList.add('opacity-0', 'pointer-events-none');
                            mainCard.classList.remove('scale-100', 'opacity-100');
                            mainCard.classList.add('scale-0', 'opacity-0');
                            
                            if (reelsContainer) reelsContainer.innerHTML = '';
                            if (detailsGrid) detailsGrid.innerHTML = '';
                            
                            if (typeof confetti !== 'undefined') confetti.reset();

                            document.getElementById('start-btn').disabled = false;
                            document.getElementById('start-btn').innerHTML = `
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                SELECT WINNER
                            `;
                            document.getElementById('start-btn').click();
                        } else {
                            appAlert('Failed to disqualify for auto respin.');
                            bannerBtn.style.pointerEvents = 'auto';
                        }
                    } catch (e) {
                        appAlert('Error triggering auto respin.');
                        bannerBtn.style.pointerEvents = 'auto';
                    }
                }
            };
        }

        const disqualifyBtn = document.getElementById('disqualify-btn');
        if (disqualifyBtn) {
            disqualifyBtn.onclick = async () => {
                if (!await appConfirm('Are you sure you want to mark these participants as ineligible and spin again?')) return;

                disqualifyBtn.disabled = true;
                try {
                    // Just disqualify the first for now (can be expanded to disqualify all if needed)
                    const firstWinnerId = winners[0].id;
                    const res = await fetch(`/participants/${firstWinnerId}/disqualify`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        }
                    });

                    const data = await res.json();
                    if (data.success) {
                        // Reset UI card styles before triggering new draw
                        const uiWrapperEl = document.getElementById('winner-ui-wrapper');
                        const mainCard = document.getElementById('winner-card');
                        const reelsContainer = document.getElementById('reels-container');
                        const detailsGrid = document.getElementById('winner-details-grid');
                        
                        uiWrapperEl.classList.remove('opacity-100', 'pointer-events-auto');
                        uiWrapperEl.classList.add('opacity-0', 'pointer-events-none');
                        mainCard.classList.remove('scale-100', 'opacity-100');
                        mainCard.classList.add('scale-0', 'opacity-0');
                        
                        if (reelsContainer) reelsContainer.innerHTML = '';
                        if (detailsGrid) detailsGrid.innerHTML = '';
                        
                        if (typeof confetti !== 'undefined') confetti.reset();

                        document.getElementById('start-btn').disabled = false;
                        document.getElementById('start-btn').innerHTML = `
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            SELECT WINNER
                        `;
                        document.getElementById('start-btn').click();
                    } else {
                        appAlert('Failed to disqualify.');
                        disqualifyBtn.disabled = false;
                        disqualifyBtn.innerHTML = '🚫 Disqualify & Re-spin';
                    }
                } catch (e) {
                    appAlert('Error disqualifying participant.');
                    disqualifyBtn.disabled = false;
                    disqualifyBtn.innerHTML = '🚫 Disqualify & Re-spin';
                }
            };
        }
    }


    function toggleOptionsMenu(event) {
        event.stopPropagation();
        const dropdown = document.getElementById('options-dropdown');
        dropdown.classList.toggle('hidden');
    }

    document.addEventListener('click', () => {
        const dropdown = document.getElementById('options-dropdown');
        if (dropdown && !dropdown.classList.contains('hidden')) {
            dropdown.classList.add('hidden');
        }
    });

    function togglePresentationMode() {
        const container = document.getElementById('draw-container');
        const icon = document.getElementById('fullscreen-icon');

        if (container.classList.contains('z-30')) {
            // Enter full display (cover navbar)
            container.classList.remove('z-30');
            container.classList.add('z-50');
            icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 14h4v4m0-4l-5 5m17-5h-4v4m0-4l5 5M4 10h4V6m0 4l-5-5m17 5h-4V6m0 4l5-5"></path>';

            const navbar = document.querySelector('nav');
            if (navbar) navbar.classList.add('hidden');

            // Optionally try browser fullscreen API
            try {
                if (container.requestFullscreen) {
                    container.requestFullscreen();
                }
            } catch (e) {}
        } else {
            // Exit full display
            container.classList.remove('z-50');
            container.classList.add('z-30');
            icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path>';

            const navbar = document.querySelector('nav');
            if (navbar) navbar.classList.remove('hidden');

            try {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                }
            } catch (e) {}
        }
    }

    // Show modal if requested in URL (e.g. clicking Start Draw from Dashboard)
    window.addEventListener('DOMContentLoaded', () => {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('mode') === 'presentation') {
            document.getElementById('fullscreen-prompt').classList.remove('hidden');
        }
    });

    function acceptFullscreen() {
        const container = document.getElementById('draw-container');
        const icon = document.getElementById('fullscreen-icon');

        container.classList.remove('z-30');
        container.classList.add('z-50');
        icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 14h4v4m0-4l-5 5m17-5h-4v4m0-4l5 5M4 10h4V6m0 4l-5-5m17 5h-4V6m0 4l5-5"></path>';

        const navbar = document.querySelector('nav');
        if (navbar) navbar.classList.add('hidden');

        try {
            if (container.requestFullscreen) {
                container.requestFullscreen().catch(e => console.warn('Fullscreen rejected:', e));
            }
        } catch (e) {}

        document.getElementById('fullscreen-prompt').classList.add('hidden');
    }

    function declineFullscreen() {
        document.getElementById('fullscreen-prompt').classList.add('hidden');
    }

    document.querySelectorAll('.cyber-container').forEach(container => {
        const card = container.querySelector('.cyber-card');

        container.addEventListener('mousemove', e => {
            card.classList.remove('resetting');
            const rect = container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = ((y - centerY) / centerY) * -15; // Max 15 deg tilt
            const rotateY = ((x - centerX) / centerX) * 15;

            card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
            card.style.filter = 'brightness(1.15)';
        });

        container.addEventListener('mouseleave', () => {
            card.classList.add('resetting');
            card.style.transform = 'rotateX(0deg) rotateY(0deg)';
            card.style.filter = 'brightness(1)';
        });
    });
    
    function updateAvatar(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.getElementById('winner-avatar');
                img.src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    }
</script>
@endpush
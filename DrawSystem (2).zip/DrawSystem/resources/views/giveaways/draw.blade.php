@extends('layouts.public')

@section('content')
<div class="mb-6 flex items-center justify-between">
    <div class="flex items-center">
        <a href="{{ url('/giveaways/' . $giveaway->id) }}" class="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mr-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
        </a>
        <div>
            <h3 class="text-2xl font-bold text-gray-800 dark:text-white">Draw Room: {{ $giveaway->title }}</h3>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Prize: <span class="font-semibold text-gray-800 dark:text-gray-200">{{ $giveaway->prize }}</span></p>
        </div>
    </div>
</div>

<div x-data="drawEngine()" class="bg-gray-900 rounded-2xl shadow-2xl overflow-hidden border border-gray-700 min-h-[600px] relative">
    
    <!-- Initial State -->
    <div x-show="state === 'ready'" class="absolute inset-0 flex flex-col items-center justify-center text-center p-8">
        <h2 class="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500 mb-6">
            Ready to Draw?
        </h2>
        <p class="text-xl text-gray-300 mb-10 max-w-2xl">
            The participant list is securely frozen. Click the button below to generate the cryptographically secure random seed and perform the Fisher-Yates shuffle.
        </p>
        <button @click="startDraw" class="group relative px-10 py-5 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-bold text-2xl rounded-xl shadow-[0_0_40px_rgba(59,130,246,0.6)] hover:shadow-[0_0_60px_rgba(147,51,234,0.8)] transition-all hover:-translate-y-1">
            <span class="absolute inset-0 w-full h-full -mt-1 rounded-lg opacity-30 bg-gradient-to-b from-transparent via-transparent to-black"></span>
            <span class="relative flex items-center">
                <svg class="w-8 h-8 mr-3 animate-spin hidden group-hover:block" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Commence Draw
            </span>
        </button>
    </div>

    <!-- Animating State -->
    <div x-show="state === 'animating'" class="absolute inset-0 flex flex-col items-center justify-center p-8 bg-gray-900 bg-opacity-95 z-10" x-cloak>
        
        <h3 class="text-2xl text-blue-400 font-mono mb-4 uppercase tracking-widest" x-text="'Round ' + currentRound + ' / ' + totalRounds"></h3>
        
        <div class="text-6xl font-bold text-white tracking-wider mb-12 h-20 overflow-hidden relative w-full max-w-lg text-center">
            <span x-text="randomName" class="absolute inset-0 flex items-center justify-center w-full text-center"></span>
        </div>
        
        <div class="w-64 h-2 bg-gray-800 rounded-full overflow-hidden">
            <div class="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-300 ease-out" :style="'width: ' + ((currentRound / totalRounds) * 100) + '%'"></div>
        </div>
        <p class="mt-4 text-gray-500 text-sm font-mono" x-text="statusText"></p>
    </div>

    <!-- Results State -->
    <div x-show="state === 'finished'" class="absolute inset-0 overflow-y-auto p-10 bg-gray-900" x-cloak>
        <div class="text-center mb-12">
            <h2 class="text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500 mb-4 animate-pulse">
                Congratulations!
            </h2>
            <p class="text-gray-400 text-lg">The cryptographically secure draw has concluded.</p>
        </div>

        <div class="max-w-4xl mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Main Winners -->
                <div>
                    <h3 class="text-2xl font-bold text-white mb-6 border-b border-gray-700 pb-2">Main Winners</h3>
                    <div class="space-y-4">
                        <template x-for="(winner, index) in winners.filter(w => w.is_reserve == 0)" :key="index">
                            <div class="bg-gray-800 border border-yellow-500/30 rounded-xl p-6 flex items-center transform transition hover:scale-105 shadow-lg">
                                <div class="w-12 h-12 rounded-full bg-yellow-500/20 text-yellow-400 flex items-center justify-center font-bold text-xl mr-6">
                                    <span x-text="index + 1"></span>
                                </div>
                                <div>
                                    <h4 class="text-2xl font-bold text-white" x-text="winner.facebook_name"></h4>
                                    <p class="text-gray-400 text-sm mt-1">Winner Position: <span x-text="winner.position"></span></p>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>

                <!-- Reserve Winners -->
                <div x-show="winners.filter(w => w.is_reserve == 1).length > 0">
                    <h3 class="text-2xl font-bold text-gray-300 mb-6 border-b border-gray-700 pb-2">Reserve Winners</h3>
                    <div class="space-y-4">
                        <template x-for="(winner, index) in winners.filter(w => w.is_reserve == 1)" :key="index">
                            <div class="bg-gray-800/50 border border-gray-700 rounded-xl p-4 flex items-center">
                                <div class="w-10 h-10 rounded-full bg-gray-700 text-gray-300 flex items-center justify-center font-bold mr-4">
                                    <span x-text="index + 1"></span>
                                </div>
                                <div>
                                    <h4 class="text-lg font-bold text-gray-300" x-text="winner.facebook_name"></h4>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
            
            <div class="mt-16 text-center">
                <a href="{{ url('/dashboard') }}" class="text-blue-400 hover:text-blue-300 underline font-medium mr-6">Return to Dashboard</a>
                <a href="{{ url('/verification/show/' . $giveaway->id) }}" class="text-green-400 hover:text-green-300 underline font-medium">View Transparency Report</a>
            </div>
        </div>
    </div>
</div>

<script>
function drawEngine() {
    return {
        state: 'ready', // ready, animating, finished
        totalRounds: 4,
        currentRound: 0,
        randomName: '',
        statusText: 'Initializing cryptographically secure random bytes...',
        winners: [],
        
        startDraw() {
            this.state = 'animating';
            
            // Start backend process via AJAX
            fetch('{{ url("/giveaways/draw/" . $giveaway->id) }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    this.winners = data.winners;
                }
            });

            this.runAnimationSequence();
        },
        
        runAnimationSequence() {
            const names = ['John Doe', 'Jane Smith', 'Alex Johnson', 'Maria Garcia', 'Michael Brown', 'Emma Davis', 'James Miller', 'Olivia Wilson'];
            let roundInterval;
            let nameInterval;
            
            const nextRound = () => {
                this.currentRound++;
                if (this.currentRound > this.totalRounds) {
                    clearInterval(nameInterval);
                    setTimeout(() => {
                        this.state = 'finished';
                        // Throw confetti
                        if(typeof confetti !== 'undefined') {
                            confetti({ particleCount: 150, spread: 180, origin: { y: 0.6 } });
                        }
                    }, 500);
                    return;
                }
                
                this.statusText = 'Applying Fisher-Yates Shuffle... (Seed processing)';
                
                nameInterval = setInterval(() => {
                    this.randomName = names[Math.floor(Math.random() * names.length)];
                }, 50);

                setTimeout(() => {
                    clearInterval(nameInterval);
                    if (this.currentRound < this.totalRounds) {
                        setTimeout(nextRound, 500);
                    } else {
                        nextRound(); // trigger finish
                    }
                }, Math.max(1000, Math.floor((Number("{{ $giveaway->spin_duration ?? 20 }}") * 1000) / this.totalRounds))); // Total time distributed across rounds
            };
            
            nextRound();
        }
    }
}
</script>
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
@endsection

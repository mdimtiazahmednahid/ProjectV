import { Client } from "basic-ftp"
import * as fs from "fs"
import * as path from "path"

const client = new Client()

async function uploadDir(localPath, remotePath) {
    const items = fs.readdirSync(localPath)
    
    for (const item of items) {
        const fullLocalPath = path.join(localPath, item)
        const stat = fs.statSync(fullLocalPath)
        const targetRemotePath = remotePath + (remotePath.endsWith('/') ? '' : '/') + item
        
        if (stat.isDirectory()) {
            await client.ensureDir(targetRemotePath)
            await uploadDir(fullLocalPath, targetRemotePath)
            await client.cd('..')
        } else {
            await client.uploadFrom(fullLocalPath, targetRemotePath)
        }
    }
}

async function deploy() {
    try {
        await client.access({
            host: "ftp.shunnointernational.com",
            user: "ecom123@draw.shunnointernational.com",
            password: "u1#=1$}*0s^coqC[",
            secure: false
        })
        
        console.log("Connected to FTP server. Uploading missing files...")
        
        // Ensure the views that got cut off are uploaded
        await client.ensureDir("/resources/views")
        await uploadDir("e:\\NAHID\\DrawSystem\\resources\\views", "/resources/views")
        console.log("Uploaded resources/views")

        await client.ensureDir("/app/Http/Controllers")
        await client.uploadFrom("e:\\NAHID\\DrawSystem\\app\\Http\\Controllers\\DrawController.php", "/app/Http/Controllers/DrawController.php")
        console.log("Uploaded DrawController.php")

        console.log("Deployment completed successfully!")
    }
    catch(err) {
        console.error("Deployment failed:", err)
    }
    client.close()
}

deploy()

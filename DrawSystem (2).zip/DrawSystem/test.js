
    async function switchScreenSmooth(fromId, toId) {
        const fromEl = document.getElementById(fromId);
        const toEl = document.getElementById(toId);
        
        if (!fromEl || !toEl) return;

        if (!fromEl.classList.contains('hidden')) {
            fromEl.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
            fromEl.style.opacity = '0';
            fromEl.style.transform = 'translateY(-10px) scale(0.98)';
            await new Promise(r => setTimeout(r, 300));
            fromEl.classList.add('hidden');
        }
        
        toEl.classList.remove('hidden');
        toEl.style.transition = 'none';
        toEl.style.opacity = '0';
        toEl.style.transform = 'translateY(10px) scale(0.98)';
        
        void toEl.offsetWidth; // Force reflow
        
        toEl.style.transition = 'opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
        toEl.style.opacity = '1';
        toEl.style.transform = 'translateY(0) scale(1)';
        
        await new Promise(r => setTimeout(r, 400));
        
        fromEl.style = '';
        toEl.style = '';
    }
    function shootConfetti() {
        var duration = 40 * 1000; // 40 seconds
        var animationEnd = Date.now() + duration;
        var defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

        function randomInRange(min, max) {
            return Math.random() * (max - min) + min;
        }

        // Firework blasts & Side Sprays
        var interval = setInterval(function() {
            var timeLeft = animationEnd - Date.now();
            if (timeLeft <= 0) return clearInterval(interval);

            var particleCount = 80 * (timeLeft / duration);
            
            // Left Cannon
            confetti({
                particleCount: particleCount,
                angle: 60,
                spread: 55,
                origin: { x: 0, y: 0.9 },
                colors: ['#00A651', '#ffffff', '#FFD22A', '#f59e0b', '#FF3B30'],
                zIndex: 9999
            });
            // Right Cannon
            confetti({
                particleCount: particleCount,
                angle: 120,
                spread: 55,
                origin: { x: 1, y: 0.9 },
                colors: ['#00A651', '#ffffff', '#FFD22A', '#f59e0b', '#FF3B30'],
                zIndex: 9999
            });
            
            // Random sky fireworks
            if(Math.random() > 0.4) {
                confetti({
                    ...defaults, particleCount: 60,
                    origin: { x: randomInRange(0.1, 0.9), y: randomInRange(0.1, 0.4) },
                    colors: ['#FFD22A', '#ffffff', '#00A651'],
                    zIndex: 9999
                });
            }
        }, 300);

        // Initial Massive Central Bursts
        const colors = ['#FFD22A', '#ffffff', '#00A651', '#FF3B30', '#f59e0b'];
        
        // Burst 1
        confetti({ particleCount: 200, spread: 120, origin: { y: 0.6 }, colors: colors, zIndex: 9999 });
        
        // Burst 2 (delay)
        setTimeout(() => {
            confetti({ particleCount: 300, spread: 180, startVelocity: 45, origin: { y: 0.6 }, colors: colors, zIndex: 9999 });
        }, 400);

        // Burst 3 (Golden rain)
        setTimeout(() => {
            confetti({ particleCount: 400, spread: 360, startVelocity: 60, origin: { y: 0.4 }, colors: ['#FFD22A', '#F59E0B', '#ffffff'], zIndex: 9999 });
        }, 800);
        
        // Continuous falling Glitter/Snow
        (function frame() {
            var timeLeft = animationEnd - Date.now();
            if (timeLeft > 0) {
                confetti({
                    particleCount: 15,
                    angle: 90,
                    spread: 360,
                    startVelocity: 20,
                    origin: { x: Math.random(), y: -0.1 },
                    colors: ['#ffffff', '#FFD22A', '#F59E0B'],
                    shapes: ['circle', 'square'],
                    gravity: 0.7,
                    scalar: 0.9,
                    zIndex: 9999
                });
                requestAnimationFrame(frame);
            }
        }());
    }


    document.getElementById('analyze-btn').addEventListener('click', async () => {
        const btn = document.getElementById('analyze-btn');
        btn.disabled = true;
        
        const loadingText = document.getElementById('loading-text');
        if (loadingText) loadingText.textContent = 'ANALYZING DATA...';
        await switchScreenSmooth('setup-screen', 'loading-screen');
        
        try {
            const keyword = document.getElementById('required-keyword').value;
            const response = await fetch("{{ route('draw.summary', $giveaway) }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ keyword: keyword })
            });
            
            const data = await response.json();
            
            if(!data.success) {
                appAlert(data.error);
                await switchScreenSmooth('loading-screen', 'setup-screen');
                btn.disabled = false;
                return;
            }
            
            // Populate summary
            const sum = data.summary;
            const trueDisqualified = sum.total - sum.qualified;
            
            document.getElementById('summary-total').innerText = sum.total;
            document.getElementById('summary-disq').innerText = trueDisqualified;
            document.getElementById('summary-disq-pct').innerText = (sum.total > 0 ? Math.round((trueDisqualified / sum.total) * 100) : 0) + '%';
            document.getElementById('summary-qual').innerText = sum.qualified;
            document.getElementById('summary-qual-pct').innerText = (sum.total > 0 ? Math.round((sum.qualified / sum.total) * 100) : 0) + '%';
            
            await switchScreenSmooth('loading-screen', 'summary-screen');
            animateSkyDrop(data.participants);
            
            btn.disabled = false;
            
        } catch(e) {
            appAlert('An error occurred. Ensure your database is connected.');
            await switchScreenSmooth('loading-screen', 'setup-screen');
            btn.disabled = false;
        }
    });

    document.getElementById('start-btn').addEventListener('click', async () => {
        const btn = document.getElementById('start-btn');
        btn.disabled = true;
        
        const loadingText = document.getElementById('loading-text');
        if (loadingText) loadingText.textContent = 'CONNECTING...';
        
        const winnerScreen = document.getElementById('winner-screen');
        if (!winnerScreen.classList.contains('hidden')) {
            await switchScreenSmooth('winner-screen', 'loading-screen');
        } else {
            await switchScreenSmooth('summary-screen', 'loading-screen');
        }
        
        try {
            const keyword = document.getElementById('required-keyword').value;
            const response = await fetch("{{ route('draw.start', $giveaway) }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ keyword: keyword })
            });
            
            const data = await response.json();
            
            if(!data.success) {
                appAlert(data.error);
                await switchScreenSmooth('loading-screen', 'summary-screen');
                btn.disabled = false;
                return;
            }
            
            // Hide header section
            const navbar = document.querySelector('nav');
            if (navbar) {
                navbar.classList.add('hidden');
            }
            
            await switchScreenSmooth('loading-screen', 'draw-screen');
            spinCardParticles(data.winner, data.decoys);
            
        } catch(e) {
            appAlert('An error occurred during the draw. Ensure your database is connected.');
            await switchScreenSmooth('loading-screen', 'summary-screen');
            btn.disabled = false;
        }
    });
    
    async function animateSkyDrop(participants) {
        let bgContainer = document.getElementById('sky-drop-container');
        if (!bgContainer) {
            bgContainer = document.createElement('div');
            bgContainer.id = 'sky-drop-container';
            bgContainer.className = 'fixed inset-0 pointer-events-none z-0 overflow-hidden';
            document.body.appendChild(bgContainer);
        }
        bgContainer.innerHTML = '';
        bgContainer.style.opacity = '1';
        
        let cardContainer = document.getElementById('summary-card-particles');
        if (cardContainer) {
            cardContainer.innerHTML = '';
            cardContainer.style.opacity = '1';
        }
        
        if (!participants || participants.length === 0) return;
        
        for (let i = 0; i < participants.length; i++) {
            const p = participants[i];
            
            const imgHtml = p.profile_pic_url ? `<img src="${p.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s100x100/')}" class="w-10 h-10 rounded-full border border-white/20 mb-1 object-cover">` : '';
            const commentStr = p.comment ? (p.comment.length > 20 ? p.comment.substring(0,20)+'...' : p.comment) : '';
            const cardHtml = `
                ${imgHtml}
                <div class="text-[10px] text-gray-300 font-bold mb-1 max-w-[100px] truncate text-center">"${commentStr}"</div>
                <div class="text-[9px] text-primary uppercase font-black tracking-widest bg-primary/20 px-1 rounded">Vejal Nai</div>
            `;
            
            // Drop into background
            const bgWrapper = document.createElement('div');
            bgWrapper.className = 'absolute flex flex-col items-center bg-black/40 backdrop-blur-md p-2 rounded-xl border border-white/10 shadow-lg';
            bgWrapper.style.left = `${Math.random() * 90 + 5}%`;
            bgWrapper.innerHTML = cardHtml;
            bgContainer.appendChild(bgWrapper);
            
            const bgRot = Math.random() * 40 - 20;
            const bgEndY = Math.random() * (window.innerHeight - 150) + 50;
            const bgEndX = Math.random() * 100 - 50;
            
            bgWrapper.animate([
                { transform: `translateY(-150px) translateX(0) scale(0.8) rotate(${Math.random() * 360}deg)`, opacity: 0 },
                { opacity: 1, offset: 0.1 },
                { transform: `translateY(${bgEndY}px) translateX(${bgEndX}px) scale(0.9) rotate(${bgRot}deg)`, opacity: 0.6 }
            ], {
                duration: 1000 + Math.random() * 1000,
                easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
                fill: 'forwards'
            });
            

            
            await new Promise(r => setTimeout(r, 40));
        }
    }

    function spinCardParticles(winner, decoys) {
        const drawParticles = document.getElementById('draw-card-particles');
        if (!drawParticles) return;
        drawParticles.innerHTML = '';
        
        const all = [winner, ...decoys];
        for (let i = 0; i < 30; i++) {
            const p = all[i % all.length];
            if (!p || !p.profile_pic_url) continue;
            
            const wrapper = document.createElement('div');
            wrapper.className = 'absolute flex flex-col items-center bg-black/40 backdrop-blur-md p-2 rounded-xl border border-white/10 shadow-lg';
            wrapper.style.left = `${Math.random() * 80 + 10}%`;
            
            const imgHtml = `<img src="${p.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s100x100/')}" class="w-10 h-10 rounded-full border border-white/20 mb-1 object-cover">`;
            const commentStr = p.comment ? (p.comment.length > 20 ? p.comment.substring(0,20)+'...' : p.comment) : '';
            
            wrapper.innerHTML = `
                ${imgHtml}
                <div class="text-[10px] text-gray-300 font-bold mb-1 max-w-[100px] truncate text-center">"${commentStr}"</div>
                <div class="text-[9px] text-primary uppercase font-black tracking-widest bg-primary/20 px-1 rounded">Vejal Nai</div>
            `;
            
            const rot = Math.random() * 360;
            const endY = 50 + Math.random() * 200;
            const endX = Math.random() * 100 - 50;
            
            wrapper.style.transform = `translateY(${endY}px) translateX(${endX}px) scale(0.9) rotate(${rot}deg)`;
            wrapper.style.opacity = '0.8';
            
            drawParticles.appendChild(wrapper);
        }
        
        setTimeout(() => {
            showWinnerReveal(winner, decoys);
        }, 3000);
     async function showWinnerReveal(winner, decoys) {
        const swiperEl = document.getElementById('swiper-container');
        const uiWrapperEl = document.getElementById('winner-ui-wrapper');
        const card = document.getElementById('winner-card');
        
        swiperEl.classList.remove('opacity-0', 'hidden');
        swiperEl.classList.add('opacity-100');
        uiWrapperEl.classList.remove('opacity-100', 'pointer-events-auto');
        uiWrapperEl.classList.add('opacity-0', 'pointer-events-none');
        card.classList.remove('scale-100', 'opacity-100');
        card.classList.add('scale-0', 'opacity-0');
        
        await switchScreenSmooth('draw-screen', 'winner-screen');
        
        // Setup Swiper
        const track = document.getElementById('swiper-track');
        track.innerHTML = '';
        const all = decoys && decoys.length > 0 ? decoys : [winner];
        let sequence = [];
        for(let i=0; i<40; i++) sequence.push(all[Math.floor(Math.random()*all.length)]);
        sequence.push(winner);
        sequence.push(all[0]);
        
        track.innerHTML = sequence.map((u, i) => {
            const img = u.profile_pic_url ? `<img src="${u.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s100x100/')}" class="w-20 h-20 rounded-full border-2 border-white/20 object-cover mx-4 shadow-lg">` : `<div class="w-20 h-20 rounded-full bg-gray-500 mx-4"></div>`;
            return `<div class="shrink-0 flex items-center justify-center">${img}</div>`;
        }).join('');
        
        // Animate Swiper
        const itemWidth = 112; // 80px + 32px margins
        const winnerIndex = sequence.length - 2;
        const targetX = -(winnerIndex * itemWidth) - (itemWidth/2);
        
        let startX = 0;
        let currentX = 0;
        let startTime = null;
        const duration = 3000;
        
        function easeOutExpo(x) { return x === 1 ? 1 : 1 - Math.pow(2, -10 * x); }
        
        function animateSwiper(time) {
            if (!startTime) startTime = time;
            const elapsed = time - startTime;
            let progress = Math.min(elapsed / duration, 1);
            
            const eased = easeOutExpo(progress);
            currentX = startX + (targetX - startX) * eased;
            track.style.transform = `translateX(${currentX}px)`;
            
            if(progress < 1) {
                requestAnimationFrame(animateSwiper);
            } else {
                setTimeout(revealActualCard, 800);
            }
        }
        requestAnimationFrame(animateSwiper);
        
        async function revealActualCard() {
            swiperEl.classList.remove('opacity-100');
            swiperEl.classList.add('opacity-0');
            
            await new Promise(r => setTimeout(r, 700));
            swiperEl.classList.add('hidden');
            
            const nameEl = document.getElementById('winner-name');
            nameEl.textContent = winner.name;
            if (winner.profile_url) {
                nameEl.href = winner.profile_url;
                nameEl.classList.add('underline', 'decoration-primary/30', 'underline-offset-8');
            } else {
                nameEl.removeAttribute('href');
                nameEl.classList.remove('underline');
            }
    
            const avatarEl = document.getElementById('winner-avatar');
            if (winner.profile_pic_url) {
                avatarEl.src = winner.profile_pic_url.replace(/\/[sp]\d+x\d+\//g, '/s600x600/');
                avatarEl.classList.remove('hidden');
            } else {
                avatarEl.classList.add('hidden');
            }
            
            document.getElementById('winner-comment').textContent = `"${winner.comment}"`;
            
            const tagContainer = document.getElementById('winner-tags');
            tagContainer.innerHTML = '';
            
            if (winner.is_follower) {
                tagContainer.innerHTML += `<span class="bg-blue-900/40 text-blue-300 text-xs font-bold px-2.5 py-1 rounded border border-blue-500/30 flex items-center gap-1"><svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"></path><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm9.707 5.707a1 1 0 00-1.414-1.414L9 12.586l-1.293-1.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg> Follower</span>`;
            }
            if (winner.has_liked) {
                tagContainer.innerHTML += `<span class="bg-red-900/40 text-red-300 text-xs font-bold px-2.5 py-1 rounded border border-red-500/30 flex items-center gap-1"><svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd"></path></svg> Liked</span>`;
            }
            
            uiWrapperEl.classList.remove('opacity-0', 'pointer-events-none');
            uiWrapperEl.classList.add('opacity-100', 'pointer-events-auto');
            
            await new Promise(r => setTimeout(r, 100));
            
            card.classList.remove('scale-0', 'opacity-0');
            card.classList.add('scale-100', 'opacity-100');
            
            setTimeout(() => {
                shootConfetti();
                
                const disqualifyBtn = document.getElementById('disqualify-btn');
                if (disqualifyBtn) {
                    disqualifyBtn.onclick = async () => {
                        disqualifyBtn.disabled = true;
                        disqualifyBtn.innerHTML = '<svg class="animate-spin w-4 h-4 mr-2 inline" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> Disqualifying...';
                        
                        const response = await fetch("{{ route('draw.disqualify', $giveaway) }}", {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            },
                            body: JSON.stringify({ participant_id: winner.id })
                        });
                        
                        const result = await response.json();
                        if (result.success) {
                            uiWrapperEl.classList.remove('opacity-100', 'pointer-events-auto');
                            uiWrapperEl.classList.add('opacity-0', 'pointer-events-none');
                            card.classList.remove('scale-100', 'opacity-100');
                            card.classList.add('scale-0', 'opacity-0');
                            
                            document.getElementById('start-btn').disabled = false;
                            document.getElementById('start-btn').innerHTML = `
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                SELECT WINNER
                            `;
                            document.getElementById('start-btn').click();
                        } else {
                            appAlert('Failed to disqualify.');
                            disqualifyBtn.disabled = false;
                            disqualifyBtn.innerHTML = '🚫 Disqualify & Re-spin';
                        }
                    };
                }
            }, 600);
        }
    }
    
    // Make sure we define saveBtn if not defined inside showWinnerReveal
    function initWinnerActions(winner) {
        const saveBtn = document.getElementById('save-btn');
        if (saveBtn) {
            saveBtn.onclick = async () => {
                saveBtn.disabled = true;
                document.getElementById('save-text').textContent = 'Saving...';
                
                try {
                    const res = await fetch("{{ route('draw.save', $giveaway) }}", {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({ participant_id: winner.id })
                    });
                    const data = await res.json();
                    if(data.success) {
                        document.getElementById('save-text').textContent = 'Winner Saved!';
                        saveBtn.classList.replace('bg-primary', 'bg-gray-400');
                        saveBtn.classList.remove('hover:bg-primaryDark');
                        saveBtn.classList.add('pointer-events-none');
                    } else {
                        throw new Error(data.error);
                    }
                } catch(e) {
                    appAlert('Error saving winner.');
                    saveBtn.disabled = false;
                    document.getElementById('save-text').textContent = 'Try Again';
                }
            };
        }
        
        const disqualifyBtn = document.getElementById('disqualify-btn');
        if (disqualifyBtn) {
            disqualifyBtn.onclick = async () => {
                if(!await appConfirm('Are you sure you want to mark this participant as ineligible and spin again?')) return;
                
                disqualifyBtn.disabled = true;
                try {
                    const res = await fetch("{{ route('draw.disqualify', $giveaway) }}", {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({ participant_id: winner.id })
                    });
                    
                    const data = await res.json();
                    if(data.success) {
                        // Reset UI card styles before triggering new draw
                        const uiWrapperEl = document.getElementById('winner-ui-wrapper');
                        const card = document.getElementById('winner-card');
                        uiWrapperEl.classList.remove('opacity-100', 'pointer-events-auto');
                        uiWrapperEl.classList.add('opacity-0', 'pointer-events-none');
                        card.classList.remove('scale-100', 'opacity-100');
                        card.classList.add('scale-0', 'opacity-0');
                        
                        document.getElementById('start-btn').disabled = false;
                        document.getElementById('start-btn').innerHTML = `
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            SELECT WINNER
                        `;
                        document.getElementById('start-btn').click();
                    } else {
                        appAlert('Failed to disqualify.');
                        disqualifyBtn.disabled = false;
                        disqualifyBtn.innerHTML = '🚫 Disqualify & Re-spin';
                    }
                } catch(e) {
                    appAlert('Error disqualifying participant.');
                    disqualifyBtn.disabled = false;
                    disqualifyBtn.innerHTML = '🚫 Disqualify & Re-spin';
                }
            };
        }
    }


    function toggleOptionsMenu(event) {
        event.stopPropagation();
        const dropdown = document.getElementById('options-dropdown');
        dropdown.classList.toggle('hidden');
    }

    document.addEventListener('click', () => {
        const dropdown = document.getElementById('options-dropdown');
        if (dropdown && !dropdown.classList.contains('hidden')) {
            dropdown.classList.add('hidden');
        }
    });

    function togglePresentationMode() {
        const container = document.getElementById('draw-container');
        const icon = document.getElementById('fullscreen-icon');
        
        if (container.classList.contains('z-30')) {
            // Enter full display (cover navbar)
            container.classList.remove('z-30');
            container.classList.add('z-50');
            icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 14h4v4m0-4l-5 5m17-5h-4v4m0-4l5 5M4 10h4V6m0 4l-5-5m17 5h-4V6m0 4l5-5"></path>';
            
            const navbar = document.querySelector('nav');
            if (navbar) navbar.classList.add('hidden');
            
            // Optionally try browser fullscreen API
            try {
                if (document.documentElement.requestFullscreen) {
                    document.documentElement.requestFullscreen();
                }
            } catch(e) {}
        } else {
            // Exit full display
            container.classList.remove('z-50');
            container.classList.add('z-30');
            icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path>';
            
            const navbar = document.querySelector('nav');
            if (navbar) navbar.classList.remove('hidden');
            
            try {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                }
            } catch(e) {}
        }
    }

    // Show modal if requested in URL (e.g. clicking Start Draw from Dashboard)
    window.addEventListener('DOMContentLoaded', () => {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('mode') === 'presentation') {
            document.getElementById('fullscreen-prompt').classList.remove('hidden');
        }
    });

    function acceptFullscreen() {
        const container = document.getElementById('draw-container');
        const icon = document.getElementById('fullscreen-icon');
        
        container.classList.remove('z-30');
        container.classList.add('z-50');
        icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 14h4v4m0-4l-5 5m17-5h-4v4m0-4l5 5M4 10h4V6m0 4l-5-5m17 5h-4V6m0 4l5-5"></path>';
        
        const navbar = document.querySelector('nav');
        if (navbar) navbar.classList.add('hidden');
        
        try {
            if (document.documentElement.requestFullscreen) {
                document.documentElement.requestFullscreen().catch(e => console.warn('Fullscreen rejected:', e));
            }
        } catch(e) {}
        
        document.getElementById('fullscreen-prompt').classList.add('hidden');
    }

    function declineFullscreen() {
        document.getElementById('fullscreen-prompt').classList.add('hidden');
    }

    document.querySelectorAll('.cyber-container').forEach(container => {
        const card = container.querySelector('.cyber-card');
        
        container.addEventListener('mousemove', e => {
            card.classList.remove('resetting');
            const rect = container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = ((y - centerY) / centerY) * -15; // Max 15 deg tilt
            const rotateY = ((x - centerX) / centerX) * 15;
            
            card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
            card.style.filter = 'brightness(1.15)';
        });
        
        container.addEventListener('mouseleave', () => {
            card.classList.add('resetting');
            card.style.transform = 'rotateX(0deg) rotateY(0deg)';
            card.style.filter = 'brightness(1)';
        });
    });

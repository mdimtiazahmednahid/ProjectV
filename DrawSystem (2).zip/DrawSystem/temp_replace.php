<?php
$files = [
    'resources/views/giveaway.blade.php',
    'resources/views/draw.blade.php',
    'resources/views/trash.blade.php'
];

foreach ($files as $f) {
    $c = file_get_contents($f);
    // Replace alert('...')
    $c = preg_replace("/alert\((.*?)\);/", "appAlert($1);", $c);
    
    // Replace if (!confirm('...')) return;
    $c = preg_replace("/if \(\!confirm\((.*?)\)\) return;/", "if (!await appConfirm($1)) return;", $c);
    
    // Replace onsubmit="return confirm('...');"
    $c = preg_replace("/onsubmit=[\"']return confirm\((.*?)\);[\"']/", "onsubmit=\"return formConfirm(event, this, $1);\"", $c);
    
    // Add async to executeBulkAction in giveaway.blade.php
    if ($f === 'resources/views/giveaway.blade.php') {
        $c = str_replace('function executeBulkAction(action)', 'async function executeBulkAction(action)', $c);
        $c = str_replace('function deleteParticipantRow(id)', 'async function deleteParticipantRow(id)', $c);
    }
    
    if ($f === 'resources/views/draw.blade.php') {
        $c = str_replace('function respin(participantId)', 'async function respin(participantId)', $c);
    }
    
    file_put_contents($f, $c);
    echo "Updated $f\n";
}

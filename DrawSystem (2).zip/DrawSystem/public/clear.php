<?php

// A quick script to clear all caches on shared hosting without terminal access
$cacheFiles = [
    __DIR__ . '/../bootstrap/cache/config.php',
    __DIR__ . '/../bootstrap/cache/routes-v7.php',
    __DIR__ . '/../bootstrap/cache/packages.php',
    __DIR__ . '/../bootstrap/cache/services.php',
];

echo "<h2>Clearing Laravel Cache...</h2>";

foreach ($cacheFiles as $file) {
    if (file_exists($file)) {
        if (unlink($file)) {
            echo "<p style='color:green;'>Deleted: " . basename($file) . "</p>";
        } else {
            echo "<p style='color:red;'>Failed to delete: " . basename($file) . "</p>";
        }
    } else {
        echo "<p style='color:gray;'>File not found (already cleared): " . basename($file) . "</p>";
    }
}

echo "<h3>✅ Cache cleared successfully! You can now visit your website and the database error should be fixed.</h3>";
echo "<p><em>Note: Please delete this clear.php file from cPanel once you are done for security.</em></p>";

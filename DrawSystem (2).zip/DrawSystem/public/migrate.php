<?php

/**
 * Script to run database migrations from a web browser (e.g. on cPanel)
 * Usage: Visit yourdomain.com/migrate.php?key=RunMigrate123
 * 
 * IMPORTANT: Delete this file after you are done to keep your server secure!
 */

// Simple security key to prevent random bots from running your migrations
$secretKey = 'RunMigrate123';

if (!isset($_GET['key']) || $_GET['key'] !== $secretKey) {
    http_response_code(403);
    die("<h1>403 Unauthorized</h1><p>Please provide the correct key in the URL. Example: <code>/migrate.php?key=RunMigrate123</code></p>");
}

// Boot the Laravel Application
require __DIR__.'/../vendor/autoload.php';
$app = require_once __DIR__.'/../bootstrap/app.php';

// Handle the HTTP request to bootstrap the framework
$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$kernel->handle(
    $request = Illuminate\Http\Request::capture()
);

try {
    echo "<h1>Running Migrations...</h1>";
    
    // Call the artisan migrate command, forcing it in production
    \Illuminate\Support\Facades\Artisan::call('migrate', ['--force' => true]);
    
    // Output the result
    echo "<pre style='background: #1e1e1e; color: #00ff00; padding: 20px; border-radius: 8px;'>";
    $output = \Illuminate\Support\Facades\Artisan::output();
    echo htmlspecialchars($output) ?: "No output or nothing to migrate.";
    echo "</pre>";
    
    echo "<p style='color: green; font-weight: bold;'>Migrations completed successfully!</p>";
    echo "<p style='color: red; font-weight: bold;'>PLEASE DELETE THIS FILE (migrate.php) NOW FOR SECURITY REASONS.</p>";
    
} catch (\Exception $e) {
    echo "<h1>Error Occurred</h1>";
    echo "<pre style='background: #fef2f2; color: #991b1b; padding: 20px; border-radius: 8px; border: 1px solid #f87171;'>";
    echo htmlspecialchars($e->getMessage());
    echo "</pre>";
}

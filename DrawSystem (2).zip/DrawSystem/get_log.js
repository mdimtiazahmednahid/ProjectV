import { Client } from "basic-ftp"

const client = new Client()

async function getLog() {
    try {
        await client.access({
            host: "ftp.shunnointernational.com",
            user: "ecom123@draw.shunnointernational.com",
            password: "u1#=1$}*0s^coqC[",
            secure: false
        })
        
        console.log("Connected. Downloading remote laravel.log...")
        await client.downloadTo("remote_laravel.log", "/storage/logs/laravel.log")
        console.log("Downloaded successfully!")
    }
    catch(err) {
        console.error("Failed:", err)
    }
    client.close()
}

getLog()
